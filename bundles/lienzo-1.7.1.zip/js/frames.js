// Marcos de página dentro del lienzo infinito: zonas del tamaño de un A4 (o Carta) que marcan cómo se
// repartirá el tablero al exportarlo o imprimirlo. Son solo una guía: no se exportan ni tapan nada.
import { uid } from './util.js';

export const PAPERS = {
  a4: { name: 'A4', w: 794, h: 1123, ptW: 595.28, ptH: 841.89 },
  letter: { name: 'Carta', w: 816, h: 1056, ptW: 612, ptH: 792 },
};

/** Numeración en orden de lectura: de arriba abajo y, en la misma fila, de izquierda a derecha. */
export function frameNumbers(items) {
  const frames = items.filter((i) => i.type === 'frame');
  if (!frames.length) return new Map();
  const sorted = [...frames].sort((a, b) => a.y - b.y);
  const rows = [];
  for (const f of sorted) {
    const row = rows.find((r) => Math.abs(r.y - f.y) < Math.min(r.h, f.h) * 0.5);
    if (row) row.items.push(f); else rows.push({ y: f.y, h: f.h, items: [f] });
  }
  const out = new Map();
  let n = 1;
  for (const r of rows) for (const f of r.items.sort((a, b) => a.x - b.x)) out.set(f.id, n++);
  return out;
}

export const framesInOrder = (items) => { const nums = frameNumbers(items); return items.filter((i) => i.type === 'frame').sort((a, b) => nums.get(a.id) - nums.get(b.id)); };

/** Marco nuevo centrado en la vista, a un tamaño que se vea entero. */
export function newFrame(vis, { paper = 'a4', landscape = false } = {}) {
  const P = PAPERS[paper];
  const w0 = landscape ? P.h : P.w, h0 = landscape ? P.w : P.h;
  const s = Math.min((vis.w * 0.7) / w0, (vis.h * 0.7) / h0);
  const w = w0 * s, h = h0 * s;
  return { id: uid(), type: 'frame', x: vis.x + (vis.w - w) / 2, y: vis.y + (vis.h - h) / 2, w, h, rot: 0, paper, landscape };
}

/** Cambia el papel o la orientación manteniendo el centro y el ancho aproximado. */
export function reshapeFrame(f, { paper = f.paper, landscape = f.landscape }) {
  const P = PAPERS[paper];
  const ratio = landscape ? P.w / P.h : P.h / P.w;    // alto / ancho
  const area = f.w * f.h, w = Math.sqrt(area / ratio), h = w * ratio;
  return { paper, landscape, w, h, x: f.x + f.w / 2 - w / 2, y: f.y + f.h / 2 - h / 2 };
}

/**
 * ¿Un toque en (x, y) coge el marco? Solo por el borde o la etiqueta: tocar dentro deja escribir y
 * seleccionar lo que hay encima con normalidad.
 */
export function frameEdgeHit(f, x, y, tol) {
  const inOuter = x >= f.x - tol && x <= f.x + f.w + tol && y >= f.y - tol && y <= f.y + f.h + tol;
  const inInner = x > f.x + tol && x < f.x + f.w - tol && y > f.y + tol && y < f.y + f.h - tol;
  const onLabel = x >= f.x && x <= f.x + Math.min(f.w, tol * 14) && y >= f.y - tol * 3.2 && y <= f.y;
  return (inOuter && !inInner) || onLabel;
}
