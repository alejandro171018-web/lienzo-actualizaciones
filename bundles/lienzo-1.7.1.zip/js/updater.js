// Actualizaciones en directo: la app descarga sola la nueva versión web publicada en GitHub.
// Los cambios nativos (Android) siguen necesitando instalar un APK; el aviso lo indica.
import { VERSION } from './version.js';
import { UPDATE_MANIFEST } from './update-config.js';
import { isNative, openExternal } from './native.js';
import { h } from './util.js';
import { toast } from './ui.js';

const Cap = window.Capacitor;
const Updater = () => Cap?.Plugins?.CapacitorUpdater || Cap?.registerPlugin?.('CapacitorUpdater');
const AppPlugin = () => Cap?.Plugins?.App || Cap?.registerPlugin?.('App');
const CHECK_EVERY = 30 * 60 * 1000;

export function newer(a, b) {
  const pa = String(a).split('.').map(Number), pb = String(b).split('.').map(Number);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    if ((pa[i] || 0) !== (pb[i] || 0)) return (pa[i] || 0) > (pb[i] || 0);
  }
  return false;
}

let lastCheck = 0, busy = false, ready = null;

/** Confirma que esta versión arranca bien (si no, el complemento vuelve a la anterior). */
export async function initUpdater() {
  if (!isNative) return;
  try { await Updater().notifyAppReady(); } catch (e) { console.warn('updater', e); }
  check();
  AppPlugin()?.addListener?.('resume', () => check());
}

export async function check({ manual = false } = {}) {
  if (!isNative || !UPDATE_MANIFEST) { if (manual) toast('Las actualizaciones automáticas solo funcionan en la app instalada'); return; }
  if (busy || (!manual && Date.now() - lastCheck < CHECK_EVERY)) return;
  busy = true; lastCheck = Date.now();
  try {
    const res = await fetch(UPDATE_MANIFEST, { cache: 'no-store', headers: { Accept: 'application/vnd.github.raw+json' } });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const m = await res.json();
    if (!newer(m.version, VERSION)) { if (manual) toast(`Tienes la última versión (${VERSION})`); return; }
    if (m.minNative) {
      const info = await AppPlugin()?.getInfo?.().catch(() => null);
      if (info && Number(info.build) < Number(m.minNative)) { banner(m, null, true); return; }
    }
    if (ready?.version === m.version) { banner(m, ready); return; }
    if (manual) toast('Descargando la actualización…');
    const bundle = await Updater().download({ url: m.url, version: m.version, checksum: m.checksum });
    ready = bundle;
    // Se aplicará sola la próxima vez que abras la app; o al momento con «Actualizar».
    await Updater().next({ id: bundle.id });
    banner(m, bundle);
  } catch (e) {
    console.warn('actualización', e);
    if (manual) toast('No se pudo buscar la actualización (¿hay conexión?)');
  } finally { busy = false; }
}

function banner(m, bundle, needsApk = false) {
  document.querySelector('.update-banner')?.remove();
  const el = h('div.update-banner', {},
    h('div.ub-text', {}, h('b', { text: needsApk ? 'Hay una versión nueva que necesita instalar el APK' : `Pizarra ${m.version} está lista` }),
      m.notes ? h('span', { text: m.notes }) : null),
    h('button.btn', { text: 'Luego', onclick: () => el.remove() }),
    needsApk ? h('button.btn.primary', { text: 'Descargar', onclick: () => { el.remove(); openExternal(m.apk || 'https://github.com/alejandro171018-web/lienzo-actualizaciones/releases/latest'); } }) : h('button.btn.primary', { text: 'Actualizar', onclick: async () => {
      el.remove();
      try { await window.lienzo?.board?.persist?.(); } catch { /* sin tablero abierto */ }
      await Updater().set({ id: bundle.id });
    } }));
  document.getElementById('overlay').append(el);
}
