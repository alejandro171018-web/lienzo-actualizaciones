// Dónde busca la app las actualizaciones (repositorio público con la versión web compilada).
// Se usa la API de GitHub (caché de 60 s) en lugar de raw.githubusercontent.com (caché de 5 min).
export const UPDATE_MANIFEST = 'https://api.github.com/repos/alejandro171018-web/lienzo-actualizaciones/contents/latest.json';
