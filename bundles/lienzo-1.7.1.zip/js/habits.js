// Aprende de cómo dibujas: qué colores y grosores usas más con cada lápiz.
// Con eso, los colores rápidos de la paleta se adaptan solos (sin cambiar su distribución)
// y las opciones de cada lápiz muestran tus combinaciones favoritas.
import { settings, saveSettings } from './settings.js';
import { TOOLS } from './ink.js';

const DECAY = 0.97;        // lo reciente pesa más que lo antiguo
const MAX_ENTRIES = 24;
const ADOPT_AT = 3;        // usos (ponderados) para que un color entre en los rápidos
const MARKER_SEED = ['#FFCC00', '#34C759', '#FF2D55', '#5AC8FA', '#FF9500'];

const same = (a, b) => a && b && a.toUpperCase() === b.toUpperCase();

/** Colores rápidos que se ven en la paleta para un lápiz. */
export function quickColorsFor(tool) {
  if (!settings.smartColors || !TOOLS[tool]) return settings.quickColors;
  const q = settings.toolQuick?.[tool];
  if (q?.length === 5) return q;
  return tool === 'marker' ? MARKER_SEED : settings.quickColors;
}

function ensureQuick(tool) {
  if (!settings.toolQuick) settings.toolQuick = {};
  if (settings.toolQuick[tool]?.length !== 5) settings.toolQuick[tool] = [...quickColorsFor(tool)];
  return settings.toolQuick[tool];
}

/** Cambia a mano un color rápido: ese hueco queda fijado y el aprendizaje no lo toca. */
export function setQuickColor(tool, i, color) {
  if (!settings.smartColors || !TOOLS[tool]) { settings.quickColors[i] = color; saveSettings(); return; }
  ensureQuick(tool)[i] = color;
  if (!settings.quickPinned) settings.quickPinned = {};
  const pins = settings.quickPinned[tool] || [false, false, false, false, false];
  pins[i] = true;
  settings.quickPinned[tool] = pins;
  saveSettings();
}

function colorScore(tool, color) {
  let s = 0;
  for (const [k, v] of Object.entries(settings.usage?.[tool] || {})) if (same(k.split('|')[0], color)) s += v;
  return s;
}

/** Registra un trazo. Devuelve el color si acaba de entrar en los colores rápidos. */
export function recordUse(tool, color, sizeIdx) {
  if (!TOOLS[tool] || !color) return null;
  if (!settings.usage) settings.usage = {};
  const u = settings.usage[tool] || {};
  for (const k of Object.keys(u)) u[k] *= DECAY;
  const key = `${color.toUpperCase()}|${sizeIdx}`;
  u[key] = (u[key] || 0) + 1;
  const entries = Object.entries(u).sort((a, b) => b[1] - a[1]).slice(0, MAX_ENTRIES);
  settings.usage[tool] = Object.fromEntries(entries);
  let adopted = null;
  if (settings.smartColors) adopted = adopt(tool, color);
  saveSettings();
  return adopted;
}

/** Si un color se usa mucho y no está en los rápidos, ocupa el hueco del menos usado (sin mover los demás). */
function adopt(tool, color) {
  const quick = quickColorsFor(tool);
  if (quick.some((c) => same(c, color))) return null;
  const score = colorScore(tool, color);
  if (score < ADOPT_AT) return null;
  const pins = settings.quickPinned?.[tool] || [];
  let slot = -1, low = Infinity;
  quick.forEach((c, i) => { if (pins[i]) return; const s = colorScore(tool, c); if (s < low) { low = s; slot = i; } });
  if (slot < 0 || score <= low + 1) return null;
  ensureQuick(tool)[slot] = color.toUpperCase();
  return color;
}

/** Combinaciones de color y grosor que más usas con un lápiz. */
export function favorites(tool, n = 4) {
  return Object.entries(settings.usage?.[tool] || {})
    .filter(([, v]) => v >= 1.5)
    .sort((a, b) => b[1] - a[1])
    .slice(0, n)
    .map(([k]) => { const [color, size] = k.split('|'); return { color, size: Number(size) }; });
}
