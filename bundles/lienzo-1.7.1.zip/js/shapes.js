// Biblioteca de formas (trazados en una caja de 100×100) y pegatinas emoji, por categorías.
const P = (pts) => 'M' + pts.map(([x, y]) => `${+x.toFixed(2)},${+y.toFixed(2)}`).join(' L') + ' Z';
const reg = (n, rot = -90, r = 50) => P(Array.from({ length: n }, (_, i) => {
  const a = ((rot + (360 / n) * i) * Math.PI) / 180;
  return [50 + Math.cos(a) * r, 50 + Math.sin(a) * r];
}));
const star = (n, inner = 0.45, rot = -90) => P(Array.from({ length: n * 2 }, (_, i) => {
  const a = ((rot + (180 / n) * i) * Math.PI) / 180, r = i % 2 ? 50 * inner : 50;
  return [50 + Math.cos(a) * r, 50 + Math.sin(a) * r];
}));

export const SHAPES = [
  // Básicas
  { id: 'rect', name: 'Rectángulo', cat: 'Básicas', d: 'M0,0 H100 V100 H0 Z' },
  { id: 'rrect', name: 'Rectángulo redondeado', cat: 'Básicas', d: 'M16,0 H84 Q100,0 100,16 V84 Q100,100 84,100 H16 Q0,100 0,84 V16 Q0,0 16,0 Z' },
  { id: 'ellipse', name: 'Círculo', cat: 'Básicas', d: 'M50,0 A50,50 0 1,1 49.99,0 Z' },
  { id: 'triangle', name: 'Triángulo', cat: 'Básicas', d: 'M50,0 L100,100 L0,100 Z' },
  { id: 'rtriangle', name: 'Triángulo rectángulo', cat: 'Básicas', d: 'M0,0 L100,100 L0,100 Z' },
  { id: 'diamond', name: 'Rombo', cat: 'Básicas', d: 'M50,0 L100,50 L50,100 L0,50 Z' },
  { id: 'pentagon', name: 'Pentágono', cat: 'Básicas', d: reg(5) },
  { id: 'hexagon', name: 'Hexágono', cat: 'Básicas', d: reg(6, 0) },
  { id: 'octagon', name: 'Octógono', cat: 'Básicas', d: reg(8, 22.5) },
  { id: 'parallelogram', name: 'Paralelogramo', cat: 'Básicas', d: 'M22,0 H100 L78,100 H0 Z' },
  { id: 'trapezoid', name: 'Trapecio', cat: 'Básicas', d: 'M22,0 H78 L100,100 H0 Z' },
  { id: 'star5', name: 'Estrella', cat: 'Básicas', d: star(5, 0.42) },
  { id: 'star4', name: 'Destello', cat: 'Básicas', d: star(4, 0.32) },
  { id: 'star6', name: 'Estrella de seis puntas', cat: 'Básicas', d: star(6, 0.55) },
  { id: 'burst', name: 'Explosión', cat: 'Básicas', d: star(12, 0.72) },
  { id: 'heart', name: 'Corazón', cat: 'Básicas', d: 'M50,96 C20,72 0,55 0,30 C0,12 13,0 28,0 C39,0 46,6 50,15 C54,6 61,0 72,0 C87,0 100,12 100,30 C100,55 80,72 50,96 Z' },
  { id: 'cross', name: 'Cruz', cat: 'Básicas', d: 'M35,0 H65 V35 H100 V65 H65 V100 H35 V65 H0 V35 H35 Z' },
  { id: 'crescent', name: 'Luna', cat: 'Básicas', d: 'M62,2 A50,50 0 1,0 98,62 A40,40 0 1,1 62,2 Z' },
  { id: 'ring', name: 'Anillo', cat: 'Básicas', d: 'M50,0 A50,50 0 1,1 49.99,0 Z M50,24 A26,26 0 1,0 50.01,24 Z' },
  // Flechas
  { id: 'arrowR', name: 'Flecha derecha', cat: 'Flechas', d: 'M0,30 H60 V5 L100,50 L60,95 V70 H0 Z' },
  { id: 'arrowL', name: 'Flecha izquierda', cat: 'Flechas', d: 'M100,30 H40 V5 L0,50 L40,95 V70 H100 Z' },
  { id: 'arrowU', name: 'Flecha arriba', cat: 'Flechas', d: 'M30,100 V40 H5 L50,0 L95,40 H70 V100 Z' },
  { id: 'arrowD', name: 'Flecha abajo', cat: 'Flechas', d: 'M30,0 V60 H5 L50,100 L95,60 H70 V0 Z' },
  { id: 'arrowLR', name: 'Flecha doble', cat: 'Flechas', d: 'M0,50 L28,10 V32 H72 V10 L100,50 L72,90 V68 H28 V90 Z' },
  { id: 'chevron', name: 'Galón', cat: 'Flechas', d: 'M0,0 H65 L100,50 L65,100 H0 L35,50 Z' },
  { id: 'pentArrow', name: 'Etiqueta flecha', cat: 'Flechas', d: 'M0,0 H70 L100,50 L70,100 H0 Z' },
  { id: 'uturn', name: 'Flecha en U', cat: 'Flechas', d: 'M15,100 V40 A35,35 0 0,1 85,40 V55 H100 L72,90 L44,55 H60 V40 A10,10 0 0,0 40,40 V100 Z' },
  { id: 'circArrow', name: 'Flecha circular', cat: 'Flechas', d: 'M50,8 A42,42 0 1,1 13,30 L27,37 A27,27 0 1,0 50,23 V36 L22,15 L50,-6 Z' },
  // Diagramas
  { id: 'process', name: 'Proceso', cat: 'Diagramas', d: 'M0,0 H100 V100 H0 Z', deco: 'M10,0 V100 M90,0 V100' },
  { id: 'decision', name: 'Decisión', cat: 'Diagramas', d: 'M50,0 L100,50 L50,100 L0,50 Z' },
  { id: 'terminal', name: 'Inicio/fin', cat: 'Diagramas', d: 'M25,0 H75 A25,50 0 0,1 75,100 H25 A25,50 0 0,1 25,0 Z' },
  { id: 'document', name: 'Documento', cat: 'Diagramas', d: 'M0,0 H100 V85 C75,70 50,100 25,90 C12,86 5,85 0,88 Z' },
  { id: 'database', name: 'Base de datos', cat: 'Diagramas', d: 'M0,14 A50,14 0 0,1 100,14 V86 A50,14 0 0,1 0,86 Z', deco: 'M0,14 A50,14 0 0,0 100,14' },
  { id: 'cube', name: 'Cubo', cat: 'Diagramas', d: 'M0,25 L25,0 H100 V75 L75,100 H0 Z', deco: 'M0,25 H75 V100 M75,25 L100,0' },
  { id: 'callout', name: 'Bocadillo', cat: 'Diagramas', d: 'M8,0 H92 Q100,0 100,8 V62 Q100,70 92,70 H40 L18,95 L24,70 H8 Q0,70 0,62 V8 Q0,0 8,0 Z' },
  { id: 'bubble', name: 'Globo de diálogo', cat: 'Diagramas', d: 'M50,0 C80,0 100,17 100,40 C100,63 80,80 50,80 C44,80 38,79 33,78 L12,98 L18,72 C7,65 0,53 0,40 C0,17 20,0 50,0 Z' },
  { id: 'thought', name: 'Pensamiento', cat: 'Diagramas', d: 'M25,22 C25,5 50,0 58,12 C68,0 92,6 90,24 C104,30 102,55 88,58 C92,74 70,82 60,72 C50,84 26,80 26,68 C8,70 0,50 12,42 C2,32 12,18 25,22 Z M14,84 A6,6 0 1,1 13.99,84 Z M5,96 A3.5,3.5 0 1,1 4.99,96 Z' },
  { id: 'cloud', name: 'Nube', cat: 'Diagramas', d: 'M25,85 C10,85 0,75 0,62 C0,48 12,40 22,42 C22,22 38,10 55,14 C68,2 92,12 90,32 C100,36 100,48 100,55 C100,72 90,85 75,85 Z' },
  { id: 'banner', name: 'Pancarta', cat: 'Diagramas', d: 'M0,20 H100 L88,50 L100,80 H0 L12,50 Z' },
  { id: 'tag', name: 'Etiqueta', cat: 'Diagramas', d: 'M0,10 Q0,0 10,0 H70 L100,50 L70,100 H10 Q0,100 0,90 Z M72,42 A8,8 0 1,1 71.99,42 Z' },
  { id: 'frame', name: 'Marco', cat: 'Diagramas', d: 'M0,0 H100 V100 H0 Z M12,12 V88 H88 V12 Z' },
  // Objetos y símbolos
  { id: 'bolt', name: 'Rayo', cat: 'Símbolos', d: 'M60,0 L10,58 H45 L35,100 L90,38 H55 Z' },
  { id: 'drop', name: 'Gota', cat: 'Símbolos', d: 'M50,0 C70,30 88,50 88,66 A38,34 0 0,1 12,66 C12,50 30,30 50,0 Z' },
  { id: 'check', name: 'Visto', cat: 'Símbolos', d: 'M0,55 L14,41 L36,63 L86,13 L100,27 L36,91 Z' },
  { id: 'xmark', name: 'Equis', cat: 'Símbolos', d: 'M0,15 L15,0 L50,35 L85,0 L100,15 L65,50 L100,85 L85,100 L50,65 L15,100 L0,85 L35,50 Z' },
  { id: 'pin', name: 'Ubicación', cat: 'Símbolos', d: 'M50,100 C30,70 12,52 12,36 A38,36 0 0,1 88,36 C88,52 70,70 50,100 Z M50,20 A15,15 0 1,0 50.01,20 Z' },
  { id: 'house', name: 'Casa', cat: 'Símbolos', d: 'M50,0 L100,45 H86 V100 H60 V68 H40 V100 H14 V45 H0 Z' },
  { id: 'shield', name: 'Escudo', cat: 'Símbolos', d: 'M50,0 L95,15 V45 C95,72 75,90 50,100 C25,90 5,72 5,45 V15 Z' },
  { id: 'flag', name: 'Bandera', cat: 'Símbolos', d: 'M5,0 H15 V100 H5 Z M15,5 C40,-5 60,20 95,8 V58 C60,70 40,45 15,55 Z' },
  { id: 'sun', name: 'Sol', cat: 'Símbolos', d: star(12, 0.7) + ' M50,22 A28,28 0 1,0 50.01,22 Z' },
  { id: 'gear', name: 'Engranaje', cat: 'Símbolos', d: (() => {
    const pts = []; const n = 8;
    for (let i = 0; i < n * 4; i++) { const a = (i / (n * 4)) * Math.PI * 2; const r = (i % 4 < 2) ? 50 : 38; pts.push([50 + Math.cos(a) * r, 50 + Math.sin(a) * r]); }
    return P(pts) + ' M50,34 A16,16 0 1,0 50.01,34 Z';
  })() },
  { id: 'puzzle', name: 'Pieza de puzle', cat: 'Símbolos', d: 'M0,20 H32 A12,12 0 1,1 56,20 H80 V44 A12,12 0 1,1 80,68 V100 H0 V68 A12,12 0 1,0 0,44 Z' },
  { id: 'bookmark', name: 'Marcador', cat: 'Símbolos', d: 'M15,0 H85 V100 L50,74 L15,100 Z' },
  { id: 'bulb', name: 'Bombilla', cat: 'Símbolos', d: 'M50,0 A36,36 0 0,1 72,64 V78 H28 V64 A36,36 0 0,1 50,0 Z M30,84 H70 V92 H30 Z M38,95 H62 V100 H38 Z' },
  { id: 'smile', name: 'Cara', cat: 'Símbolos', d: 'M50,0 A50,50 0 1,1 49.99,0 Z M32,30 A7,7 0 1,0 32.01,30 Z M68,30 A7,7 0 1,0 68.01,30 Z M25,58 Q50,88 75,58 Q50,74 25,58 Z' },
];

export const SHAPE_CATS = ['Básicas', 'Flechas', 'Diagramas', 'Símbolos'];
export const shapeById = (id) => SHAPES.find((s) => s.id === id);

export const EMOJI = {
  'Caras': '😀 😃 😄 😁 😆 😅 🤣 😂 🙂 😉 😊 😇 🥰 😍 🤩 😘 😋 😜 🤪 🤔 🤨 😐 😑 😶 🙄 😏 😬 😌 😴 🤯 🥳 😎 🤓 😕 😟 😮 😲 😳 🥺 😢 😭 😱 😤 😡 🤬 👍 👎 👏 🙌 🙏 💪 👀 🧠 ❤️ 🔥 ✨ 💯',
  'Animales': '🐶 🐱 🐭 🐹 🐰 🦊 🐻 🐼 🐨 🐯 🦁 🐮 🐷 🐸 🐵 🐔 🐧 🐦 🐤 🦆 🦅 🦉 🐴 🦄 🐝 🦋 🐌 🐞 🐢 🐍 🦖 🐙 🦀 🐠 🐬 🐳 🦈 🐘 🦒 🐿️',
  'Naturaleza': '🌵 🎄 🌲 🌳 🌴 🌱 🌿 🍀 🍁 🍂 🌷 🌹 🌺 🌸 🌼 🌻 🌞 🌝 🌙 ⭐ 🌟 ⚡ 🌈 ☀️ ⛅ ☁️ 🌧️ ⛈️ ❄️ ☃️ 🌊 💧 🌍 🔥',
  'Comida': '🍏 🍎 🍐 🍊 🍋 🍌 🍉 🍇 🍓 🍒 🍑 🥭 🍍 🥥 🥝 🍅 🥑 🥦 🥕 🌽 🥐 🍞 🧀 🥚 🍳 🥓 🍔 🍟 🍕 🌭 🌮 🍝 🍣 🍦 🍩 🍪 🎂 🍫 ☕ 🍵 🍺 🍷',
  'Actividades': '⚽ 🏀 🏈 ⚾ 🎾 🏐 🏓 🏸 🥊 🏋️ 🚴 🏃 🧘 🏊 🎯 🎮 🎲 🧩 🎨 🎬 🎤 🎧 🎸 🎹 🥁 🏆 🥇 🎉 🎁 🎈',
  'Viajes': '🚗 🚕 🚌 🚓 🚑 🚒 🚚 🚜 🏍️ 🚲 🛴 🚂 ✈️ 🚀 🛸 🚁 ⛵ 🚢 ⚓ 🗺️ 🧭 🏔️ 🏕️ 🏖️ 🏝️ 🏠 🏢 🏰 🗼 🗽',
  'Objetos': '⌚ 📱 💻 ⌨️ 🖥️ 🖨️ 📷 🎥 📺 📻 ⏰ ⌛ 💡 🔦 🔋 🔌 💰 💳 💎 🔧 🔨 ⚙️ 🧲 🔑 🔒 📌 📍 📎 ✂️ 🖊️ ✏️ 📝 📁 📅 📈 📉 📊 📋 📚 📖 🔖 ✉️ 📦 🛒',
  'Símbolos': '✅ ☑️ ❌ ❎ ➕ ➖ ❓ ❗ ‼️ ⚠️ 🚫 ⛔ 🔴 🟠 🟡 🟢 🔵 🟣 ⚫ ⚪ 🟥 🟧 🟨 🟩 🟦 🟪 ⬛ ⬜ ⬆️ ➡️ ⬇️ ⬅️ 🔄 🔝 🆕 🆗 💬 💭 🗯️ 🔔 🎵 ♻️ ⭕ 💲',
};
