// Geometría: cajas, rotaciones, anclajes de conectores y detección de toques.
const RAD = Math.PI / 180;

export function rotPt(x, y, cx, cy, deg) {
  if (!deg) return { x, y };
  const a = deg * RAD, c = Math.cos(a), s = Math.sin(a);
  const dx = x - cx, dy = y - cy;
  return { x: cx + dx * c - dy * s, y: cy + dx * s + dy * c };
}

export const center = (it) => ({ x: it.x + it.w / 2, y: it.y + it.h / 2 });

export function corners(it) {
  const c = center(it);
  return [[it.x, it.y], [it.x + it.w, it.y], [it.x + it.w, it.y + it.h], [it.x, it.y + it.h]].map(([x, y]) => rotPt(x, y, c.x, c.y, it.rot || 0));
}

/** Punto del mundo -> coordenadas locales del elemento (sin rotación, origen en su esquina). */
export function toLocal(it, px, py) {
  const c = center(it);
  const p = rotPt(px, py, c.x, c.y, -(it.rot || 0));
  return { x: p.x - it.x, y: p.y - it.y };
}

export function bboxOfPoints(pts) {
  let x1 = Infinity, y1 = Infinity, x2 = -Infinity, y2 = -Infinity;
  for (const p of pts) { x1 = Math.min(x1, p.x); y1 = Math.min(y1, p.y); x2 = Math.max(x2, p.x); y2 = Math.max(y2, p.y); }
  return { x: x1, y: y1, w: x2 - x1, h: y2 - y1 };
}

export function aabb(it, map) {
  if (it.type === 'line') {
    const g = lineGeom(it, map);
    return bboxOfPoints(g.samples);
  }
  if (!it.rot) return { x: it.x, y: it.y, w: it.w, h: it.h };
  return bboxOfPoints(corners(it));
}

export function unionBox(boxes) {
  if (!boxes.length) return null;
  let x1 = Infinity, y1 = Infinity, x2 = -Infinity, y2 = -Infinity;
  for (const b of boxes) { x1 = Math.min(x1, b.x); y1 = Math.min(y1, b.y); x2 = Math.max(x2, b.x + b.w); y2 = Math.max(y2, b.y + b.h); }
  return { x: x1, y: y1, w: x2 - x1, h: y2 - y1 };
}

export const boxesIntersect = (a, b) => a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
export const boxContains = (a, b) => b.x >= a.x && b.y >= a.y && b.x + b.w <= a.x + a.w && b.y + b.h <= a.y + a.h;

export function distToSeg(px, py, ax, ay, bx, by) {
  const dx = bx - ax, dy = by - ay;
  const l2 = dx * dx + dy * dy;
  let t = l2 ? ((px - ax) * dx + (py - ay) * dy) / l2 : 0;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
}

export function pointInPoly(x, y, poly) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i++) {
    const xi = poly[i].x, yi = poly[i].y, xj = poly[j].x, yj = poly[j].y;
    if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}

// Conectores ---------------------------------------------------------------
export const CONNECTABLE = new Set(['note', 'shape', 'text', 'image', 'video', 'file', 'link', 'table', 'emoji', 'audio']);

/** Punto de anclaje en el centro de un lado (con rotación) y su normal hacia fuera. */
export function anchor(it, side) {
  const c = center(it);
  const local = { top: [it.w / 2, 0, 0, -1], right: [it.w, it.h / 2, 1, 0], bottom: [it.w / 2, it.h, 0, 1], left: [0, it.h / 2, -1, 0] }[side];
  const p = rotPt(it.x + local[0], it.y + local[1], c.x, c.y, it.rot || 0);
  const n = rotPt(local[2], local[3], 0, 0, it.rot || 0);
  return { x: p.x, y: p.y, nx: n.x, ny: n.y };
}

function bestSide(it, tx, ty) {
  let best = 'right', bd = Infinity;
  for (const s of ['top', 'right', 'bottom', 'left']) {
    const a = anchor(it, s);
    const d = Math.hypot(tx - a.x, ty - a.y) - ((tx - a.x) * a.nx + (ty - a.y) * a.ny) * 0.5;
    if (d < bd) { bd = d; best = s; }
  }
  return best;
}

/** Posición real de un extremo de una línea. */
export function endPoint(line, end, map) {
  const e = line[end];
  const other = line[end === 'a' ? 'b' : 'a'];
  const target = e?.id ? map.get(e.id) : null;
  if (!target) return { x: e?.x ?? 0, y: e?.y ?? 0, nx: 0, ny: 0, free: true };
  let otherPt;
  const ot = other?.id ? map.get(other.id) : null;
  otherPt = ot ? center(ot) : { x: other?.x ?? 0, y: other?.y ?? 0 };
  const side = e.side || bestSide(target, otherPt.x, otherPt.y);
  return anchor(target, side);
}

/** Geometría completa de un conector: trazado SVG, puntos de muestreo y tangentes de los extremos. */
export function lineGeom(line, map) {
  const A = endPoint(line, 'a', map), B = endPoint(line, 'b', map);
  const style = line.style || 'curved';
  let d, samples;
  if (style === 'straight' || (A.free && B.free && style === 'curved' && !line.bend)) {
    d = `M${A.x},${A.y} L${B.x},${B.y}`;
    samples = [A, B];
    return { A, B, d, samples, angA: Math.atan2(A.y - B.y, A.x - B.x), angB: Math.atan2(B.y - A.y, B.x - A.x) };
  }
  if (style === 'elbow') {
    const pts = elbow(A, B);
    d = 'M' + pts.map((p) => `${p.x},${p.y}`).join(' L');
    const n = pts.length;
    return { A, B, d, samples: pts, angA: Math.atan2(pts[0].y - pts[1].y, pts[0].x - pts[1].x), angB: Math.atan2(pts[n - 1].y - pts[n - 2].y, pts[n - 1].x - pts[n - 2].x) };
  }
  const len = Math.hypot(B.x - A.x, B.y - A.y);
  const k = Math.max(30, len * 0.4);
  let c1, c2;
  if (A.free && B.free) {
    const mx = (A.x + B.x) / 2, my = (A.y + B.y) / 2, nx = -(B.y - A.y) / (len || 1), ny = (B.x - A.x) / (len || 1);
    const bx = mx + nx * (line.bend || 0), by = my + ny * (line.bend || 0);
    c1 = { x: A.x + (bx - A.x) * 0.66, y: A.y + (by - A.y) * 0.66 };
    c2 = { x: B.x + (bx - B.x) * 0.66, y: B.y + (by - B.y) * 0.66 };
  } else {
    const dirA = A.free ? norm(B.x - A.x, B.y - A.y) : { x: A.nx, y: A.ny };
    const dirB = B.free ? norm(A.x - B.x, A.y - B.y) : { x: B.nx, y: B.ny };
    c1 = { x: A.x + dirA.x * k, y: A.y + dirA.y * k };
    c2 = { x: B.x + dirB.x * k, y: B.y + dirB.y * k };
  }
  d = `M${A.x},${A.y} C${c1.x},${c1.y} ${c2.x},${c2.y} ${B.x},${B.y}`;
  samples = [];
  for (let i = 0; i <= 24; i++) {
    const t = i / 24, u = 1 - t;
    samples.push({ x: u * u * u * A.x + 3 * u * u * t * c1.x + 3 * u * t * t * c2.x + t * t * t * B.x, y: u * u * u * A.y + 3 * u * u * t * c1.y + 3 * u * t * t * c2.y + t * t * t * B.y });
  }
  return { A, B, d, samples, angA: Math.atan2(A.y - c1.y, A.x - c1.x), angB: Math.atan2(B.y - c2.y, B.x - c2.x) };
}

function norm(x, y) { const l = Math.hypot(x, y) || 1; return { x: x / l, y: y / l }; }

function elbow(A, B) {
  const g = 24;
  const a1 = { x: A.x + A.nx * g, y: A.y + A.ny * g };
  const b1 = { x: B.x + B.nx * g, y: B.y + B.ny * g };
  const horizA = A.free ? Math.abs(B.x - A.x) > Math.abs(B.y - A.y) : Math.abs(A.nx) > 0;
  const mid = horizA ? [{ x: (a1.x + b1.x) / 2, y: a1.y }, { x: (a1.x + b1.x) / 2, y: b1.y }] : [{ x: a1.x, y: (a1.y + b1.y) / 2 }, { x: b1.x, y: (a1.y + b1.y) / 2 }];
  const pts = [A];
  if (!A.free) pts.push(a1);
  pts.push(...mid);
  if (!B.free) pts.push(b1);
  pts.push(B);
  return pts;
}

export function distToPolyline(px, py, pts) {
  let d = Infinity;
  for (let i = 1; i < pts.length; i++) d = Math.min(d, distToSeg(px, py, pts[i - 1].x, pts[i - 1].y, pts[i].x, pts[i].y));
  return d;
}

/** ¿El punto (mundo) toca el elemento? tol en unidades de mundo. */
export function hit(it, px, py, tol, map) {
  if (it.type === 'line') return distToPolyline(px, py, lineGeom(it, map).samples) <= tol + (it.width || 2) / 2;
  const l = toLocal(it, px, py);
  if (l.x < -tol || l.y < -tol || l.x > it.w + tol || l.y > it.h + tol) return false;
  if (it.type === 'ink') {
    const sx = it.vw / it.w, sy = it.vh / it.h;
    const lx = l.x * sx, ly = l.y * sy;
    const r = (it.size || 3) / 2 + tol * Math.max(sx, sy) + 2;
    const p = it.pts;
    if (p.length === 3) return Math.hypot(lx - p[0], ly - p[1]) <= r;
    for (let i = 3; i < p.length; i += 3) if (distToSeg(lx, ly, p[i - 3], p[i - 2], p[i], p[i + 1]) <= r) return true;
    return false;
  }
  return true;
}

/** Puntos del trazo en coordenadas del mundo. */
export function inkWorldPoints(it) {
  const sx = it.w / it.vw, sy = it.h / it.vh, c = center(it), out = [];
  for (let i = 0; i < it.pts.length; i += 3) out.push(rotPt(it.x + it.pts[i] * sx, it.y + it.pts[i + 1] * sy, c.x, c.y, it.rot || 0));
  return out;
}

/** Simplificación Ramer–Douglas–Peucker. */
export function rdp(pts, eps) {
  if (pts.length < 3) return pts;
  let maxD = 0, idx = 0;
  const a = pts[0], b = pts[pts.length - 1];
  for (let i = 1; i < pts.length - 1; i++) {
    const d = distToSeg(pts[i].x, pts[i].y, a.x, a.y, b.x, b.y);
    if (d > maxD) { maxD = d; idx = i; }
  }
  if (maxD <= eps) return [a, b];
  return [...rdp(pts.slice(0, idx + 1), eps).slice(0, -1), ...rdp(pts.slice(idx), eps)];
}
