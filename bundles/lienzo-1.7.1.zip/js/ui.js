// Componentes de interfaz: popovers, menús, diálogos, avisos y selector de color.
import { h, icon, clamp, hslToHex, hexToRgb, rgbToHex } from './util.js';

const layer = () => document.getElementById('overlay');
const stack = [];

export function closeAllPopovers() { while (stack.length) stack[stack.length - 1].close(); }
export const popoverOpen = () => stack.length > 0;
export function closeTopPopover() { if (!stack.length) return false; stack[stack.length - 1].close(); return true; }

/**
 * Muestra un popover junto a un elemento o rectángulo.
 * placement: 'below' | 'above' | 'auto'
 */
export function popover(anchor, content, { placement = 'auto', className = '', onClose, modal = false, keep = false } = {}) {
  if (!keep) closeAllPopovers();
  const scrim = h('div.pop-scrim' + (modal ? '.modal' : ''));
  const box = h('div.popover' + (className ? '.' + className.split(' ').join('.') : ''), {}, content);
  const arrow = h('div.pop-arrow');
  box.append(arrow);
  layer().append(scrim, box);
  const rect = anchor instanceof Element ? anchor.getBoundingClientRect() : anchor;
  const place = () => {
    const vw = innerWidth, vh = innerHeight, m = 10;
    const bw = box.offsetWidth, bh = box.offsetHeight;
    let below = placement === 'below' || (placement === 'auto' && rect.bottom + bh + 14 < vh) || (placement === 'auto' && rect.top - bh - 14 < 0 && vh - rect.bottom > rect.top);
    if (placement === 'above') below = false;
    let top = below ? rect.bottom + 12 : rect.top - bh - 12;
    top = clamp(top, m + (parseFloat(getComputedStyle(document.documentElement).getPropertyValue('--sat')) || 0), vh - bh - m);
    const cx = rect.left + rect.width / 2;
    const left = clamp(cx - bw / 2, m, vw - bw - m);
    box.style.left = left + 'px';
    box.style.top = top + 'px';
    arrow.className = 'pop-arrow ' + (below ? 'up' : 'down');
    arrow.style.left = clamp(cx - left - 8, 14, bw - 30) + 'px';
  };
  place();
  requestAnimationFrame(() => box.classList.add('in'));
  const api = {
    el: box,
    place,
    close() {
      const i = stack.indexOf(api);
      if (i < 0) return;
      stack.splice(i, 1);
      box.remove(); scrim.remove();
      onClose?.();
    },
  };
  scrim.addEventListener('pointerdown', (e) => { e.preventDefault(); api.close(); });
  stack.push(api);
  new ResizeObserver(() => place()).observe(box);
  return api;
}

/** Menú contextual. items: [{label, icon, act, danger, disabled, checked, sep, sub}] */
export function menu(anchor, items, opts = {}) {
  const list = h('div.menu');
  let api;
  for (const it of items) {
    if (!it) continue;
    if (it.sep) { list.append(h('div.menu-sep')); continue; }
    if (it.row) {
      const row = h('div.menu-row');
      for (const b of it.row) row.append(h('button.menu-chip' + (b.danger ? '.danger' : ''), { onclick: () => { api.close(); b.act(); }, title: b.label }, h('span', { html: icon(b.icon, 20) }), h('small', { text: b.label })));
      list.append(row);
      continue;
    }
    const btn = h('button.menu-item' + (it.danger ? '.danger' : '') + (it.disabled ? '.disabled' : ''), {
      onclick: () => { if (it.disabled) return; if (!it.stay) api.close(); it.act?.(); },
    }, h('span.lbl', { text: it.label }), it.checked != null ? h('span.chk', { html: it.checked ? icon('check', 18) : '' }) : null, it.icon ? h('span.mi', { html: icon(it.icon, 19) }) : null);
    list.append(btn);
  }
  api = popover(anchor, list, { className: 'menu-pop', ...opts });
  return api;
}

export function toast(msg, ms = 2200) {
  const t = h('div.toast', { text: msg });
  layer().append(t);
  requestAnimationFrame(() => t.classList.add('in'));
  setTimeout(() => { t.classList.remove('in'); setTimeout(() => t.remove(), 300); }, ms);
}

export function dialog(build) {
  return new Promise((resolve) => {
    const scrim = h('div.dlg-scrim');
    const box = h('div.dialog');
    const done = (v) => { scrim.remove(); stack.splice(stack.indexOf(api), 1); resolve(v); };
    const api = { close: () => done(null), el: box };
    stack.push(api);
    build(box, done);
    scrim.append(box);
    layer().append(scrim);
    requestAnimationFrame(() => scrim.classList.add('in'));
  });
}

export function prompt(title, value = '', { placeholder = '', ok = 'Aceptar', message = '' } = {}) {
  return dialog((box, done) => {
    const inp = h('input.dlg-input', { value, placeholder, enterkeyhint: 'done' });
    inp.addEventListener('keydown', (e) => { if (e.key === 'Enter') done(inp.value.trim()); if (e.key === 'Escape') done(null); });
    box.append(h('h3', { text: title }), message ? h('p', { text: message }) : null, inp,
      h('div.dlg-btns', {}, h('button.btn', { text: 'Cancelar', onclick: () => done(null) }), h('button.btn.primary', { text: ok, onclick: () => done(inp.value.trim()) })));
    setTimeout(() => { inp.focus(); inp.select(); }, 60);
  });
}

export function confirm(title, message = '', { ok = 'Aceptar', danger = false } = {}) {
  return dialog((box, done) => {
    box.append(h('h3', { text: title }), message ? h('p', { text: message }) : null,
      h('div.dlg-btns', {}, h('button.btn', { text: 'Cancelar', onclick: () => done(false) }), h('button.btn.primary' + (danger ? '.danger' : ''), { text: ok, onclick: () => done(true) })));
  });
}

// Selector de color ----------------------------------------------------------
export const SYSTEM_COLORS = ['#000000', '#8E8E93', '#FFFFFF', '#FF3B30', '#FF9500', '#FFCC00', '#34C759', '#00C7BE', '#007AFF', '#5856D6', '#AF52DE', '#FF2D55', '#A2845E'];

const GRID_HUES = [195, 210, 230, 260, 290, 330, 0, 15, 30, 42, 52, 78];
const GRID_L = [18, 27, 36, 45, 54, 64, 74, 84, 92];
function gridColors() {
  const rows = [];
  const gray = []; for (let i = 0; i < 12; i++) { const v = Math.round(255 - (255 * i) / 11); gray.push(rgbToHex(v, v, v)); }
  rows.push(gray);
  for (const l of GRID_L) rows.push(GRID_HUES.map((hh) => hslToHex(hh, l > 85 ? 85 : 100, l)));
  return rows;
}

function recentColors() { try { return JSON.parse(localStorage.getItem('lienzo.recentColors') || '[]'); } catch { return []; } }
function pushRecent(c) {
  try {
    const r = [c, ...recentColors().filter((x) => x !== c)].slice(0, 12);
    localStorage.setItem('lienzo.recentColors', JSON.stringify(r));
  } catch { /* sin almacenamiento */ }
}

/** Abre el selector de color. onChange(color) se llama en cada cambio. */
export function colorPicker(anchor, { value = '#000000', onChange, allowNone = false, title = 'Colores', keep = true } = {}) {
  let tab = (() => { try { return localStorage.getItem('lienzo.colorTab') || 'grid'; } catch { return 'grid'; } })();
  let current = value;
  const root = h('div.cpick');
  const set = (c, commit = true) => {
    current = c; onChange?.(c);
    if (commit && c !== 'none') pushRecent(c);
    preview.style.background = c === 'none' ? 'var(--none-bg)' : c;
    hex.value = c === 'none' ? '' : c.toUpperCase();
    root.querySelectorAll('.sw').forEach((s) => s.classList.toggle('on', s.dataset.c === c));
  };
  const head = h('div.cp-head', {}, h('b', { text: title }));
  const tabs = h('div.seg');
  const body = h('div.cp-body');
  for (const [k, l] of [['grid', 'Cuadrícula'], ['spectrum', 'Espectro'], ['sliders', 'Reguladores']]) {
    tabs.append(h('button' + (k === tab ? '.on' : ''), { text: l, onclick: (e) => { tab = k; try { localStorage.setItem('lienzo.colorTab', k); } catch { /* */ } tabs.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b === e.currentTarget)); draw(); } }));
  }
  const preview = h('div.cp-prev');
  const hex = h('input.cp-hex', { maxlength: 7, placeholder: '#RRGGBB', spellcheck: 'false' });
  hex.addEventListener('change', () => { const v = hex.value.trim(); if (/^#?[0-9a-f]{6}$/i.test(v)) set((v[0] === '#' ? v : '#' + v).toUpperCase()); });
  const recents = h('div.cp-recent');

  function draw() {
    body.innerHTML = '';
    if (tab === 'grid') {
      const g = h('div.cp-grid');
      for (const row of gridColors()) for (const c of row) g.append(h('button.sw', { 'data-c': c, style: { background: c }, onclick: () => set(c) }));
      body.append(g);
    } else if (tab === 'spectrum') {
      const cv = h('canvas.cp-spec', { width: 300, height: 180 });
      const ctx = cv.getContext('2d');
      const gh = ctx.createLinearGradient(0, 0, 300, 0);
      for (let i = 0; i <= 12; i++) gh.addColorStop(i / 12, `hsl(${i * 30},100%,50%)`);
      ctx.fillStyle = gh; ctx.fillRect(0, 0, 300, 180);
      const gv = ctx.createLinearGradient(0, 0, 0, 180);
      gv.addColorStop(0, 'rgba(255,255,255,1)'); gv.addColorStop(0.5, 'rgba(255,255,255,0)'); gv.addColorStop(0.5, 'rgba(0,0,0,0)'); gv.addColorStop(1, 'rgba(0,0,0,1)');
      ctx.fillStyle = gv; ctx.fillRect(0, 0, 300, 180);
      const pick = (e) => {
        const r = cv.getBoundingClientRect();
        const x = clamp(((e.clientX - r.left) / r.width) * 300, 0, 299), y = clamp(((e.clientY - r.top) / r.height) * 180, 0, 179);
        const d = ctx.getImageData(x, y, 1, 1).data;
        set(rgbToHex(d[0], d[1], d[2]), false);
      };
      cv.addEventListener('pointerdown', (e) => { try { cv.setPointerCapture(e.pointerId); } catch { /* */ } pick(e); });
      cv.addEventListener('pointermove', (e) => { if (e.buttons) pick(e); });
      cv.addEventListener('pointerup', () => pushRecent(current));
      body.append(cv);
    } else {
      const [r0, g0, b0] = current === 'none' ? [0, 0, 0] : hexToRgb(current);
      const vals = { R: r0, G: g0, B: b0 };
      for (const k of ['R', 'G', 'B']) {
        const out = h('span.sl-val', { text: vals[k] });
        const inp = h('input.sl', { type: 'range', min: 0, max: 255, value: vals[k] });
        inp.style.setProperty('--sl', k === 'R' ? '#FF3B30' : k === 'G' ? '#34C759' : '#007AFF');
        inp.addEventListener('input', () => { vals[k] = +inp.value; out.textContent = inp.value; set(rgbToHex(vals.R, vals.G, vals.B), false); });
        inp.addEventListener('change', () => pushRecent(current));
        body.append(h('label.sl-row', {}, h('b', { text: k }), inp, out));
      }
    }
    set(current, false);
  }

  const sys = h('div.cp-sys');
  for (const c of SYSTEM_COLORS) sys.append(h('button.sw.round', { 'data-c': c, style: { background: c }, onclick: () => set(c) }));
  if (allowNone) sys.prepend(h('button.sw.round.none', { 'data-c': 'none', title: 'Sin color', onclick: () => set('none') }));
  const rc = recentColors();
  if (rc.length) { recents.append(h('small', { text: 'Recientes' })); const rr = h('div.cp-sys'); for (const c of rc) rr.append(h('button.sw.round', { 'data-c': c, style: { background: c }, onclick: () => set(c) })); recents.append(rr); }

  root.append(head, tabs, body, h('div.cp-foot', {}, preview, hex), sys, recents);
  draw();
  return popover(anchor, root, { className: 'cp-pop', keep });
}

/** Botón redondo que muestra un color (para barras contextuales). */
export function swatchBtn(color, onclick, title = 'Color') {
  const b = h('button.ctx-btn.swatch-btn', { title, onclick });
  b.append(h('span.swatch-dot', { style: { background: color === 'none' ? 'var(--none-bg)' : color } }));
  return b;
}

export function segmented(options, value, onChange) {
  const s = h('div.seg');
  for (const o of options) {
    s.append(h('button' + (o.value === value ? '.on' : ''), {
      html: o.icon ? icon(o.icon, 18) : '', title: o.label,
      onclick: (e) => { s.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b === e.currentTarget)); onChange(o.value); },
    }, o.icon ? null : o.label));
  }
  return s;
}

export function slider({ min, max, step = 1, value, onInput, onChange, label, fmt = (v) => v }) {
  const out = h('span.sl-val', { text: fmt(value) });
  const inp = h('input.sl', { type: 'range', min, max, step, value });
  inp.addEventListener('input', () => { out.textContent = fmt(+inp.value); onInput?.(+inp.value); });
  inp.addEventListener('change', () => onChange?.(+inp.value));
  return h('label.sl-row', {}, label ? h('b', { text: label }) : null, inp, out);
}
