// Guías inteligentes (como en Freeform/Keynote): al mover o cambiar de tamaño, el objeto se ajusta
// a los bordes y centros de lo que hay alrededor (y al centro de la página en los cuadernos), y a la
// misma separación que hay entre otros objetos. Las guías muestran cuándo algo está alineado o centrado.
import * as G from './geom.js';

/** Caja real de un elemento (la de los trazos sin el margen que llevan alrededor). */
export function tightBox(it, map) {
  if (it.type !== 'ink') return G.aabb(it, map);
  const b = G.bboxOfPoints(G.inkWorldPoints(it));
  const r = ((it.size || 2) * Math.sqrt((it.w / it.vw) * (it.h / it.vh))) / 2;
  return { x: b.x - r, y: b.y - r, w: b.w + r * 2, h: b.h + r * 2 };
}

const AX = {
  x: { pos: 'x', size: 'w', cross: 'y', crossSize: 'h' },
  y: { pos: 'y', size: 'h', cross: 'x', crossSize: 'w' },
};
const lo = (b, a) => b[AX[a].pos], hi = (b, a) => b[AX[a].pos] + b[AX[a].size], mid = (b, a) => b[AX[a].pos] + b[AX[a].size] / 2;

/**
 * Alineación en un eje. which: qué partes del objeto pueden ajustarse ('lo', 'mid', 'hi').
 * Bordes con bordes y centros con centros (mezclarlos da guías confusas).
 */
function alignAxis(box, targets, a, th, which) {
  let best = null;
  const mine = { lo: lo(box, a), mid: mid(box, a), hi: hi(box, a) };
  for (const t of targets) {
    for (const k of which) {
      const opts = k === 'mid' ? [['mid', mid(t, a)]] : [['lo', lo(t, a)], ['hi', hi(t, a)]];
      for (const [tk, v] of opts) {
        if (t.page && tk !== 'mid') continue; // de la página solo interesa el centro
        const d = v - mine[k];
        if (Math.abs(d) < th && (!best || Math.abs(d) < Math.abs(best.d) - 0.01)) best = { d, v, center: k === 'mid' };
      }
    }
  }
  return best;
}

/** Misma separación: entre dos vecinos, o siguiendo la que ya hay entre dos objetos. */
function spacingAxis(box, targets, a, th) {
  const { cross, crossSize } = AX[a];
  const overlaps = (t, b) => t[cross] < b[cross] + b[crossSize] && t[cross] + t[crossSize] > b[cross];
  const row = targets.filter((t) => !t.page && overlaps(t, box));
  const before = row.filter((t) => hi(t, a) <= lo(box, a) + th).sort((p, q) => hi(q, a) - hi(p, a));
  const after = row.filter((t) => lo(t, a) >= hi(box, a) - th).sort((p, q) => lo(p, a) - lo(q, a));
  const L = before[0], R = after[0];
  const cands = [];
  const size = box[AX[a].size];
  if (L && R) {
    const ideal = (hi(L, a) + lo(R, a) - size) / 2;
    if (ideal >= hi(L, a)) cands.push({ d: ideal - lo(box, a), pairs: [[L, null], [null, R]] });
  }
  if (L) {
    const L2 = row.filter((t) => t !== L && hi(t, a) <= lo(L, a) + 0.5 && overlaps(t, L)).sort((p, q) => hi(q, a) - hi(p, a))[0];
    if (L2) { const g = lo(L, a) - hi(L2, a); cands.push({ d: hi(L, a) + g - lo(box, a), pairs: [[L2, L], [L, null]] }); }
  }
  if (R) {
    const R2 = row.filter((t) => t !== R && lo(t, a) >= hi(R, a) - 0.5 && overlaps(t, R)).sort((p, q) => lo(p, a) - lo(q, a))[0];
    if (R2) { const g = lo(R2, a) - hi(R, a); cands.push({ d: lo(R, a) - g - hi(box, a), pairs: [[null, R], [R, R2]] }); }
  }
  let best = null;
  for (const c of cands) if (Math.abs(c.d) < th && (!best || Math.abs(c.d) < Math.abs(best.d))) best = c;
  return best;
}

/** Guías para dibujar con el objeto ya en su sitio. */
function describe(box, targets, a, res, th) {
  const out = [];
  if (!res) return out;
  const { cross, crossSize } = AX[a];
  if (res.pairs) {
    // Segmentos de separación: [izquierda, derecha] (null = el propio objeto).
    for (const [p, q] of res.pairs) {
      const A = p || box, B = q || box;
      const from = hi(A, a), to = lo(B, a);
      const c0 = Math.max(A[cross], B[cross]), c1 = Math.min(A[cross] + A[crossSize], B[cross] + B[crossSize]);
      out.push({ kind: 'gap', axis: a, from, to, at: (c0 + c1) / 2, len: to - from });
    }
    return out;
  }
  // Línea de alineación: abarca el objeto y todo lo que está alineado en ese valor.
  const v = res.v;
  const hits = targets.filter((t) => [lo(t, a), mid(t, a), hi(t, a)].some((x) => Math.abs(x - v) < 0.5));
  let c0 = box[cross], c1 = box[cross] + box[crossSize];
  for (const t of hits) { c0 = Math.min(c0, t[cross]); c1 = Math.max(c1, t[cross] + t[crossSize]); }
  out.push({ kind: 'line', axis: a, v, from: c0, to: c1, center: res.center, page: hits.some((t) => t.page) });
  void th;
  return out;
}

/**
 * Ajusta una caja en movimiento. Devuelve { dx, dy, guides, centered }.
 * centered: el objeto está centrado (en los dos ejes) respecto a otro objeto o a la página.
 */
export function snapMove(box, targets, th) {
  const res = {};
  for (const a of ['x', 'y']) {
    const al = alignAxis(box, targets, a, th, ['mid', 'lo', 'hi']); // con empate, mejor el centro
    const sp = spacingAxis(box, targets, a, th);
    res[a] = al && (!sp || Math.abs(al.d) <= Math.abs(sp.d) + 0.5) ? al : sp;
  }
  const dx = res.x?.d || 0, dy = res.y?.d || 0;
  const moved = { ...box, x: box.x + dx, y: box.y + dy };
  const guides = [...describe(moved, targets, 'x', res.x, th), ...describe(moved, targets, 'y', res.y, th)];
  // «Centrado»: los dos centros coinciden con los de un mismo objeto (o con la página).
  const cx = mid(moved, 'x'), cy = mid(moved, 'y');
  const centerOf = targets.find((t) => Math.abs(mid(t, 'x') - cx) < 0.5 && Math.abs(mid(t, 'y') - cy) < 0.5);
  const centeredH = guides.some((g) => g.kind === 'line' && g.axis === 'x' && g.center);
  return { dx, dy, guides, centered: centerOf ? 'both' : centeredH && targets.some((t) => t.page && Math.abs(mid(t, 'x') - cx) < 0.5) ? 'page' : null };
}

/** Ajuste al cambiar de tamaño: solo los bordes que se están arrastrando. */
export function snapEdges(box, targets, th, edges) {
  const out = { x: 0, y: 0, guides: [] };
  for (const a of ['x', 'y']) {
    const which = edges[a];
    if (!which) continue;
    const al = alignAxis(box, targets, a, th, [which]);
    if (!al) continue;
    out[a] = al.d;
    const b2 = { ...box };
    if (which === 'lo') { b2[AX[a].pos] += al.d; b2[AX[a].size] -= al.d; } else b2[AX[a].size] += al.d;
    out.guides.push(...describe(b2, targets, a, al, th));
  }
  return out;
}
