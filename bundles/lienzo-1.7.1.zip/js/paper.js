// Cuadernos: tamaño de página, plantillas de papel (rayado, cuadrícula, Cornell…) y colores de papel.
// Las plantillas se describen como trazados SVG para pintarlas igual en pantalla y al exportar.

export const PAGE_GAP = 48;
export const PAGE_SIZES = {
  portrait: { w: 794, h: 1123, name: 'Vertical' },   // A4 a 96 ppp
  landscape: { w: 1123, h: 794, name: 'Horizontal' },
};

export const TEMPLATES = [
  { id: 'blank', name: 'En blanco' },
  { id: 'lines', name: 'Rayado' },
  { id: 'narrow', name: 'Rayado estrecho' },
  { id: 'grid', name: 'Cuadrícula' },
  { id: 'dots', name: 'Puntos' },
  { id: 'cornell', name: 'Cornell' },
  { id: 'todo', name: 'Lista de tareas' },
  { id: 'music', name: 'Pentagrama' },
];
export const templateName = (id) => TEMPLATES.find((t) => t.id === id)?.name || 'En blanco';

export const PAPER_COLORS = [
  { id: 'white', name: 'Blanco', light: '#FFFFFF', dark: '#232325' },
  { id: 'cream', name: 'Crema', light: '#FBF6E9', dark: '#2A2722' },
  { id: 'grey', name: 'Gris', light: '#F1F1F4', dark: '#2C2C2F' },
  { id: 'blue', name: 'Azul', light: '#EFF5FC', dark: '#1F2630' },
];

export function paperColor(id, dark) {
  const c = PAPER_COLORS.find((p) => p.id === id) || PAPER_COLORS[0];
  return dark ? c.dark : c.light;
}

/** Colores de las líneas de la plantilla. */
export function inkOf(dark) {
  return dark
    ? { line: 'rgba(170, 195, 235, .22)', strong: 'rgba(255, 120, 110, .4)', dot: 'rgba(235, 235, 245, .3)', frame: 'rgba(235, 235, 245, .3)' }
    : { line: 'rgba(70, 120, 190, .3)', strong: 'rgba(255, 59, 48, .38)', dot: 'rgba(60, 60, 67, .34)', frame: 'rgba(60, 60, 67, .34)' };
}

const r1 = (n) => Math.round(n * 10) / 10;

/**
 * Geometría de una plantilla para una página w×h.
 * Devuelve { line, strong, frame, dots, dotR }: trazados finos, de margen, de marco y puntos (trazado de puntos).
 */
export function templateGeometry(tpl, w, h) {
  let line = '', strong = '', frame = '', dots = '';
  const hlines = (x0, x1, y0, y1, step) => { for (let y = y0; y <= y1 + 0.01; y += step) line += `M${r1(x0)} ${r1(y)}H${r1(x1)}`; };
  switch (tpl) {
    case 'lines': {
      hlines(0, w, 128, h - 48, 32);
      strong += `M96 0V${h}`;
      break;
    }
    case 'narrow': hlines(0, w, 96, h - 40, 24); break;
    case 'grid': {
      const s = 18.9; // 5 mm
      const ox = (w % s) / 2, oy = (h % s) / 2;
      for (let x = ox; x <= w; x += s) line += `M${r1(x)} 0V${h}`;
      for (let y = oy; y <= h; y += s) line += `M0 ${r1(y)}H${w}`;
      break;
    }
    case 'dots': {
      const s = 24;
      const ox = (w % s) / 2 || s / 2, oy = (h % s) / 2 || s / 2;
      for (let y = oy; y <= h; y += s) for (let x = ox; x <= w; x += s) dots += `M${r1(x)} ${r1(y)}h.01`;
      break;
    }
    case 'cornell': {
      const top = Math.round(h * 0.12), bottom = Math.round(h * 0.8), cue = Math.round(w * 0.29);
      hlines(0, w, top + 32, bottom - 16, 32);
      frame += `M0 ${top}H${w}M${cue} ${top}V${bottom}M0 ${bottom}H${w}`;
      break;
    }
    case 'todo': {
      const step = 40;
      for (let y = 112; y <= h - 40; y += step) {
        line += `M28 ${y}H${w - 28}`;
        frame += `M44 ${y - 27}h16v16h-16Z`;
      }
      break;
    }
    case 'music': {
      const gap = 10, stave = gap * 4, stride = stave + 58;
      for (let y = 88; y + stave <= h - 48; y += stride) {
        for (let k = 0; k < 5; k++) frame += `M56 ${y + k * gap}H${w - 56}`;
        frame += `M56 ${y}V${y + stave}M${w - 56} ${y}V${y + stave}`;
      }
      break;
    }
    default: break;
  }
  return { line, strong, frame, dots };
}

/** SVG de la plantilla (sin el fondo, que va en el propio div de la página). */
export function templateSVG(tpl, w, h, dark) {
  const g = templateGeometry(tpl, w, h), c = inkOf(dark);
  return `<svg class="page-tpl" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}" fill="none" stroke-linecap="round">` +
    (g.line ? `<path d="${g.line}" stroke="${c.line}" stroke-width="1"/>` : '') +
    (g.frame ? `<path d="${g.frame}" stroke="${c.frame}" stroke-width="1.2"/>` : '') +
    (g.strong ? `<path d="${g.strong}" stroke="${c.strong}" stroke-width="1.2"/>` : '') +
    (g.dots ? `<path d="${g.dots}" stroke="${c.dot}" stroke-width="2.6"/>` : '') +
    '</svg>';
}

/** Pinta la plantilla en un canvas (exportación y miniaturas). El contexto ya está en coordenadas de la página. */
export function drawTemplate(ctx, tpl, w, h, colorId) {
  ctx.save();
  ctx.fillStyle = paperColor(colorId, false);
  ctx.fillRect(0, 0, w, h);
  const g = templateGeometry(tpl, w, h), c = inkOf(false);
  ctx.lineCap = 'round';
  const stroke = (d, color, width) => { if (!d) return; ctx.strokeStyle = color; ctx.lineWidth = width; ctx.stroke(new Path2D(d)); };
  stroke(g.line, c.line, 1);
  stroke(g.frame, c.frame, 1.2);
  stroke(g.strong, c.strong, 1.2);
  stroke(g.dots, c.dot, 2.6);
  ctx.restore();
}

/** Miniatura pequeña de una plantilla (para elegirla). */
export function templatePreview(tpl, orient = 'portrait', colorId = 'white') {
  const { w, h } = PAGE_SIZES[orient];
  return `<svg viewBox="0 0 ${w} ${h}" class="tpl-prev"><rect width="${w}" height="${h}" fill="${paperColor(colorId, false)}"/>${templateSVG(tpl, w, h, false).replace(/stroke-width="1(\.2)?"/g, 'stroke-width="5"').replace('stroke-width="2.6"', 'stroke-width="9"').replace(/rgba\((\d+), (\d+), (\d+), \.(\d+)\)/g, 'rgba($1, $2, $3, .7)')}</svg>`;
}
