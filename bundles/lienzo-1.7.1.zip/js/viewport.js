// Vista del lienzo infinito: desplazamiento, zoom (10 %–400 %) y fondo de puntos/cuadrícula.
import { clamp } from './util.js';

export const MIN_Z = 0.1, MAX_Z = 4;

export class Viewport {
  constructor(el, world, onChange) {
    this.el = el; this.world = world; this.onChange = onChange;
    this.x = 0; this.y = 0; this.z = 1;
    this.bg = 'dots';
    this.anim = null;
    this.bounds = null;   // (x, y, z) => {x, y}: límites de desplazamiento (cuadernos)
  }

  set(x, y, z, silent) {
    this.z = clamp(z, MIN_Z, MAX_Z);
    // En un cuaderno la vista no se sale de las páginas.
    if (this.bounds) ({ x, y } = this.bounds(x, y, this.z));
    this.x = x; this.y = y;
    this.apply();
    if (!silent) this.onChange?.();
  }

  apply() {
    // Desplazamiento redondeado a píxeles físicos: evita texto y trazos borrosos.
    const dpr = window.devicePixelRatio || 1;
    const tx = Math.round(this.x * dpr) / dpr, ty = Math.round(this.y * dpr) / dpr;
    this.world.style.transform = `translate(${tx}px,${ty}px) scale(${this.z})`;
    // Durante el gesto el navegador mueve una imagen ya pintada (fluido); al parar, se repinta nítido al zoom real.
    this.el.classList.add('moving');
    clearTimeout(this._still);
    this._still = setTimeout(() => this.el.classList.remove('moving'), 140);
    // Fondo: la cuadrícula se agranda al alejar para no saturar.
    let step = 24 * this.z;
    while (step < 12) step *= 4;
    const s = this.el.style;
    s.backgroundSize = `${step}px ${step}px`;
    s.backgroundPosition = `${this.x}px ${this.y}px`;
    this.el.dataset.bg = this.bg;
    this.el.style.setProperty('--z', this.z);
    this.el.style.setProperty('--iz', 1 / this.z);
  }

  setBg(bg) { this.bg = bg; this.apply(); }

  rect() { return this.el.getBoundingClientRect(); }

  toWorld(cx, cy) {
    const r = this.rect();
    return { x: (cx - r.left - this.x) / this.z, y: (cy - r.top - this.y) / this.z };
  }
  toScreen(wx, wy) {
    const r = this.rect();
    return { x: wx * this.z + this.x + r.left, y: wy * this.z + this.y + r.top };
  }

  /** Zoom manteniendo fijo un punto de pantalla. */
  zoomAt(cx, cy, z) {
    const r = this.rect();
    const nz = clamp(z, MIN_Z, MAX_Z);
    const wx = (cx - r.left - this.x) / this.z, wy = (cy - r.top - this.y) / this.z;
    this.set(cx - r.left - wx * nz, cy - r.top - wy * nz, nz);
  }

  /** Centro visible en coordenadas de mundo. */
  center() { const r = this.rect(); return this.toWorld(r.left + r.width / 2, r.top + r.height / 2); }

  visibleBox() {
    const r = this.rect();
    const a = this.toWorld(r.left, r.top), b = this.toWorld(r.right, r.bottom);
    return { x: a.x, y: a.y, w: b.x - a.x, h: b.y - a.y };
  }

  /** Encaja una caja del mundo en pantalla (con margen) y la anima. */
  fit(box, { pad = 60, maxZ = 1, animate = true, insets = { top: 70, bottom: 40, left: 0, right: 0 } } = {}) {
    if (!box) return;
    const r = this.rect();
    const aw = r.width - pad * 2 - insets.left - insets.right, ah = r.height - pad * 2 - insets.top - insets.bottom;
    const z = clamp(Math.min(aw / Math.max(box.w, 1), ah / Math.max(box.h, 1), maxZ), MIN_Z, MAX_Z);
    const x = insets.left + pad + (aw - box.w * z) / 2 - box.x * z;
    const y = insets.top + pad + (ah - box.h * z) / 2 - box.y * z;
    if (animate) this.animateTo(x, y, z); else this.set(x, y, z);
  }

  /** Vista a partir de una escena guardada (centro + zoom). */
  showScene(sc, animate = true) {
    const r = this.rect();
    const z = clamp(sc.z, MIN_Z, MAX_Z);
    const x = r.width / 2 - sc.cx * z, y = r.height / 2 - sc.cy * z;
    if (animate) this.animateTo(x, y, z, 520); else this.set(x, y, z);
  }

  animateTo(x, y, z, ms = 380) {
    cancelAnimationFrame(this.anim);
    const sx = this.x, sy = this.y, sz = this.z, t0 = performance.now();
    // Interpolación en espacio logarítmico para que el zoom se sienta natural.
    const step = (t) => {
      const k = Math.min(1, (t - t0) / ms), e = 1 - Math.pow(1 - k, 3);
      const zz = Math.exp(Math.log(sz) + (Math.log(z) - Math.log(sz)) * e);
      // Mantiene la trayectoria del punto central coherente.
      const r = this.rect();
      const c0x = (r.width / 2 - sx) / sz, c0y = (r.height / 2 - sy) / sz;
      const c1x = (r.width / 2 - x) / z, c1y = (r.height / 2 - y) / z;
      const cx = c0x + (c1x - c0x) * e, cy = c0y + (c1y - c0y) * e;
      this.set(r.width / 2 - cx * zz, r.height / 2 - cy * zz, zz, k < 1);
      if (k < 1) this.anim = requestAnimationFrame(step);
    };
    this.anim = requestAnimationFrame(step);
  }

  stopAnim() { cancelAnimationFrame(this.anim); }
}
