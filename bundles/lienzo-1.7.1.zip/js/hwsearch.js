// Buscar en lo escrito a mano: Pizarra lee tu letra en segundo plano (con el mismo lector de «Mejorar
// letra», en la tablet y sin internet) y guarda el texto con el tablero. Para no ralentizar nada:
// solo trabaja con el tablero quieto, nunca mientras dibujas, de una línea en una línea, y cada línea
// se lee una sola vez (si no cambia, no se vuelve a leer).
import { store } from './store.js';
import * as G from './geom.js';
import { inkReady, recognizeStrokes } from './restyle.js';

const HAND_TOOLS = new Set(['pen', 'monoline', 'fountain', 'pencil']);   // el subrayador, la cera… no son texto
const boxes = new WeakMap();                                             // caja real de cada trazo (no cambian)

function inkBox(it) {
  let b = boxes.get(it);
  if (!b) { b = G.bboxOfPoints(G.inkWorldPoints(it)); boxes.set(it, b); }
  return b;
}

/** Quita tildes y mayúsculas para comparar («Fotosíntesis» = «fotosintesis»). */
export const norm = (s) => String(s || '').normalize('NFD').replace(/\p{M}/gu, '').toLowerCase();

/**
 * Agrupa los trazos en trozos de línea: letras y palabras cercanas a la misma altura (y sus tildes y puntos).
 * Usa una rejilla para comparar solo trazos vecinos (rápido aunque haya miles).
 */
export function groupHandwriting(items) {
  const inks = items.filter((i) => i.type === 'ink' && HAND_TOOLS.has(i.tool));
  if (!inks.length) return [];
  const info = inks.map((it, k) => ({ it, b: inkBox(it), k }));
  const hs = info.map((x) => x.b.h).filter((v) => v > 0).sort((a, b) => a - b);
  const letter = Math.max(4, hs[Math.floor(hs.length * 0.6)] || 10);
  const cell = letter * 3;
  const grid = new Map();
  const key = (cx, cy) => `${cx},${cy}`;
  for (const x of info) {
    // Cada trazo ocupa también el margen en el que puede unirse a otro, para que los vecinos compartan casilla.
    const mx = letter * 1.4, my = letter;
    const x0 = Math.floor((x.b.x - mx) / cell), x1 = Math.floor((x.b.x + x.b.w + mx) / cell), y0 = Math.floor((x.b.y - my) / cell), y1 = Math.floor((x.b.y + x.b.h + my) / cell);
    for (let i = x0; i <= x1; i++) for (let j = y0; j <= y1; j++) { const kk = key(i, j); if (!grid.has(kk)) grid.set(kk, []); grid.get(kk).push(x); }
  }
  const parent = info.map((_, i) => i);
  const find = (i) => { while (parent[i] !== i) i = parent[i] = parent[parent[i]]; return i; };
  const join = (a, b) => { a = find(a); b = find(b); if (a !== b) parent[a] = b; };
  const near = (A, B) => {
    const a = A.b, b = B.b;
    const big = Math.max(a.h, b.h, letter * 0.5), small = Math.min(a.h, b.h);
    const gapX = Math.max(0, Math.max(a.x, b.x) - Math.min(a.x + a.w, b.x + b.w));
    const overlapY = Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y);
    if (overlapY > Math.max(small, 1) * 0.3 && gapX < big * 1.3) return true;            // letras y palabras de la misma línea
    if (small < big * 0.45 && gapX < big * 0.4) {                                         // tildes, puntos de la «i»
      const gapY = Math.max(0, Math.max(a.y, b.y) - Math.min(a.y + a.h, b.y + b.h));
      return gapY < big * 0.7;
    }
    return false;
  };
  for (const list of grid.values()) {
    for (let i = 0; i < list.length; i++) for (let j = i + 1; j < list.length; j++) if (find(list[i].k) !== find(list[j].k) && near(list[i], list[j])) join(list[i].k, list[j].k);
  }
  const groups = new Map();
  for (const x of info) { const r = find(x.k); if (!groups.has(r)) groups.set(r, []); groups.get(r).push(x); }
  const order = new Map(items.map((it, i) => [it.id, i]));
  return [...groups.values()].map((parts) => {
    parts.sort((p, q) => order.get(p.it.id) - order.get(q.it.id));
    const box = G.unionBox(parts.map((p) => p.b));
    return { key: parts.map((p) => p.it.id).sort().join('|'), parts, box };
  });
}

export class HandIndex {
  constructor(board) {
    this.b = board;
    this.timer = null;
    this.running = false;
    this.ready = null;      // ¿lector disponible? (se mira una vez)
  }

  /** Programa una pasada cuando el tablero lleve un rato quieto. */
  schedule(ms = 2500) {
    clearTimeout(this.timer);
    this.timer = setTimeout(() => this.run(), ms);
  }

  stop() { clearTimeout(this.timer); this.stopped = true; }

  async run() {
    if (this.running || !store.meta) return;
    if (this.b.op) { this.schedule(1500); return; }           // estás dibujando: luego
    if (this.ready === null) this.ready = await inkReady();
    if (!this.ready) return;
    this.running = true; this.stopped = false;
    const boardId = store.meta.id;
    try {
      const index = store.hw || (store.hw = {});
      const groups = groupHandwriting(store.items);
      const live = new Set(groups.map((g) => g.key));
      for (const k of Object.keys(index)) if (!live.has(k)) delete index[k];   // lo borrado o cambiado
      const todo = groups.filter((g) => !(g.key in index) && g.parts.length);
      for (const g of todo) {
        if (this.stopped || store.meta?.id !== boardId) return;
        if (this.b.op) { this.schedule(1500); return; }          // has vuelto a escribir: se sigue luego
        const strokes = g.parts.map(({ it }) => G.inkWorldPoints(it).flatMap((q) => [Math.round((q.x - g.box.x) * 10) / 10, Math.round((q.y - g.box.y) * 10) / 10]));
        let text = '';
        try { text = await recognizeStrokes(strokes, g.box); } catch { /* trazo ilegible */ }
        index[g.key] = { t: text, b: [g.box.x, g.box.y, g.box.w, g.box.h].map((v) => Math.round(v)) };
        await new Promise((r) => setTimeout(r, 40));              // deja respirar a la interfaz
      }
      if (todo.length) this.b.save();
    } finally { this.running = false; }
  }

  /** Coincidencias en lo escrito a mano: [{ text, box }]. */
  search(q) {
    const nq = norm(q).trim();
    if (!nq) return [];
    return Object.values(store.hw || {}).filter((e) => e.t && norm(e.t).includes(nq)).map((e) => ({ text: e.t, box: { x: e.b[0], y: e.b[1], w: e.b[2], h: e.b[3] } }));
  }
}

/** Texto del tablero para buscar desde la galería (lo escrito a mano y lo tecleado). */
export function boardSearchText() {
  const typed = store.items.map((it) => [it.text, it.name, it.title, ...(it.cells || []).flat()].filter(Boolean).join(' ')).filter(Boolean).join(' ');
  const hand = Object.values(store.hw || {}).map((e) => e.t).filter(Boolean).join(' ');
  return norm(`${typed} ${hand}`).replace(/\s+/g, ' ').slice(0, 40000);
}
