// Editor del tablero: gestos, herramientas, selección y edición.
import { store, cloneItems } from './store.js';
import { Renderer, isDark, adaptInk } from './render.js';
import { Viewport, MIN_Z, MAX_Z } from './viewport.js';
import * as G from './geom.js';
import { inkPath, inkStyle, inkBlend, makeInk, recognize, TOOLS, ERASER_SIZES, markerPoints, markerSegment, widthFactor } from './ink.js';
import { liveInk } from './native.js';
import { settings } from './settings.js';
import { uid, clamp, h, icon, debounce, vibrate } from './util.js';
import { penPressure, learnPressure } from './penpressure.js';
import { toast, menu, closeAllPopovers, popoverOpen } from './ui.js';
import * as db from './db.js';
import { buildContextBar } from './inspector.js';
import { Palette } from './palette.js';
import * as insert from './insert.js';
import * as panels from './panels.js';
import { thumbnail, notebookThumb } from './export.js';
import * as NB from './notebook.js';
import { recordUse } from './habits.js';
import { tightBox, snapMove, snapEdges } from './guides.js';
import { frameEdgeHit, newFrame } from './frames.js';
import { HandIndex, boardSearchText } from './hwsearch.js';

const HANDLES = { nw: [0, 0], n: [0.5, 0], ne: [1, 0], e: [1, 0.5], se: [1, 1], s: [0.5, 1], sw: [0, 1], w: [0, 0.5] };
const TEXTUAL = new Set(['note', 'text', 'shape']);
const KEEP_ASPECT = new Set(['image', 'video', 'emoji', 'file', 'audio', 'link', 'frame']);
const MIN_SIZE = 12;
// Tachar con un garabato borra (como en GoodNotes). La cera y el lápiz se usan para colorear: con ellos nunca.
const SCRIBBLE_TOOLS = new Set(['pen', 'monoline', 'fountain']);

export class Board {
  constructor(app) {
    this.app = app;
    this.root = document.getElementById('board');
    this.vpEl = document.getElementById('viewport');
    this.world = document.getElementById('world');
    this.ui = document.getElementById('ui-layer');
    this.ctxbar = document.getElementById('ctxbar');
    this.vp = new Viewport(this.vpEl, this.world, () => this.onView());
    this.r = new Renderer(this.world);
    this.r.onMeasure = (id, hh) => { if (!this.editing || this.editing.id !== id) store.update(id, { h: hh }, { record: false }); else this.scheduleOverlay(); };
    this.sel = new Set();
    this.mode = 'select';
    this.pointers = new Map();
    this.ignored = new Set();
    this.op = null;
    this.multi = false;
    this.editing = null;
    this.guides = [];
    this.ruler = { cx: 0, cy: 0, ang: -20 };
    this.palette = new Palette(this);
    this.pages = new NB.Pages(this);
    this.hand = new HandIndex(this);
    this.vp.bounds = (x, y, z) => this.pages.bounds(x, y, z);
    this.live = h('div.live-layer');
    // Guardar copia el tablero entero: en tableros grandes tarda un momento, así que se espera a que levantes el
    // lápiz un instante (nunca a media palabra), con un máximo de 8 s sin guardar mientras escribes sin parar.
    const saveD = debounce(() => this.persistQuiet(), 500);
    this.save = Object.assign(() => { this.dirty = true; saveD(); }, { cancel: saveD.cancel, flush: () => this.persist() });
    this.saveThumb = debounce((force) => (!force && this.isBusy() ? this.saveThumb() : this.persistThumb()), 3000);
    // Mover o hacer zoom solo guarda la posición (en la ficha del tablero), no el tablero entero: así no da tirones.
    this.saveView = debounce(() => { if (store.meta) { store.meta.view = store.view; db.putMeta(store.meta); } }, 1200);
    store.on((info) => this.onStore(info));
    this.bind();
    // Al salir de la app (cambiar de app, bloquear la tablet) se guarda al momento: Android puede cerrarla luego.
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden || !store.meta || !this.dirty) return;
      this.save.cancel();
      this.persist();
      this.saveThumb.flush(true);
    });
  }

  // Ciclo de vida -------------------------------------------------------------
  async open(meta, content) {
    closeAllPopovers();
    this.world.innerHTML = '';
    this.r.els.clear();
    this.sel.clear();
    this.editing = null;
    this.r.editing = null;
    this.mode = 'select';
    this.multi = false;
    const blobIds = db.blobIdsOf(content?.items || []);
    db.releaseBlobURLs(new Set(blobIds));
    await Promise.all(blobIds.map((id) => db.blobURL(id)));
    store.load(meta, content);
    this.world.append(this.live);
    const nb = NB.isNotebook();
    this.root.classList.toggle('notebook', nb);
    // Cuaderno: las páginas van en el fondo del mundo (debajo de todo, y el subrayador se mezcla con sus líneas).
    this.r.floor = nb ? this.pages.layer : null;
    if (nb) this.world.prepend(this.pages.layer); else this.pages.layer.remove();
    this.vp.setBg(nb ? 'notebook' : store.bg);
    const r = this.vp.rect();
    if (store.view) {
      this.vp.set(store.view.x, store.view.y, store.view.z, true);
      // Guardado con la tablet en otra posición: se encuadra igual que se dejó.
      if (store.view.w && Math.abs(store.view.w - r.width) > 4) this.reframe(store.view.w, store.view.h, r);
    } else if (nb) NB.fitPage(this, 0, false);
    else this.vp.set(r.width / 2, r.height / 2, 1, true);
    this.vpSize = { w: r.width, h: r.height };
    this.pages.render();
    this.fillVisible();
    this.r.fillLazyIdle();
    this.updatePagePill();
    document.getElementById('b-title').querySelector('span').textContent = meta.title;
    this.palette.show(false);
    this.setMode('select');
    this.updateOverlay();
    this.updateUndo();
    this.updateZoom();
    this.ruler = { cx: r.width / 2, cy: r.height * 0.6, ang: -20 };
    this.renderRuler();
    this.hand.stopped = false;
    this.hand.schedule(1500);
  }

  async close() {
    this.hand.stop();
    if (this.editing) this.stopEditing();
    closeAllPopovers();
    panels.closeFind(this);
    this.save.cancel();
    this.saveThumb.cancel();
    await this.persist();
    await this.persistThumb();
    store.meta = null;
  }

  /** Escribiendo o borrando ahora mismo (o el lápiz acaba de levantarse): mejor no hacer trabajo pesado. */
  isBusy() { return this.op?.kind === 'draw' || this.op?.kind === 'erase' || performance.now() - (this.lastPenT || 0) < 700; }

  persistQuiet() {
    const now = performance.now();
    this.saveSince = this.saveSince || now;
    const busy = this.isBusy();
    if (busy && now - this.saveSince < 8000) { this.save(); return; }
    this.saveSince = 0;
    this.persist();
  }

  async persist() {
    if (!store.meta) return;
    this.saveSince = 0;
    this.dirty = false;
    store.view = this.viewState();
    store.meta.view = store.view;
    store.meta.updated = Date.now();
    store.meta.find = boardSearchText();   // para buscar desde la galería
    await db.saveBoard(store.meta, store.content());
  }

  async persistThumb() {
    if (!store.meta) return;
    try { store.meta.thumb = NB.isNotebook() ? await notebookThumb(store.items, store.content()) : await thumbnail(store.items); await db.putMeta(store.meta); } catch (e) { console.warn('miniatura', e); }
  }

  onStore(info) {
    if (info.reset) { this.r.sync(store.items, true); return; }
    this.r.sync(store.items);
    for (const id of [...this.sel]) if (!store.get(id)) this.sel.delete(id);
    if (info.bg && !NB.isNotebook()) this.vp.setBg(store.bg);
    if (info.pages && NB.isNotebook()) { this.pages.render(); this.updatePagePill(); }
    this.scheduleOverlay();
    this.updateUndo();
    if (!info.silent) { this.save(); this.saveThumb(); this.hand.schedule(); }
  }

  /** Dibuja los trazos pendientes de lo que se ve (y un margen alrededor, para desplazarte sin huecos). */
  fillVisible() {
    if (!this.r.lazy.size) return;
    const v = this.vp.visibleBox();
    this.r.fillLazy({ x: v.x - v.w * 0.5, y: v.y - v.h * 0.5, w: v.w * 2, h: v.h * 2 });
  }

  onView() {
    if (this.r.lazy.size && !this._fillRaf) this._fillRaf = requestAnimationFrame(() => { this._fillRaf = null; this.fillVisible(); });
    this.scheduleOverlay();
    this.updateZoom();
    if (NB.isNotebook()) { this.pages.updateVisible(); this.updatePagePill(); }
    if (store.meta) { store.view = this.viewState(); this.saveView(); }
  }

  /** Vista guardada con el tamaño de pantalla, para reencuadrarla si se abre con la tablet girada. */
  viewState() {
    const r = this.vpSize || this.vp.rect();
    return { x: this.vp.x, y: this.vp.y, z: this.vp.z, w: Math.round(r.w ?? r.width), h: Math.round(r.h ?? r.height) };
  }

  /**
   * Al girar la tablet se sigue viendo lo mismo: el mismo punto en el centro y el mismo ancho de contenido
   * (lo escrito de lado a lado sigue cabiendo entero). En un cuaderno ajustado a la página, sigue ajustado.
   */
  reframe(oldW, oldH, r = this.vp.rect()) {
    const { x, y, z } = this.vp;
    const cx = (oldW / 2 - x) / z, cy = (oldH / 2 - y) / z;
    let nz = z * (r.width / oldW);
    if (NB.isNotebook()) {
      const fitOld = NB.fitZoom(this, { width: oldW, height: oldH });
      if (Math.abs(z / fitOld - 1) < 0.04) nz = NB.fitZoom(this, r);
    }
    nz = clamp(nz, MIN_Z, MAX_Z);
    this.vp.stopAnim();
    this.vp.set(r.width / 2 - cx * nz, r.height / 2 - cy * nz, nz);
  }

  /** Cambio de tamaño del lienzo: si cambia el ancho (giro), se reencuadra; si solo la altura (teclado), no. */
  onViewportResize() {
    const r = this.vp.rect();
    if (!store.meta || !r.width || !r.height) return;
    const prev = this.vpSize;
    this.vpSize = { w: r.width, h: r.height };
    if (prev && Math.abs(prev.w - r.width) > 4) {
      this.reframe(prev.w, prev.h, r);
      // La regla se queda en el mismo sitio relativo de la pantalla.
      if (this.ruler) { this.ruler.cx *= r.width / prev.w; this.ruler.cy *= r.height / prev.h; this.renderRuler(); }
    }
  }

  get map() { return this.r.map; }
  selItems() { return [...this.sel].map((id) => store.get(id)).filter(Boolean); }

  // Modos ---------------------------------------------------------------------
  /** quiet: no mostrar aún la paleta (se muestra al levantar el lápiz, para no frenar el trazo). */
  setMode(mode, { quiet = false } = {}) {
    if (this.editing) this.stopEditing();
    this.mode = mode;
    this.syncLiveInk();
    this.root.classList.toggle('drawing', mode === 'draw');
    document.getElementById('t-draw').classList.toggle('on', mode === 'draw');
    if (quiet) this.paletteLater = true; else { this.paletteLater = false; this.palette.show(mode === 'draw'); }
    this.renderRuler();
    if (mode === 'draw' && settings.tool !== 'lasso') this.clearSel();
  }

  fingerDraws() {
    if (settings.fingerDraw === 'on') return true;
    if (settings.fingerDraw === 'off') return false;
    return !settings.penSeen;
  }

  // Selección -----------------------------------------------------------------
  expandGroups(ids) {
    const out = new Set(ids);
    const groups = new Set(ids.map((id) => store.get(id)?.group).filter(Boolean));
    if (groups.size) for (const it of store.items) if (groups.has(it.group)) out.add(it.id);
    return out;
  }

  select(ids, additive = false) {
    if (this.editing) this.stopEditing();
    const next = this.expandGroups(ids);
    if (additive) {
      const allIn = [...next].every((id) => this.sel.has(id));
      for (const id of next) allIn ? this.sel.delete(id) : this.sel.add(id);
    } else this.sel = next;
    // Al seleccionar otra cosa, lo recién colocado deja de poder moverse con el lápiz.
    if (this.fresh && ![...this.sel].every((id) => this.fresh.has(id))) this.fresh = null;
    this.updateOverlay();
  }

  /** ¿El lápiz toca algo recién colocado? Devuelve el elemento, 'sel' (dentro de una selección recién pegada) o null. */
  freshAt(w) {
    if (!this.fresh?.size) return null;
    const hit = this.hitTest(w, 'pen');
    if (hit && this.fresh.has(hit.id)) return hit;
    // Un marco recién puesto también se arrastra desde dentro, para colocarlo.
    const fr = store.items.find((i) => i.type === 'frame' && this.fresh.has(i.id) && G.boxContains(i, { x: w.x, y: w.y, w: 0, h: 0 }));
    if (fr) return fr;
    if (this.sel.size > 1 && [...this.sel].every((id) => this.fresh.has(id)) && this.insideSel(w)) return 'sel';
    return null;
  }

  /** Elementos recién colocados: mientras sigan seleccionados, el lápiz también los arrastra para ubicarlos. */
  markFresh(ids) { this.fresh = new Set(ids); }

  clearSel() {
    if (this.editing) this.stopEditing();
    this.fresh = null;
    if (!this.sel.size) return;
    this.sel.clear();
    this.updateOverlay();
  }

  selectAll() { this.select(store.items.map((i) => i.id)); }

  hitTest(w, pointerType) {
    const tol = (pointerType === 'touch' ? 10 : 5) / this.vp.z;
    const items = store.items;
    let frameHit = null;
    for (let i = items.length - 1; i >= 0; i--) {
      const it = items[i];
      // La escritura a mano no se selecciona al tocarla (como en GoodNotes): se usa el lazo.
      if (it.type === 'line' || it.type === 'ink') continue;
      // Los marcos de página solo se cogen por el borde o la etiqueta.
      if (it.type === 'frame') { if (frameEdgeHit(it, w.x, w.y, (pointerType === 'touch' ? 14 : 9) / this.vp.z)) frameHit = frameHit || it; continue; }
      if (G.hit(it, w.x, w.y, 0, this.map)) return it;
    }
    // Las líneas, al final, con más tolerancia (son finas).
    for (let i = items.length - 1; i >= 0; i--) if (items[i].type === 'line' && G.hit(items[i], w.x, w.y, tol + 6 / this.vp.z, this.map)) return items[i];
    return frameHit;
  }

  selBox() {
    const items = this.selItems();
    if (!items.length) return null;
    return G.unionBox(items.map((i) => G.aabb(i, this.map)));
  }

  // Superposición: caja de selección, tiradores y barra contextual ------------
  scheduleOverlay() {
    if (this._ovr) return;
    this._ovr = requestAnimationFrame(() => { this._ovr = null; this.updateOverlay(); });
  }

  updateOverlay() {
    const ui = this.ui;
    ui.querySelectorAll('.sel-box,.sel-outline,.guide,.hd-free').forEach((e) => e.remove());
    const items = this.selItems();
    this.root.classList.toggle('has-sel', items.length > 0);
    this.renderGuides();
    if (!items.length) { this.ctxbar.classList.remove('in'); this.ctxbar.innerHTML = ''; this._ctxKey = null; return; }
    const z = this.vp.z;
    const single = items.length === 1 ? items[0] : null;
    const moving = this.op && ['move', 'resize', 'rotate'].includes(this.op.kind);

    if (single && single.type === 'line') {
      const g = G.lineGeom(single, this.map);
      for (const [end, P] of [['a', g.A], ['b', g.B]]) {
        const s = this.vp.toScreen(P.x, P.y), r = this.vp.rect();
        ui.append(h('div.hd-free.hd-end' + (single[end]?.id ? '.attached' : ''), { 'data-h': 'e' + end, style: { left: `${s.x - r.left}px`, top: `${s.y - r.top}px` } }));
      }
      if (g.A.free && g.B.free && (single.style || 'curved') === 'curved') {
        const m = g.samples[Math.floor(g.samples.length / 2)] || { x: (g.A.x + g.B.x) / 2, y: (g.A.y + g.B.y) / 2 };
        const s = this.vp.toScreen(m.x, m.y), r = this.vp.rect();
        ui.append(h('div.hd-free.hd-bend', { 'data-h': 'bend', style: { left: `${s.x - r.left}px`, top: `${s.y - r.top}px` } }));
      }
    } else {
      // Contornos individuales cuando hay varios elementos.
      if (!single) for (const it of items) ui.append(this.boxEl(it.type === 'line' ? { ...G.aabb(it, this.map), rot: 0 } : it, 'sel-outline'));
      const target = single ? single : { ...this.selBox(), rot: 0 };
      const box = this.boxEl(target, 'sel-box' + (single?.locked ? ' locked' : '') + (this.editing ? ' editing' : ''));
      const locked = items.some((i) => i.locked);
      if (!this.editing && !locked) {
        const keys = single?.type === 'text' ? ['e', 'w', 'se', 'sw', 'ne', 'nw'] : Object.keys(HANDLES);
        const small = target.w * z < 60 || target.h * z < 60;
        for (const k of keys) {
          if (small && k.length === 1 && !(single?.type === 'text')) continue;
          box.append(h('div.hd.hd-' + k, { 'data-h': k }));
        }
        if (single?.type !== 'frame') box.append(h('div.hd-rot', { 'data-h': 'rot', html: icon('rotate-cw', 13) }));
        if (single && G.CONNECTABLE.has(single.type) && !moving) {
          for (const s of ['top', 'right', 'bottom', 'left']) box.append(h('div.hd-con.c-' + s, { 'data-h': 'c-' + s, html: icon('arrow-up', 12) }));
        }
      }
      if (locked) box.append(h('div.lock-badge', { html: icon('lock', 14) }));
      ui.append(box);
    }

    // Barra contextual.
    if (moving) { this.ctxbar.classList.remove('in'); return; }
    const key = items.map((i) => i.id).join(',') + (this.editing ? ':e' : '');
    if (key !== this._ctxKey || this._ctxDirty) {
      this.ctxbar.innerHTML = '';
      this.ctxbar.append(...buildContextBar(this, items));
      this._ctxKey = key;
      this._ctxDirty = false;
    }
    this.positionCtx();
  }

  refreshCtx() { this._ctxDirty = true; this.scheduleOverlay(); }

  positionCtx() {
    const b = this.selBox();
    if (!b) return;
    const r = this.vp.rect();
    const tl = this.vp.toScreen(b.x, b.y), br = this.vp.toScreen(b.x + b.w, b.y + b.h);
    const bar = this.ctxbar;
    bar.classList.add('in');
    const bw = bar.offsetWidth, bh = bar.offsetHeight;
    const top0 = r.top + 64;
    let y = tl.y - bh - 46;
    if (y < top0) y = br.y + 40;
    if (y + bh > r.bottom - 12 || (this.editing && window.visualViewport && y + bh > visualViewport.height - 8)) y = Math.max(top0, tl.y - bh - 46);
    if (y < top0) y = top0;
    const cx = (tl.x + br.x) / 2;
    bar.style.left = clamp(cx - bw / 2, 8, innerWidth - bw - 8) + 'px';
    bar.style.top = y + 'px';
  }

  boxEl(it, cls) {
    const z = this.vp.z, r0 = this.vp.rect();
    const c = G.center(it), s = this.vp.toScreen(c.x, c.y);
    const w = it.w * z, hh = it.h * z;
    return h('div.' + cls.split(' ').join('.'), { style: { left: `${s.x - r0.left - w / 2}px`, top: `${s.y - r0.top - hh / 2}px`, width: `${w}px`, height: `${hh}px`, transform: it.rot ? `rotate(${it.rot}deg)` : '' } });
  }

  /** Guías inteligentes: líneas de alineación (discontinuas si son de centro), separaciones iguales y «Centrado». */
  renderGuides() {
    if (!this.guides.length && !this.centered) return;
    const r = this.vp.rect();
    const S = (x, y) => { const s = this.vp.toScreen(x, y); return [Math.round(s.x - r.left) + 0.5, Math.round(s.y - r.top) + 0.5]; };
    let svg = '';
    const labels = [];
    for (const g of this.guides) {
      if (g.kind === 'line') {
        const [x1, y1] = g.axis === 'x' ? S(g.v, g.from) : S(g.from, g.v);
        const [x2, y2] = g.axis === 'x' ? S(g.v, g.to) : S(g.to, g.v);
        const ext = 10, ex = g.axis === 'y' ? ext : 0, ey = g.axis === 'x' ? ext : 0;
        svg += `<line class="gl${g.center ? ' c' : ''}" x1="${x1 - ex}" y1="${y1 - ey}" x2="${x2 + ex}" y2="${y2 + ey}"/>`;
      } else {
        const [x1, y1] = g.axis === 'x' ? S(g.from, g.at) : S(g.at, g.from);
        const [x2, y2] = g.axis === 'x' ? S(g.to, g.at) : S(g.at, g.to);
        const t = 5, tx = g.axis === 'x' ? 0 : t, ty = g.axis === 'x' ? t : 0;
        svg += `<line class="gg" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}"/><line class="gg" x1="${x1 - tx}" y1="${y1 - ty}" x2="${x1 + tx}" y2="${y1 + ty}"/><line class="gg" x1="${x2 - tx}" y1="${y2 - ty}" x2="${x2 + tx}" y2="${y2 + ty}"/>`;
        labels.push(h('div.guide.gap-label', { text: `${Math.round(g.len)}`, style: { left: `${(x1 + x2) / 2}px`, top: `${(y1 + y2) / 2}px` } }));
      }
    }
    if (svg) this.ui.append(h('div.guide.guide-svg', { html: `<svg width="${r.width}" height="${r.height}">${svg}</svg>` }));
    labels.forEach((l) => this.ui.append(l));
    if (this.centered) {
      const [x, y] = S(this.centered.x, this.centered.y);
      this.ui.append(h('div.guide.center-badge', { text: this.centered.kind === 'page' ? 'Centrado en la página' : 'Centrado', style: { left: `${x}px`, top: `${y - 30}px` } }));
    }
  }

  updateUndo() {
    document.getElementById('t-undo').disabled = !store.canUndo();
    document.getElementById('t-redo').disabled = !store.canRedo();
    this.palette.updateUndo?.();
  }

  /** Indicador «página 3 / 12» de los cuadernos. */
  updatePagePill() {
    const pill = document.getElementById('page-pill');
    if (!NB.isNotebook()) { pill.hidden = true; return; }
    pill.hidden = false;
    const t = `${NB.currentPage(this) + 1} / ${store.pages.length}`;
    if (pill.textContent !== t) pill.textContent = t;
  }

  /** El tema (claro/oscuro) cambia el color del papel. */
  onTheme() { if (NB.isNotebook()) this.pages.render(); }

  updateZoom() { document.getElementById('zoom-pill').textContent = `${Math.round(this.vp.z * 100)} %`; }

  // Eventos -------------------------------------------------------------------
  bind() {
    const vp = this.vpEl;
    vp.addEventListener('pointerdown', (e) => this.onDown(e));
    vp.addEventListener('pointermove', (e) => this.onMove(e));
    vp.addEventListener('pointerleave', (e) => { if (e.pointerType === 'pen' && !this.pointers.has(e.pointerId)) this.hideHover(); });
    // Botón lateral del S Pen leído desde Android (MainActivity), más fiable que los eventos web.
    window.__spenButton = (on) => { window.__spenDiag?.('Botón (Android)', on ? 'pulsado' : 'suelto'); this.nativeBtn = !!on; this.updatePenButton(); };
    vp.addEventListener('pointerup', (e) => this.onUp(e));
    vp.addEventListener('pointercancel', (e) => this.onUp(e, true));
    vp.addEventListener('lostpointercapture', (e) => { if (this.pointers.has(e.pointerId)) this.onUp(e, true); });
    vp.addEventListener('contextmenu', (e) => e.preventDefault());
    vp.addEventListener('wheel', (e) => this.onWheel(e), { passive: false });
    window.addEventListener('keydown', (e) => this.onKey(e));
    window.addEventListener('keyup', (e) => { if (e.code === 'Space') this.spaceDown = false; });
    window.addEventListener('resize', () => { this.scheduleOverlay(); this.renderRuler(); });
    new ResizeObserver(() => this.onViewportResize()).observe(vp);
    window.visualViewport?.addEventListener('resize', () => this.keepEditingVisible());
  }

  onWheel(e) {
    e.preventDefault();
    this.vp.stopAnim();
    if (e.ctrlKey || e.metaKey) this.vp.zoomAt(e.clientX, e.clientY, this.vp.z * Math.exp(-e.deltaY * 0.0022));
    else this.vp.set(this.vp.x - e.deltaX, this.vp.y - e.deltaY, this.vp.z);
  }

  onDown(e) {
    const t = e.target;
    const act = t.closest('[data-act]');
    if (act?.dataset.act === 'add-page') { e.preventDefault(); NB.addPage(this); return; }
    if (act) { this.itemAction(act, e); return; }
    if (this.editing && t.closest('.editing')) return;
    if (this.app.presenting && e.pointerType === 'pen') { e.preventDefault(); this.pointers.set(e.pointerId, this.ptr(e)); try { this.vpEl.setPointerCapture(e.pointerId); } catch { /* */ } this.startLaser(this.ptr(e)); return; }
    if (this.app.presenting) { this.pointers.set(e.pointerId, this.ptr(e)); try { this.vpEl.setPointerCapture(e.pointerId); } catch { /* */ } if ([...this.pointers.values()].filter((q) => q.type === 'touch').length >= 2) this.startPinch(); else this.op = { kind: 'presentPan', p: this.ptr(e) }; return; }
    e.preventDefault();
    // Rechazo de la palma: mientras el S Pen está en la pantalla, los toques de la mano se ignoran.
    const penDown = [...this.pointers.values()].some((q) => q.type === 'pen');
    if (e.pointerType === 'touch' && penDown) { this.ignored.add(e.pointerId); return; }
    // También es la palma si el S Pen está justo encima de la pantalla (o se acaba de levantar),
    // o si el contacto es muy grande. Así apoyar la mano para escribir no mueve ni selecciona nada.
    if (e.pointerType === 'touch' && settings.penSeen && !this.app.presenting) {
      // La mano apoyada mientras escribes: con el S Pen cerca o usado hace poco (1,2 s), un dedo no mueve el lienzo.
      const nearPen = performance.now() - (this.lastPenT || 0) < 1200;
      const big = Math.max(e.width || 0, e.height || 0) > 50;
      if ((nearPen || big) && !this.pointers.size) { this.ignored.add(e.pointerId); return; }
    }
    if (e.pointerType === 'pen') { this.dropTouches(); this.hideHover(); this.webBtn = penBits(e); this.updatePenButton(); if (e.pressure > 0 && this.spenBtn) this.btnContact = true; }
    if (popoverOpen()) closeAllPopovers();
    if (this.editing) this.stopEditing();
    this.vp.stopAnim();
    cancelAnimationFrame(this.momentum);
    try { this.vpEl.setPointerCapture(e.pointerId); } catch { /* sin captura */ }
    const p = this.ptr(e);
    this.pointers.set(e.pointerId, p);
    if (e.pointerType === 'pen' && !settings.penSeen) { settings.penSeen = true; toast('S Pen detectado: el dedo ahora desplaza el lienzo'); }

    const touches = [...this.pointers.values()].filter((q) => q.type === 'touch');
    if (e.pointerType === 'touch' && touches.length >= 2) {
      if (this.op?.kind === 'ruler' && t.closest('.ruler')) { this.op.second = p; return; }
      const now = performance.now(), big = Math.max(e.width || 0, e.height || 0) > 50;
      this.tapGesture = this.tapGesture && now - this.tapGesture.t0 < 300
        ? { ...this.tapGesture, count: touches.length, lastT: now, big: this.tapGesture.big || big }
        : { count: touches.length, t0: now, lastT: now, moved: false, big };
      this.startPinch();
      return;
    }
    if (e.pointerType === 'touch') { const now = performance.now(); this.tapGesture = { count: 1, t0: now, lastT: now, moved: false, big: Math.max(e.width || 0, e.height || 0) > 50 }; }
    if (this.op) return;

    const w = this.vp.toWorld(p.x, p.y);
    const hEl = t.closest('[data-h]');
    if (hEl) { this.startHandle(hEl.dataset.h, p, w); return; }
    if (t.closest('.ruler')) { this.op = { kind: 'ruler', p, start: { ...this.ruler }, id: e.pointerId }; return; }

    const isPen = e.pointerType === 'pen';
    const penEraser = isPen && (this.spenBtn || penBits(e));
    const drawInput = isPen || e.pointerType === 'mouse' || this.fingerDraws();

    if (this.mode === 'draw' && drawInput && !(e.pointerType === 'mouse' && e.button !== 0)) {
      if (penEraser) return this.startErase(p, w);
      if (this.sel.size && settings.tool === 'lasso' && this.insideSel(w)) return this.startPress(null, p, w, true);
      if (settings.tool === 'eraser') return this.startErase(p, w);
      if (settings.tool === 'lasso') return this.startLasso(p, w);
      if (settings.tool === 'laser') return this.startLaser(p);
      if (isPen) {
        const fr = this.freshAt(w);
        if (fr) return fr === 'sel' ? this.startPress(null, p, w, true) : this.startPress(fr, p, w);
        // Lápiz sobre un objeto: un toque lo selecciona; si se mueve, escribe. Justo después de escribir,
        // un toque es un punto (el de la «i», un punto final), no una selección.
        const hit = this.hitTest(w, 'pen');
        if (hit && performance.now() - (this.lastInkT || 0) > 1200) { this.op = { kind: 'penTapOrDraw', p, w, hit }; return; }
      }
      return this.startDraw(p, w);
    }

    if (e.pointerType === 'mouse' && e.button === 2) {
      const hit = this.hitTest(w, 'mouse');
      if (hit && !this.sel.has(hit.id)) this.select([hit.id]);
      this.contextMenu(p, w, hit);
      this.pointers.delete(e.pointerId);
      return;
    }
    if (e.pointerType === 'mouse' && (e.button === 1 || this.spaceDown)) { this.op = { kind: 'pan', last: p, vel: [] }; return; }

    const hit = this.hitTest(w, e.pointerType);
    // El lápiz siempre escribe (también encima de objetos seleccionados); un toque corto selecciona.
    // Para mover objetos se usa el dedo; los tiradores de tamaño y giro sí funcionan con el lápiz.
    if (isPen) {
      if (penEraser) return this.startErase(p, w);
      // Lo que acabas de colocar sí se arrastra con el lápiz, para ubicarlo.
      const fr = this.freshAt(w);
      if (fr) return fr === 'sel' ? this.startPress(null, p, w, true) : this.startPress(fr, p, w);
      this.op = { kind: 'penPending', p, w };
      return;
    }
    if (hit) return this.startPress(hit, p, w);
    if (this.sel.size > 1 && this.insideSel(w)) return this.startPress(null, p, w, true);
    if (e.pointerType === 'mouse') return this.startMarquee(p, w);
    this.op = { kind: 'emptyPress', p, w, timer: setTimeout(() => this.emptyLongPress(), 480) };
  }

  /** El S Pen toca la pantalla: descarta los toques de la mano que hubiera apoyada. */
  dropTouches() {
    const ids = [...this.pointers.values()].filter((q) => q.type === 'touch').map((q) => q.id);
    if (!ids.length) return;
    const op = this.op;
    if (op && op.p?.type !== 'pen') {
      clearTimeout(op.timer);
      if (op.kind === 'draw') this.cancelDraw();
      else if (op.prev) store.set(op.prev.items);
      this.ui.querySelectorAll('.marquee,.lasso,.eraser-cursor').forEach((el) => el.remove());
      this.guides = [];
      this.op = null;
    }
    for (const id of ids) { this.pointers.delete(id); this.ignored.add(id); }
    this.tapGesture = null;
    this.updateOverlay();
  }

  ptr(e) { return { id: e.pointerId, type: e.pointerType, x: e.clientX, y: e.clientY, sx: e.clientX, sy: e.clientY, t: performance.now(), shift: e.shiftKey, pr: e.pressure }; }

  // Botón lateral del S Pen ------------------------------------------------------------
  /** Combina el estado nativo y el de los eventos web. Mantener = goma temporal; pulsar sin tocar = alternar goma. */
  updatePenButton() {
    const on = !!(this.nativeBtn || this.webBtn);
    if (on === !!this.spenBtn) return;
    this.spenBtn = on;
    const penTouching = [...this.pointers.values()].some((q) => q.type === 'pen' && q.pr > 0);
    if (on) { this.btnT0 = performance.now(); this.btnContact = penTouching; }
    else if (!this.btnContact && performance.now() - this.btnT0 < 800 && this.root.classList.contains('active')) {
      if (this.mode !== 'draw') this.setMode('draw');
      this.palette.toggleEraser();
      toast(settings.tool === 'eraser' ? 'Borrador' : 'Lápiz', 900);
    }
    this.palette.setTempEraser(on && settings.tool !== 'eraser');
    if (this.hoverEl) this.styleHover();
  }

  // Vista previa al acercar el S Pen ---------------------------------------------------
  /**
   * Tinta en vivo nativa: se prepara con el lápiz, color y grosor actuales (solo pluma y bolígrafo opacos).
   * Se llama al acercar el lápiz y al cambiar de modo; solo avisa a Android si algo ha cambiado.
   */
  syncLiveInk() {
    const t = settings.tool, cfg = settings.tools[t];
    const on = (t === 'pen' || t === 'monoline') && (cfg?.opacity ?? 1) >= 0.999 && !this.app.presenting && !!store.meta;
    let key = 'off', opts = { on: false };
    if (on) {
      const c = this.toolConfig(t), dpr = window.devicePixelRatio || 1, z = this.vp.z;
      const curve = [];
      for (let i = 0; i <= 20; i++) curve.push(Math.round(widthFactor(c.tool, c.tip, penPressure(i / 20, c.tool)) * 1000) / 1000);
      opts = { on: true, color: adaptInk(c.color), radius: (c.size / 2) * z * dpr, curve, tipIn: c.tip === 'sn' ? c.size * 1.5 * z * dpr : 0 };
      key = JSON.stringify(opts);
    }
    if (key === this._liveKey) return;
    this._liveKey = key;
    liveInk.arm(opts).then((res) => { this.liveOk = !!res?.ok && on; });
  }

  onHover(e) {
    this.lastPenT = performance.now();
    if (!this._liveT || this.lastPenT - this._liveT > 200) { this._liveT = this.lastPenT; this.syncLiveInk(); }
    if (e.buttons & 1) return;
    const bits = penBits(e);
    if (bits !== !!this.webBtn) { this.webBtn = bits; this.updatePenButton(); }
    if (settings.hoverPreview === false || (this.app.presenting && settings.tool !== 'laser')) { this.hideHover(); return; }
    if (!this.hoverEl) { this.hoverEl = h('div.hover-prev'); this.ui.append(this.hoverEl); this.styleHover(); }
    const r = this.vp.rect();
    this.hoverEl.style.left = `${e.clientX - r.left}px`;
    this.hoverEl.style.top = `${e.clientY - r.top}px`;
    clearTimeout(this.hoverTimer);
    this.hoverTimer = setTimeout(() => this.hideHover(), 1200);
  }

  styleHover() {
    const el = this.hoverEl;
    const t = this.spenBtn ? 'eraser' : settings.tool;
    el.className = 'hover-prev hv-' + (TOOLS[t] ? 'ink' : t) + (t === 'eraser' && settings.eraserTarget === 'marker' ? ' only-marker' : '');
    let size = 8, color = '';
    if (TOOLS[t]) { size = Math.max(5, TOOLS[t].sizes[settings.tools[t].size] * 1.1 * (settings.inkScreenWidth ? 1 : this.vp.z)); color = adaptInk(settings.tools[t].color); }
    else if (t === 'eraser') size = ERASER_SIZES[settings.eraserSize ?? 1];
    else if (t === 'laser') { size = 12; color = settings.tools.laser.color; }
    el.style.width = el.style.height = `${size}px`;
    el.style.setProperty('--hc', color || 'var(--accent)');
  }

  hideHover() { clearTimeout(this.hoverTimer); this.hoverEl?.remove(); this.hoverEl = null; }

  // Puntero láser (como en GoodNotes): brilla y desaparece solo -------------------------
  startLaser(p) {
    clearTimeout(this.laserFade);
    let layer = this.vpEl.querySelector('.laser-layer');
    if (!layer) { layer = document.createElementNS('http://www.w3.org/2000/svg', 'svg'); layer.setAttribute('class', 'laser-layer'); this.vpEl.append(layer); }
    layer.classList.remove('fading');
    const g = document.createElementNS('http://www.w3.org/2000/svg', 'g');
    g.style.setProperty('--lc', settings.tools.laser.color);
    g.innerHTML = '<path class="lz-glow"/><path class="lz-main"/><path class="lz-core"/><circle class="lz-dot" r="5"/>';
    layer.append(g);
    this.op = { kind: 'laser', p, g, pts: [], mode: settings.laserMode || 'trail', layer };
    this.addLaserPoint(p.x, p.y);
  }

  addLaserPoint(cx, cy) {
    const op = this.op, r = this.vp.rect();
    op.pts.push({ x: cx - r.left, y: cy - r.top, t: performance.now() });
    if (!op.raf) op.raf = requestAnimationFrame(() => { op.raf = null; this.drawLaser(op); });
  }

  drawLaser(op) {
    let pts = op.pts;
    if (op.mode === 'dot') { const now = performance.now(); pts = pts.filter((q) => now - q.t < 220); if (!pts.length) pts = op.pts.slice(-1); }
    let d = '';
    if (pts.length) {
      d = `M${pts[0].x},${pts[0].y}`;
      for (let i = 1; i < pts.length - 1; i++) d += `Q${pts[i].x},${pts[i].y} ${(pts[i].x + pts[i + 1].x) / 2},${(pts[i].y + pts[i + 1].y) / 2}`;
      const l = pts[pts.length - 1];
      d += `L${l.x},${l.y}`;
      const dot = op.g.querySelector('.lz-dot');
      dot.setAttribute('cx', l.x); dot.setAttribute('cy', l.y);
    }
    op.g.querySelectorAll('path').forEach((pa) => pa.setAttribute('d', d));
    if (op.mode === 'dot' && this.op === op) op.raf = requestAnimationFrame(() => { op.raf = null; this.drawLaser(op); });
  }

  endLaser(op) {
    cancelAnimationFrame(op.raf);
    this.drawLaser(op);
    const layer = op.layer;
    clearTimeout(this.laserFade);
    // Si vuelves a señalar enseguida, los trazos anteriores siguen; si paras, se desvanecen.
    this.laserFade = setTimeout(() => {
      layer.classList.add('fading');
      this.laserFade = setTimeout(() => { layer.innerHTML = ''; layer.classList.remove('fading'); }, 520);
    }, op.mode === 'dot' ? 250 : 900);
  }

  insideSel(w) {
    const b = this.selBox();
    if (!b) return false;
    const pad = 8 / this.vp.z;
    return w.x >= b.x - pad && w.y >= b.y - pad && w.x <= b.x + b.w + pad && w.y <= b.y + b.h + pad;
  }

  onMove(e) {
    if (this.ignored.has(e.pointerId)) return;
    const p = this.pointers.get(e.pointerId);
    if (!p) { if (e.pointerType === 'pen') this.onHover(e); return; }
    if (p.type === 'pen') {
      this.lastPenT = performance.now();
      p.pr = e.pressure;
      const bits = penBits(e);
      if (bits !== !!this.webBtn) { this.webBtn = bits; this.updatePenButton(); }
      if (e.pressure > 0 && this.spenBtn) this.btnContact = true;
      // Botón pulsado mientras se dibuja: se convierte en goma desde ese punto.
      if (this.spenBtn && this.op?.kind === 'draw') {
        // Si el aviso del botón llegó justo después de tocar, ese trocito no se guarda como tinta.
        if (this.op.pts.length < 12 && performance.now() - this.op.t0 < 250) this.cancelDraw(); else this.endDraw(false, this.op);
        this.startErase({ ...p, sx: p.x, sy: p.y }, this.vp.toWorld(p.x, p.y));
      }
    }
    const coalesced = ['draw', 'erase', 'laser', 'lasso'].includes(this.op?.kind) ? e.getCoalescedEvents?.() : null;
    const events = coalesced?.length ? coalesced : [e];
    p.x = e.clientX; p.y = e.clientY;
    if (this.tapGesture && Math.hypot(p.x - p.sx, p.y - p.sy) > 12) this.tapGesture.moved = true;
    if (this.tapGesture && e.pointerType === 'touch' && Math.max(e.width || 0, e.height || 0) > 50) this.tapGesture.big = true;
    const op = this.op;
    if (!op) return;
    const moved = Math.hypot(p.x - p.sx, p.y - p.sy);
    const w = this.vp.toWorld(p.x, p.y);
    switch (op.kind) {
      case 'pinch': return this.movePinch();
      case 'presentPan': return;
      case 'pan': return this.movePan(p);
      case 'ruler': return this.moveRuler();
      case 'emptyPress':
        if (moved > 8) { clearTimeout(op.timer); this.op = { kind: 'pan', last: { x: op.p.x, y: op.p.y }, vel: [] }; this.movePan(p); }
        return;
      case 'marqueeArmed': if (moved > 8) this.startMarquee(op.p, op.w); return;
      case 'penPending':
        if (moved > 4) {
          if (this.mode !== 'draw') this.setMode('draw', { quiet: true });
          this.op = null;
          if (settings.tool === 'eraser') { this.startErase(op.p, op.w); this.moveErase([e]); }
          else if (settings.tool === 'laser') { this.startLaser(op.p); this.addLaserPoint(e.clientX, e.clientY); }
          else if (settings.tool === 'lasso') { this.startLasso(op.p, op.w); this.moveLasso(w); }
          else if (this.startDraw(op.p, op.w) !== false) this.moveDraw([e]);
        }
        return;
      case 'penTapOrDraw':
        if (moved > 3) { this.op = null; if (this.startDraw(op.p, op.w) !== false) this.moveDraw([e]); }
        return;
      case 'press':
        if (moved > (p.type === 'touch' ? 9 : 4)) {
          clearTimeout(op.timer);
          // Dedo que arrastra sobre un objeto sin seleccionar: era apoyarse o desplazarse, no mover el objeto.
          if (op.guarded) { this.op = { kind: 'pan', last: { x: p.sx, y: p.sy }, vel: [] }; this.movePan(p); return; }
          if (op.hit && !this.sel.has(op.hit.id)) this.select([op.hit.id], this.multi || p.shift);
          this.startMove(op.w);
          this.moveMove(w);
        }
        return;
      case 'move': return this.moveMove(w);
      case 'resize': return this.moveResize(w);
      case 'rotate': return this.moveRotate(w);
      case 'connect': return this.moveConnect(w);
      case 'endpoint': return this.moveEndpoint(w);
      case 'bend': return this.moveBend(w);
      case 'marquee': return this.moveMarquee(w);
      case 'lasso': for (const ev of events) this.moveLasso(this.vp.toWorld(ev.clientX, ev.clientY)); return;
      case 'draw': {
        // Predicción del lápiz (como Samsung Notes): se dibuja un poco por delante de la punta, solo en pantalla.
        const pred = e.pointerType === 'pen' ? e.getPredictedEvents?.() : null;
        const last = pred?.length ? pred[pred.length - 1] : null;
        op.pred = last ? this.vp.toWorld(last.clientX, last.clientY) : null;
        return this.moveDraw(events);
      }
      case 'erase': return this.moveErase(events);
      case 'laser': for (const ev of events) this.addLaserPoint(ev.clientX, ev.clientY); return;
    }
  }

  onUp(e, cancel = false) {
    if (this.ignored.delete(e.pointerId)) return;
    const p = this.pointers.get(e.pointerId);
    if (!p) return;
    this.pointers.delete(e.pointerId);
    if (p.type === 'pen') this.lastPenT = performance.now();
    if (p.type === 'pen' && this.webBtn) { this.webBtn = false; this.updatePenButton(); }
    const op = this.op;
    const remainingTouches = [...this.pointers.values()].filter((q) => q.type === 'touch').length;
    if (this.tapGesture && remainingTouches === 0 && e.pointerType === 'touch') {
      const g = this.tapGesture; this.tapGesture = null;
      // Toque con dos/tres dedos = deshacer/rehacer, pero no si parece la mano apoyada: contacto grande, dedos que
      // no llegan a la vez (la palma va tocando a trozos) o el S Pen usado hace poco (estabas escribiendo).
      const now = performance.now();
      const palmLike = g.big || g.lastT - g.t0 > 140 || (settings.penSeen && now - (this.lastPenT || 0) < 1500);
      if (!g.moved && !palmLike && g.count >= 2 && now - g.t0 < 380) {
        // Hace falta tocar DOS veces seguidas (dos dedos = deshacer, tres = rehacer): un solo toque de la mano no hace nada.
        const n = Math.min(3, g.count), prev = this.lastMultiTap;
        if (prev && prev.n === n && now - prev.t < 550) {
          this.lastMultiTap = null;
          if (n === 2) { this.undo(); toast('Deshacer', 900); } else { this.redo(); toast('Rehacer', 900); }
        } else this.lastMultiTap = { n, t: now };
        if (op?.kind === 'pinch') this.op = null;
        return;
      }
    }
    if (!op) return;
    if (op.kind === 'pinch') {
      if (remainingTouches < 2) this.op = remainingTouches === 1 ? { kind: 'idleTouch' } : null;
      return;
    }
    if (op.kind === 'idleTouch') { if (!remainingTouches) this.op = null; return; }
    if (op.kind === 'ruler') { if (op.second?.id === e.pointerId) { op.second = null; op.start = { ...this.ruler }; op.p = { ...this.pointers.get(op.id) || op.p }; op.p.sx = op.p.x; op.p.sy = op.p.y; return; } this.op = null; return; }
    if (op.p && op.p.id !== undefined && op.p.id !== e.pointerId && op.kind !== 'presentPan') return;
    this.op = null;
    const w = this.vp.toWorld(p.x, p.y);
    const moved = Math.hypot(p.x - p.sx, p.y - p.sy);
    switch (op.kind) {
      case 'presentPan': if (Math.abs(p.x - p.sx) > 60) panels.presentStep(this, p.x < p.sx ? 1 : -1); return;
      case 'pan': return this.endPan(op);
      case 'emptyPress':
        clearTimeout(op.timer);
        if (!cancel) { if (this.multi) this.setMulti(false); this.clearSel(); }
        return;
      case 'marqueeArmed': return this.contextMenu(p, op.w, null);
      case 'penTapOrDraw': if (!cancel) this.tapItem(op.hit, op.w, p); return;
      case 'penPending': {
        const hit = this.hitTest(op.w, 'pen');
        if (hit) this.tapItem(hit, op.w, p); else this.clearSel();
        return;
      }
      case 'press':
        clearTimeout(op.timer);
        if (op.longFired || cancel) return;
        if (op.hit) this.tapItem(op.hit, op.w, p); else if (moved < 6) this.clearSel();
        return;
      case 'move': return this.endMove(cancel, op);
      case 'resize': case 'rotate': case 'bend': case 'endpoint': return this.endTransform(cancel, op);
      case 'connect': return this.endConnect(op, moved, cancel);
      case 'marquee': return this.endMarquee();
      case 'lasso': this.endLasso(op); return this.showPaletteLater();
      case 'draw':
        // Si se levantó lejos del punto de pausa, no era una forma: trazo libre.
        if (op.shape && Math.hypot(e.clientX - op.lastStill.x, e.clientY - op.lastStill.y) > 12) op.shape = null;
        // Completa el trazo hasta donde se levantó el lápiz (por si el sistema descartó movimientos).
        if (!cancel && op.pts.length && !op.shape) { const l = op.pts[op.pts.length - 1], s = this.vp.toScreen(l.x, l.y); if (Math.hypot(e.clientX - s.x, e.clientY - s.y) > 3 && (e.clientX || e.clientY)) { const q = op.ruler ? projectOnLine(e.clientX, e.clientY, op.ruler) : { x: e.clientX, y: e.clientY }; const w2 = this.vp.toWorld(q.x, q.y); op.pts.push({ x: w2.x, y: w2.y, p: op.lastP ?? 0.5 }); } }
        this.endDraw(cancel, op);
        return this.showPaletteLater();
      case 'erase': this.endErase(op); return this.showPaletteLater();
      case 'laser': return this.endLaser(op);
    }
    void w;
  }

  showPaletteLater() { if (this.paletteLater) { this.paletteLater = false; if (this.mode === 'draw') this.palette.show(true); } }

  // Desplazar y zoom ------------------------------------------------------------
  startPinch() {
    const op = this.op;
    if (op?.kind === 'draw') {
      if (op.pts.length < 14 || performance.now() - op.t0 < 250) this.cancelDraw(); else this.endDraw();
    } else if (op?.kind === 'press' || op?.kind === 'emptyPress') clearTimeout(op.timer);
    else if (op && ['move', 'resize', 'rotate', 'connect', 'endpoint', 'bend'].includes(op.kind)) { if (op.kind === 'connect') this.endConnect(op, 99, false); else if (op.kind === 'move') this.endMove(); else this.endTransform(); }
    else if (op?.kind === 'marquee') this.endMarquee();
    else if (op?.kind === 'lasso') this.endLasso();
    else if (op?.kind === 'erase') this.endErase();
    const [a, b] = [...this.pointers.values()].filter((q) => q.type === 'touch');
    if (!a || !b) return;
    const cx = (a.x + b.x) / 2, cy = (a.y + b.y) / 2;
    this.op = { kind: 'pinch', a: a.id, b: b.id, d0: Math.hypot(a.x - b.x, a.y - b.y) || 1, z0: this.vp.z, w0: this.vp.toWorld(cx, cy) };
  }

  movePinch() {
    const op = this.op;
    const a = this.pointers.get(op.a), b = this.pointers.get(op.b);
    if (!a || !b) return;
    const cx = (a.x + b.x) / 2, cy = (a.y + b.y) / 2;
    const d = Math.hypot(a.x - b.x, a.y - b.y);
    let z = clamp(op.z0 * (d / op.d0), 0.1, 4);
    if (Math.abs(z - 1) < 0.04 && Math.abs(op.z0 - 1) > 0.04) z = 1; // imán al 100 %
    const r = this.vp.rect();
    this.vp.set(cx - r.left - op.w0.x * z, cy - r.top - op.w0.y * z, z);
    if (this.tapGesture && Math.abs(d - op.d0) > 14) this.tapGesture.moved = true;
  }

  movePan(p) {
    const op = this.op;
    const dx = p.x - op.last.x, dy = p.y - op.last.y;
    op.last = { x: p.x, y: p.y };
    op.vel.push({ dx, dy, t: performance.now() });
    if (op.vel.length > 6) op.vel.shift();
    this.vp.set(this.vp.x + dx, this.vp.y + dy, this.vp.z);
  }

  endPan(op) {
    // Inercia: el lienzo sigue deslizándose y frena poco a poco.
    const now = performance.now();
    const recent = op.vel.filter((v) => now - v.t < 90);
    if (recent.length < 2) return;
    const span = Math.max(16, now - recent[0].t);
    let vx = (recent.reduce((s, v) => s + v.dx, 0) / span) * 16, vy = (recent.reduce((s, v) => s + v.dy, 0) / span) * 16;
    const step = () => {
      if (Math.hypot(vx, vy) < 0.4) return;
      this.vp.set(this.vp.x + vx, this.vp.y + vy, this.vp.z);
      vx *= 0.93; vy *= 0.93;
      this.momentum = requestAnimationFrame(step);
    };
    this.momentum = requestAnimationFrame(step);
  }

  // Pulsar / tocar elementos ---------------------------------------------------------------------
  startPress(hit, p, w, onSelection = false) {
    // Con S Pen, el dedo sobre un objeto sin seleccionar no lo arrastra (apoyarse no lo mueve): desplaza el lienzo.
    // Para moverlo con el dedo: tócalo antes (queda seleccionado) o mantenlo pulsado hasta que vibre y arrástralo.
    const guarded = p.type === 'touch' && settings.penSeen && !!hit && !this.sel.has(hit.id) && !this.fresh?.has(hit.id);
    const op = { kind: 'press', hit, p, w, onSelection, guarded };
    this.op = op;
    if (!hit) return;
    const menuAfter = (ms) => setTimeout(() => {
      if (this.op !== op) return;
      op.longFired = true;
      vibrate(12);
      if (!this.sel.has(hit.id)) this.select([hit.id], this.multi);
      this.contextMenu(p, w, hit);
      this.op = null;
    }, ms);
    if (!guarded) { op.timer = menuAfter(500); return; }
    // Pulsación mantenida: el objeto se «levanta» (vibra) y ya se puede arrastrar; si no se mueve, sale el menú.
    op.timer = setTimeout(() => {
      if (this.op !== op) return;
      op.guarded = false;
      vibrate(8);
      if (!this.sel.has(hit.id)) this.select([hit.id], this.multi);
      op.timer = menuAfter(550);
    }, 320);
  }

  tapItem(hit, w, p) {
    const now = performance.now();
    const dbl = this.lastTap && this.lastTap.id === hit.id && now - this.lastTap.t < 380;
    this.lastTap = { id: hit.id, t: now };
    if (this.multi || p.shift) { this.select([hit.id], true); return; }
    const wasOnly = this.sel.size === 1 && this.sel.has(hit.id) || (this.sel.has(hit.id) && hit.group && [...this.sel].every((id) => store.get(id)?.group === hit.group));
    if (hit.group && wasOnly && this.sel.size > 1) { this.sel = new Set([hit.id]); this.updateOverlay(); return; }
    if (wasOnly && !hit.locked) {
      if (TEXTUAL.has(hit.type)) return this.startEditing(hit);
      if (hit.type === 'table') { const cell = this.cellAt(hit, w); if (cell) return this.startEditing(hit, { cell }); }
      if (dbl) return this.openItem(hit);
      return;
    }
    this.select([hit.id]);
    if (dbl && !hit.locked) this.openItem(hit);
  }

  openItem(it) {
    if (it.type === 'file' || it.type === 'link') insert.openItem(this, it);
    else if (it.type === 'video' || it.type === 'audio') this.playMedia(it.id);
    else if (it.type === 'image') insert.viewImage(it);
  }

  cellAt(it, w) {
    const l = G.toLocal(it, w.x, w.y);
    const tw = it.colW.reduce((a, b) => a + b, 0), th = it.rowH.reduce((a, b) => a + b, 0);
    let x = 0, c = -1, y = 0, r = -1;
    for (let i = 0; i < it.colW.length; i++) { x += (it.colW[i] / tw) * it.w; if (l.x <= x) { c = i; break; } }
    for (let i = 0; i < it.rowH.length; i++) { y += (it.rowH[i] / th) * it.h; if (l.y <= y) { r = i; break; } }
    return r >= 0 && c >= 0 ? { r, c } : null;
  }

  itemAction(btn, e) {
    e.preventDefault(); e.stopPropagation();
    const el = btn.closest('.item');
    if (!el) return;
    if (btn.dataset.act === 'play') this.playMedia(el.dataset.id);
    if (btn.dataset.act === 'check') { const it = store.get(el.dataset.id); if (it) store.update(it.id, { done: !it.done }); vibrate?.(8); return; }
    if (btn.dataset.act === 'transcript') panels.transcriptView(this, store.get(el.dataset.id));
  }

  playMedia(id) {
    const el = this.r.elOf(id);
    const m = el?.querySelector('video,audio');
    if (!m) return;
    if (m.paused) { m.muted = false; m.play().catch(() => toast('No se puede reproducir')); el.classList.add('playing'); el.querySelector('.media-btn').innerHTML = icon('circle-stop', 22); }
    else { m.pause(); el.classList.remove('playing'); el.querySelector('.media-btn').innerHTML = icon('play', 22); }
  }

  emptyLongPress() {
    const op = this.op;
    if (op?.kind !== 'emptyPress') return;
    vibrate(12);
    this.op = { kind: 'marqueeArmed', p: op.p, w: op.w };
  }

  setMulti(on) {
    this.multi = on;
    this.root.classList.toggle('multi', on);
    document.getElementById('multi-bar').classList.toggle('in', on);
  }

  contextMenu(p, w, hit) {
    const anchor = { left: p.x - 1, right: p.x + 1, top: p.y - 1, bottom: p.y + 1, width: 2, height: 2 };
    if (hit) {
      const items = this.selItems();
      const locked = items.some((i) => i.locked);
      menu(anchor, [
        { row: [
          { label: 'Cortar', icon: 'scissors', act: () => this.cut() },
          { label: 'Copiar', icon: 'copy', act: () => this.copy() },
          { label: 'Duplicar', icon: 'layers-2', act: () => this.duplicate() },
          { label: 'Eliminar', icon: 'trash-2', danger: true, act: () => this.deleteSel() },
        ] },
        { label: 'Seleccionar varios', icon: 'square-dashed', act: () => this.setMulti(true) },
        TEXTUAL.has(hit.type) && !locked ? { label: 'Editar texto', icon: 'type', act: () => this.startEditing(store.get(hit.id)) } : null,
        { sep: true },
        { label: 'Traer al frente', icon: 'bring-to-front', act: () => store.reorder([...this.sel], 'front') },
        { label: 'Enviar al fondo', icon: 'send-to-back', act: () => store.reorder([...this.sel], 'back') },
        items.length > 1 ? { label: items.every((i) => i.group && i.group === items[0].group) ? 'Desagrupar' : 'Agrupar', icon: 'group', act: () => this.toggleGroup() } : null,
        { label: locked ? 'Desbloquear' : 'Bloquear', icon: locked ? 'lock-open' : 'lock', act: () => this.toggleLock() },
      ]);
    } else {
      const hasClip = !!this.app.clipboard();
      menu(anchor, [
        { label: 'Pegar', icon: 'clipboard-paste', disabled: !hasClip, act: () => this.paste(w) },
        { label: 'Seleccionar todo', icon: 'square-dashed', act: () => this.selectAll() },
        { label: 'Seleccionar varios', icon: 'square-dashed', act: () => this.setMulti(true) },
        { sep: true },
        { label: 'Nota adhesiva aquí', icon: 'sticky-note', act: () => insert.addNote(this, w) },
        { label: 'Texto aquí', icon: 'type', act: () => insert.addText(this, w) },
      ]);
    }
  }

  // Mover ---------------------------------------------------------------------
  startMove(w0) {
    const ids = [...this.sel].filter((id) => !store.get(id)?.locked);
    if (!ids.length) { this.op = null; return; }
    const orig = new Map(ids.map((id) => [id, store.get(id)]));
    const map = this.map;
    const box0 = G.unionBox([...orig.values()].map((i) => tightBox(i, map)));
    this.op = { kind: 'move', prev: store.snapshot(), orig, w0, box0, others: this.guideTargets(orig), map };
    this.updateOverlay();
  }

  moveMove(w) {
    const op = this.op;
    let dx = w.x - op.w0.x, dy = w.y - op.w0.y;
    this.guides = [];
    this.centered = null;
    if (settings.snap && op.others.length) {
      const b = op.box0;
      const s = snapMove({ x: b.x + dx, y: b.y + dy, w: b.w, h: b.h }, op.others, 7 / this.vp.z);
      dx += s.dx; dy += s.dy;
      this.guides = s.guides;
      this.centered = s.centered ? { x: b.x + dx + b.w / 2, y: b.y + dy, kind: s.centered } : null;
    }
    op.dx = dx; op.dy = dy;
    store.set(store.items.map((it) => (op.orig.has(it.id) ? translated(op.orig.get(it.id), dx, dy) : it)), { silent: true });
  }

  /** Referencias para las guías: lo visible que no se mueve (con la escritura a mano) y, en un cuaderno, la página. */
  guideTargets(moving) {
    const map = this.map, vis = this.vp.visibleBox();
    const pad = Math.max(vis.w, vis.h) * 0.25;
    const area = { x: vis.x - pad, y: vis.y - pad, w: vis.w + pad * 2, h: vis.h + pad * 2 };
    const out = [];
    for (const it of store.items) {
      if (moving.has(it.id) || !G.boxesIntersect(G.aabb(it, map), area)) continue;
      out.push(tightBox(it, map));
      if (out.length >= 400) break;
    }
    if (NB.isNotebook()) { const c = this.vp.center(); out.push({ ...NB.pageRect(NB.currentPage(this)), page: true }); void c; }
    return out;
  }

  endMove(cancel, op = this.op) {
    this.op = null;
    this.guides = [];
    this.centered = null;
    if (op?.kind === 'move' || op?.prev) {
      if (cancel) store.set(op.prev.items); else store.record(op.prev);
      this.save(); this.saveThumb();
    }
    this.updateOverlay();
  }

  // Tiradores: redimensionar, rotar, conectar -------------------------------------------
  startHandle(k, p, w) {
    const items = this.selItems();
    const prev = store.snapshot();
    if (k === 'ea' || k === 'eb') { this.op = { kind: 'endpoint', end: k[1], id: items[0].id, prev, p }; return; }
    if (k === 'bend') { this.op = { kind: 'bend', id: items[0].id, prev, p }; return; }
    if (k.startsWith('c-')) {
      const from = items[0];
      const line = { id: uid(), type: 'line', a: { id: from.id, side: k.slice(2) }, b: { x: w.x, y: w.y }, style: 'curved', color: '#000000', width: 2, arrowB: 'arrow' };
      this.op = { kind: 'connect', from, side: k.slice(2), line, prev, p, w0: w };
      return;
    }
    const orig = new Map(items.map((i) => [i.id, i]));
    const box = items.length === 1 && items[0].type !== 'line' ? items[0] : { ...this.selBox(), rot: 0 };
    if (k === 'rot') {
      const c = G.center(box);
      this.op = { kind: 'rotate', orig, c, a0: Math.atan2(w.y - c.y, w.x - c.x), rot0: box.rot || 0, prev, p, single: items.length === 1 };
      return;
    }
    this.op = { kind: 'resize', k, orig, box, prev, p, single: items.length === 1 && items[0].type !== 'line', others: this.guideTargets(new Set(orig.keys())) };
  }

  moveResize(w) {
    const op = this.op;
    const [hx, hy] = HANDLES[op.k];
    const o = op.box;
    const l = G.toLocal(o, w.x, w.y);
    let x1 = 0, y1 = 0, x2 = o.w, y2 = o.h;
    if (hx === 0) x1 = Math.min(l.x, o.w - MIN_SIZE); else if (hx === 1) x2 = Math.max(l.x, MIN_SIZE);
    if (hy === 0) y1 = Math.min(l.y, o.h - MIN_SIZE); else if (hy === 1) y2 = Math.max(l.y, MIN_SIZE);
    const single = op.single ? op.orig.values().next().value : null;
    const keep = (single ? KEEP_ASPECT.has(single.type) || (single.type === 'ink' && false) : true) && hx !== 0.5 && hy !== 0.5;
    if (keep || (op.p.shift && hx !== 0.5 && hy !== 0.5)) {
      const s = Math.max((x2 - x1) / o.w, (y2 - y1) / o.h);
      const nw = o.w * s, nh = o.h * s;
      if (hx === 0) x1 = o.w - nw; else x2 = nw;
      if (hy === 0) y1 = o.h - nh; else y2 = nh;
    }
    // Guías al cambiar de tamaño: los bordes que arrastras se ajustan a los de alrededor (sin giro ni proporción fija).
    this.guides = [];
    if (settings.snap && !o.rot && !keep && !op.p.shift && op.others?.length) {
      const s = snapEdges({ x: o.x + x1, y: o.y + y1, w: x2 - x1, h: y2 - y1 }, op.others, 7 / this.vp.z, { x: hx === 0 ? 'lo' : hx === 1 ? 'hi' : null, y: hy === 0 ? 'lo' : hy === 1 ? 'hi' : null });
      if (hx === 0) x1 += s.x; else if (hx === 1) x2 += s.x;
      if (hy === 0) y1 += s.y; else if (hy === 1) y2 += s.y;
      this.guides = s.guides;
    }
    const nw = x2 - x1, nh = y2 - y1;
    const oc = G.center(o);
    const c = G.rotPt(o.x + (x1 + x2) / 2, o.y + (y1 + y2) / 2, oc.x, oc.y, o.rot || 0);
    if (single) {
      let n = { ...single, x: c.x - nw / 2, y: c.y - nh / 2, w: nw, h: single.type === 'text' ? single.h : nh };
      if (single.type === 'text') { n.x = c.x - nw / 2; n.y = single.y + (hy === 0 ? 0 : 0); const cc = G.rotPt(o.x + (x1 + x2) / 2, o.y + o.h / 2, oc.x, oc.y, o.rot || 0); n.x = cc.x - nw / 2; n.y = cc.y - single.h / 2; if (hy !== 0.5 && hx !== 0.5) n.fsize = Math.max(6, Math.round((single.fsize || 24) * (nw / o.w) * 10) / 10); }
      store.set(store.items.map((it) => (it.id === single.id ? n : it)), { silent: true });
    } else {
      const sx = nw / o.w, sy = nh / o.h, ax = o.x + (hx === 0 ? o.w : 0), ay = o.y + (hy === 0 ? o.h : 0);
      const nx0 = c.x - nw / 2, ny0 = c.y - nh / 2;
      void ax; void ay;
      store.set(store.items.map((it) => {
        const og = op.orig.get(it.id);
        if (!og) return it;
        if (og.type === 'line') {
          const f = (e) => (e.id ? e : { x: nx0 + (e.x - o.x) * sx, y: ny0 + (e.y - o.y) * sy });
          return { ...og, a: f(og.a), b: f(og.b) };
        }
        const n = { ...og, x: nx0 + (og.x - o.x) * sx, y: ny0 + (og.y - o.y) * sy, w: og.w * sx, h: og.h * sy };
        if (og.fsize && og.fsize !== 'auto') n.fsize = Math.max(6, og.fsize * Math.min(sx, sy));
        return n;
      }), { silent: true });
    }
  }

  moveRotate(w) {
    const op = this.op;
    let deg = ((Math.atan2(w.y - op.c.y, w.x - op.c.x) - op.a0) * 180) / Math.PI;
    let total = op.rot0 + deg;
    total = ((total % 360) + 360) % 360;
    for (const s of [0, 90, 180, 270, 360]) if (Math.abs(total - s) < 5) total = s % 360;
    deg = total - op.rot0;
    op.angle = total;
    const map = this.map;
    store.set(store.items.map((it) => {
      const og = op.orig.get(it.id);
      if (!og) return it;
      if (og.type === 'line') {
        const f = (e) => (e.id ? e : G.rotPt(e.x, e.y, op.c.x, op.c.y, deg));
        return { ...og, a: f(og.a), b: f(og.b) };
      }
      if (op.single) return { ...og, rot: total };
      const c = G.center(og), nc = G.rotPt(c.x, c.y, op.c.x, op.c.y, deg);
      return { ...og, x: nc.x - og.w / 2, y: nc.y - og.h / 2, rot: (((og.rot || 0) + deg) % 360 + 360) % 360 };
    }), { silent: true });
    void map;
    this.showHint(`${Math.round(total)}°`);
  }

  endTransform(cancel, op = this.op || {}) {
    this.op = null;
    this.guides = [];
    this.highlight(null);
    this.showHint(null);
    const prev = op.prev;
    if (prev) { if (cancel) store.set(prev.items); else store.record(prev); }
    this.save(); this.saveThumb();
    this.updateOverlay();
  }

  showHint(text) {
    let el = this.ui.querySelector('.hint');
    if (!text) { el?.remove(); return; }
    if (!el) { el = h('div.hint'); this.ui.append(el); }
    el.textContent = text;
  }

  moveConnect(w) {
    const op = this.op;
    const target = this.connectTarget(w, op.from.id);
    op.line = { ...op.line, b: target ? { id: target.id } : { x: w.x, y: w.y } };
    op.target = target;
    store.set([...op.prev.items, op.line], { silent: true });
    this.highlight(target);
  }

  connectTarget(w, excludeId) {
    const items = store.items;
    for (let i = items.length - 1; i >= 0; i--) {
      const it = items[i];
      if (it.id === excludeId || !G.CONNECTABLE.has(it.type)) continue;
      if (G.hit(it, w.x, w.y, 6 / this.vp.z, this.map)) return it;
    }
    return null;
  }

  highlight(it) {
    this.ui.querySelector('.target-hl')?.remove();
    if (it) this.ui.append(this.boxEl(it, 'target-hl'));
  }

  endConnect(op, moved, cancel) {
    this.highlight(null);
    if (cancel) { store.set(op.prev.items); this.updateOverlay(); return; }
    if (moved < 6) {
      // Toque: duplica el elemento hacia ese lado y lo conecta (mapas mentales rápidos).
      const from = op.from;
      const gap = 90;
      const dir = { top: [0, -1], right: [1, 0], bottom: [0, 1], left: [-1, 0] }[op.side];
      const copy = cloneItems([from], dir[0] * (from.w + gap), dir[1] * (from.h + gap))[0];
      if (TEXTUAL.has(copy.type)) copy.text = '';
      const opposite = { top: 'bottom', bottom: 'top', left: 'right', right: 'left' }[op.side];
      const line = { ...op.line, b: { id: copy.id, side: opposite } };
      store.set(op.prev.items);
      store.mutate((items) => [...items, copy, line]);
      this.select([copy.id]);
      if (TEXTUAL.has(copy.type)) this.startEditing(store.get(copy.id));
      return;
    }
    const g = G.lineGeom(op.line, this.map);
    if (!op.target && Math.hypot(g.B.x - g.A.x, g.B.y - g.A.y) < 30) { store.set(op.prev.items); this.updateOverlay(); return; }
    store.record(op.prev);
    this.select([op.line.id]);
  }

  moveEndpoint(w) {
    const op = this.op;
    const line = store.get(op.id);
    const other = line[op.end === 'a' ? 'b' : 'a'];
    const target = this.connectTarget(w, other?.id);
    const nl = { ...line, [op.end]: target ? { id: target.id } : { x: w.x, y: w.y } };
    this.highlight(target);
    store.set(store.items.map((it) => (it.id === op.id ? nl : it)), { silent: true });
  }

  moveBend(w) {
    const op = this.op;
    const line = store.get(op.id);
    const A = line.a, B = line.b;
    const mx = (A.x + B.x) / 2, my = (A.y + B.y) / 2, len = Math.hypot(B.x - A.x, B.y - A.y) || 1;
    const nx = -(B.y - A.y) / len, ny = (B.x - A.x) / len;
    const bend = ((w.x - mx) * nx + (w.y - my) * ny) * 1.33;
    store.set(store.items.map((it) => (it.id === op.id ? { ...line, bend } : it)), { silent: true });
  }

  // Selección por rectángulo y lazo ----------------------------------------------------
  startMarquee(p, w0) {
    const el = h('div.marquee');
    this.ui.append(el);
    this.op = { kind: 'marquee', p, w0, el, base: new Set(this.multi ? this.sel : []) };
  }

  moveMarquee(w) {
    const op = this.op;
    const b = { x: Math.min(op.w0.x, w.x), y: Math.min(op.w0.y, w.y), w: Math.abs(w.x - op.w0.x), h: Math.abs(w.y - op.w0.y) };
    const s = this.vp.toScreen(b.x, b.y), r = this.vp.rect();
    Object.assign(op.el.style, { left: `${s.x - r.left}px`, top: `${s.y - r.top}px`, width: `${b.w * this.vp.z}px`, height: `${b.h * this.vp.z}px` });
    // Un marco de página solo entra si el rectángulo lo abarca entero (si no, cogerías el marco al seleccionar dentro).
    const ids = store.items.filter((it) => (it.type === 'frame' ? G.boxContains(b, it) : G.boxesIntersect(G.aabb(it, this.map), b))).map((i) => i.id);
    this.sel = this.expandGroups([...op.base, ...ids]);
    this.updateOverlay();
  }

  endMarquee() { this.ui.querySelector('.marquee')?.remove(); this.op = null; this.updateOverlay(); }

  startLasso(p, w) {
    const svg = h('div.lasso', { html: '<svg><path/></svg>' });
    this.ui.append(svg);
    const r = this.vp.rect(), s = this.vp.toScreen(w.x, w.y);
    const last = { x: s.x - r.left, y: s.y - r.top };
    this.op = { kind: 'lasso', p, pts: [w], el: svg, path: svg.querySelector('path'), d: `M${last.x.toFixed(1)},${last.y.toFixed(1)}`, last, r };
  }

  // La línea sigue a la punta como un trazo de lápiz: curva suave por los puntos medios, sin cerrarse ni rellenarse
  // mientras dibujas. Se pinta una vez por fotograma.
  moveLasso(w) {
    const op = this.op;
    op.pts.push(w);
    const s = this.vp.toScreen(w.x, w.y);
    const x = s.x - op.r.left, y = s.y - op.r.top, l = op.last;
    if (Math.hypot(x - l.x, y - l.y) < 1.5) return;
    op.d += ` Q${l.x.toFixed(1)},${l.y.toFixed(1)} ${((l.x + x) / 2).toFixed(1)},${((l.y + y) / 2).toFixed(1)}`;
    op.last = { x, y };
    if (op.raf) return;
    op.raf = requestAnimationFrame(() => { op.raf = 0; op.path.setAttribute('d', `${op.d} L${op.last.x.toFixed(1)},${op.last.y.toFixed(1)}`); });
  }

  // Se coge exactamente lo que queda dentro del lazo (como en GoodNotes). Si no lo cierras, se cierra de punta a punta.
  endLasso(op = this.op || {}) {
    this.op = null;
    if (op.raf) cancelAnimationFrame(op.raf);
    this.ui.querySelector('.lasso')?.remove();
    const poly = op.pts || [];
    const lb = poly.length > 2 ? G.bboxOfPoints(poly) : null;
    if (!lb || Math.max(lb.w, lb.h) < 8 / this.vp.z) { this.clearSel(); return; }
    const inPoly = (x, y) => x >= lb.x && y >= lb.y && x <= lb.x + lb.w && y <= lb.y + lb.h && G.pointInPoly(x, y, poly);
    const share = (pts) => { let n = 0; for (const q of pts) if (inPoly(q.x, q.y)) n++; return n / (pts.length || 1); };
    const ids = [];
    for (const it of store.items) {
      const b = G.aabb(it, this.map);
      if (!G.boxesIntersect(b, { x: lb.x - 1, y: lb.y - 1, w: lb.w + 2, h: lb.h + 2 })) continue;
      let ok;
      if (it.type === 'ink') ok = this.inkInside(it, inPoly) >= 0.5;
      else if (it.type === 'frame') ok = G.corners(it).every(([x, y]) => inPoly(x, y));
      else if (it.type === 'line') ok = share(G.lineGeom(it, this.map).samples) >= 0.5;
      else ok = share(this.boxSamples(it)) >= 0.5;
      if (ok) ids.push(it.id);
    }
    if (ids.length) this.select(ids); else this.clearSel();
  }

  /** Parte del trazo (por longitud, no por número de puntos) que queda dentro del lazo. */
  inkInside(it, inPoly) {
    const pts = G.inkWorldPoints(it);
    if (pts.length < 2) return pts.length && inPoly(pts[0].x, pts[0].y) ? 1 : 0;
    let tot = 0, inn = 0, prev = inPoly(pts[0].x, pts[0].y);
    for (let i = 1; i < pts.length; i++) {
      const a = pts[i - 1], b = pts[i], cur = inPoly(b.x, b.y);
      const l = Math.hypot(b.x - a.x, b.y - a.y);
      tot += l;
      inn += prev && cur ? l : prev || cur ? l / 2 : 0;
      prev = cur;
    }
    return tot ? inn / tot : 0;
  }

  /** Rejilla de 5×5 puntos sobre un elemento (con su giro), para ver cuánto queda dentro del lazo. */
  boxSamples(it) {
    const c = G.center(it), out = [];
    for (let i = 0; i <= 4; i++) for (let j = 0; j <= 4; j++) out.push(G.rotPt(it.x + (it.w * i) / 4, it.y + (it.h * j) / 4, c.x, c.y, it.rot || 0));
    return out;
  }

  // Dibujo ---------------------------------------------------------------------
  toolConfig(tool = settings.tool) {
    if (!TOOLS[tool]) tool = TOOLS[settings.lastDraw] ? settings.lastDraw : 'pen';
    const cfg = settings.tools[tool];
    const def = TOOLS[tool];
    // Por defecto el grosor es fijo respecto al lienzo (como en GoodNotes): con zoom el trazo se ve más gordo.
    const scale = settings.inkScreenWidth ? this.vp.z : 1;
    return { tool, color: cfg.color, size: def.sizes[cfg.size] / scale, sizeIdx: cfg.size, opacity: cfg.opacity ?? 1, tip: tool === 'marker' && (cfg.tip ?? 'round') === 'round' ? 'round' : tool === 'monoline' ? 'mb' : tool === 'pen' && (cfg.style ?? 'samsung') === 'samsung' ? 'sn' : tool === 'pen' && cfg.style === 'goodnotes' ? 'gf' : tool === 'fountain' ? 'gn' : undefined };
  }

  startDraw(p, w) {
    // En un cuaderno se escribe sobre las páginas, no en el hueco entre ellas.
    if (NB.isNotebook() && NB.pageAt(w, 4 / this.vp.z) < 0) { this.op = null; return false; }
    // Empezar a escribir quita la selección (lo que acabas de colocar ya está en su sitio).
    this.clearSel();
    const cfg = this.toolConfig();
    const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    svg.setAttribute('class', 'live-ink');
    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    svg.append(path);
    this.live.append(svg);
    this.palette.autoMinimize();
    const op = { kind: 'draw', p, cfg, pts: [], svg, path, t0: performance.now(), lastStill: { x: p.x, y: p.y }, shape: null, lastP: 0.5, lastT: performance.now(), lastS: { x: p.x, y: p.y } };
    // Regla: si el trazo empieza junto a su borde, se ajusta a él.
    if (settings.rulerOn) op.ruler = this.rulerSnapLine(p);
    this.op = op;
    if (this.liveOk && p.type === 'pen' && (cfg.tool === 'pen' || cfg.tool === 'monoline') && (cfg.opacity ?? 1) >= 0.999) {
      // La web sigue dibujando hasta que Android confirma que lo pinta él; entonces se esconde la vista previa web.
      op.nativeTried = true;
      liveInk.confirm().then((ok) => {
        if (!ok || this.op !== op || op.shape) return;
        op.native = true;
        svg.style.visibility = 'hidden';
      });
    }
    this.addPoint(p.x, p.y, p.type === 'pen' && p.pr > 0 ? p.pr : 0.5, p.type);
    this.drawLive();
  }

  addPoint(cx, cy, pressure, type, t) {
    const op = this.op;
    let x = cx, y = cy;
    if (op.ruler) { const q = projectOnLine(cx, cy, op.ruler); x = q.x; y = q.y; }
    const w = this.vp.toWorld(x, y);
    let pr;
    if (type === 'pen') {
      pr = pressure > 0 ? penPressure(pressure, op.cfg.tool) : 0.5;
      if (pressure > 0) (op.raw || (op.raw = [])).push(pressure);
      // La velocidad solo cuenta en la pluma estilo Freeform; la de GoodNotes va solo por presión.
      if (op.cfg.tool === 'pen' && !['smooth', 'gn', 'gf', 'pf', 'sn'].includes(op.cfg.tip)) {
        const f = this.penSpeed(op, cx, cy, t);
        // Hasta saber a qué velocidad va el trazo, sus primeros puntos se guardan aparte y se corrigen luego.
        if (!op.spd.ready) { (op.pre || (op.pre = [])).push(op.pts.length); op.prePr = op.prePr || []; op.prePr.push(pr); }
        else if (op.pre) { op.pre.forEach((i, k) => { if (op.pts[i]) op.pts[i].p = Math.min(1.6, op.prePr[k] * f); }); op.pre = null; }
        pr = Math.min(1.6, pr * f);
      }
    } else {
      const now = performance.now(), dt = Math.max(1, now - op.lastT);
      const v = Math.hypot(cx - op.lastS.x, cy - op.lastS.y) / dt;
      pr = op.lastP + (clamp(1.05 - v * 0.28, 0.35, 1) - op.lastP) * 0.25;
      op.lastT = now; op.lastS = { x: cx, y: cy };
    }
    op.lastP = pr;
    op.pts.push({ x: w.x, y: w.y, p: pr });
  }

  /**
   * Bolígrafo como en Freeform: la tinta depende de la velocidad. Un trazo rápido (una rama, el lado de un
   * triángulo, una flecha) sale fino y engorda donde frenas; al pararte para levantar queda la «gota» gruesa
   * del final. Factor suavizado en el tiempo (unos 45 ms) para que el grosor cambie poco a poco, sin saltos.
   */
  penSpeed(op, x, y, t) {
    const s = op.spd || (op.spd = { t: null, x, y, f: 1, ready: false });
    if (t == null || s.t == null) { if (t != null) { s.t = t; s.x = x; s.y = y; } return s.f; }
    const dt = t - s.t;
    if (dt > 0) {
      const v = Math.hypot(x - s.x, y - s.y) / dt;                // px por ms (escribir letras ≈ 0,3; una raya rápida ≈ 1,5)
      // Escribiendo letras (≈0,35) queda 1; parándote, hasta 1,5 (la gota); una raya rápida, menos de la mitad.
      const target = 0.42 + 1.1 * Math.exp(-v / 0.55);
      // La primera medida fija el punto de partida (si empiezas rápido, el trazo ya empieza fino).
      if (!s.ready) { s.f = target; s.ready = true; } else s.f += (target - s.f) * Math.min(1, dt / 45);
      s.t = t; s.x = x; s.y = y;
    }
    return s.f;
  }

  moveDraw(events) {
    const op = this.op;
    if (op.shape) {
      // Si el lápiz sigue moviéndose tras reconocer la forma, no era una pausa: se vuelve al trazo libre.
      const last = events[events.length - 1];
      if (Math.hypot(last.clientX - op.lastStill.x, last.clientY - op.lastStill.y) < 12) return;
      op.shape = null;
      if (op.mk) { op.mk.g.style.display = ''; op.path.setAttribute('d', ''); }
      else for (const a of ['stroke', 'stroke-width', 'stroke-linejoin', 'stroke-linecap', 'fill']) op.path.removeAttribute(a);
    }
    for (const ev of events) this.addPoint(ev.clientX, ev.clientY, ev.pressure, ev.pointerType, ev.timeStamp);
    const last = events[events.length - 1];
    if (settings.autoShape && Math.hypot(last.clientX - op.lastStill.x, last.clientY - op.lastStill.y) > 5) {
      op.lastStill = { x: last.clientX, y: last.clientY };
      clearTimeout(op.stillTimer);
      // El subrayador pide una pausa más larga para enderezarse: si no, cualquier subrayado acaba recto.
      op.stillTimer = setTimeout(() => this.tryRecognize(), op.cfg.tool === 'marker' ? 1100 : 600);
    }
    if (!op.raf) op.raf = requestAnimationFrame(() => { op.raf = null; this.drawLive(); });
  }

  drawLive() {
    const op = this.op;
    if (!op || op.kind !== 'draw') return;
    if (op.cfg.tool === 'marker') return this.drawLiveMarker(op);
    if (op.native) return;   // la pinta Android en vivo
    const flat = [];
    for (const q of op.pts) flat.push(q.x, q.y, q.p);
    // El trazo en pantalla llega hasta donde va a estar el lápiz (no se guarda): así se siente instantáneo.
    const lp = op.pts[op.pts.length - 1];
    if (op.pred && lp && !op.shape && Math.hypot(op.pred.x - lp.x, op.pred.y - lp.y) < 40 / this.vp.z) flat.push(op.pred.x, op.pred.y, lp.p);
    const it = { tool: op.cfg.tool, color: adaptInk(op.cfg.color), size: op.cfg.size, opacity: op.cfg.opacity, pts: flat, tip: op.cfg.tip };
    op.path.setAttribute('d', inkPath(flat, op.cfg.tool, op.cfg.size, op.cfg.tip));
    const tmp = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    tmp.innerHTML = `<path ${inkStyle(it, isDark())}/>`;
    for (const a of tmp.firstChild.attributes) op.path.setAttribute(a.name, a.value);
    op.svg.style.mixBlendMode = inkBlend(op.cfg.tool, isDark()) || '';
  }

  /**
   * Subrayador en vivo: lo ya pintado no se recalcula (va en trozos fijos) y solo cambia la punta,
   * así sigue al lápiz sin tirones aunque el trazo sea largo. La transparencia va en el grupo,
   * para que los tramos que se pisan no oscurezcan.
   */
  drawLiveMarker(op) {
    const NS = 'http://www.w3.org/2000/svg';
    if (!op.mk) {
      const g = document.createElementNS(NS, 'g');
      const tail = document.createElementNS(NS, 'path');
      g.append(tail);
      op.svg.insertBefore(g, op.path);
      const it = { tool: 'marker', opacity: op.cfg.opacity };
      op.svg.style.opacity = String((TOOLS.marker.alpha ?? 1) * (it.opacity ?? 1));
      op.svg.style.mixBlendMode = inkBlend('marker', isDark()) || '';
      op.mk = { g, tail, cur: null, curN: 0, done: 0, color: adaptInk(op.cfg.color) };
      tail.setAttribute('fill', op.mk.color);
      op.path.setAttribute('fill', op.mk.color);
    }
    const mk = op.mk, size = op.cfg.size;
    const flat = [];
    for (const q of op.pts) flat.push(q.x, q.y, q.p);
    const { pts, stable } = markerPoints(flat, size);
    const tip = op.cfg.tip;
    // Tramos nuevos que ya no cambiarán: se añaden al trozo actual (cada 40, un trozo nuevo).
    if (stable === 1 && mk.done === 0 && pts.length === 1) { mk.tail.setAttribute('d', markerSegment(pts[0], null, size, tip)); return; }
    let add = '', k = 0;
    while (mk.done < stable - 1) { add += markerSegment(pts[mk.done], pts[mk.done + 1], size, tip); mk.done++; k++; }
    if (add) {
      if (!mk.cur || mk.curN + k > 40) {
        mk.cur = document.createElementNS(NS, 'path');
        mk.cur.setAttribute('fill', mk.color);
        mk.g.insertBefore(mk.cur, mk.tail);
        mk.curD = ''; mk.curN = 0;
      }
      mk.curN += k;
      mk.curD += add;
      mk.cur.setAttribute('d', mk.curD);
    }
    // La punta: del último punto fijo hasta donde está el lápiz.
    const last = pts.length > stable ? pts[pts.length - 1] : null;
    mk.tail.setAttribute('d', last ? markerSegment(pts[stable - 1], last, size, tip) : (mk.done ? '' : markerSegment(pts[0], null, size, tip)));
  }

  tryRecognize() {
    const op = this.op;
    if (!op || op.kind !== 'draw' || op.pts.length < 6 || op.cfg.tool === 'watercolor') return;
    const res = recognize(op.pts);
    if (!res) return;
    if (op.cfg.tool === 'marker') {
      // Subrayador: al mantener el lápiz quieto, la línea se endereza (como en GoodNotes).
      if (res.kind !== 'line') return;
      if (op.nativeTried) { op.native = op.nativeTried = false; op.svg.style.visibility = ''; liveInk.clear(true); this.drawLive(); }
      op.shape = { kind: 'straightInk', pts: straightPts(res.a, res.b, op.pts) };
      vibrate(15);
      const flat = [];
      for (const q of op.shape.pts) flat.push(q.x, q.y, q.p);
      if (op.mk) op.mk.g.style.display = 'none';
      op.path.setAttribute('d', inkPath(flat, op.cfg.tool, op.cfg.size, op.cfg.tip));
      return;
    }
    if (op.nativeTried) { op.native = op.nativeTried = false; op.svg.style.visibility = ''; liveInk.clear(true); this.drawLive(); }
    op.shape = res;
    vibrate(15);
    const sw = op.cfg.size;
    let d;
    if (res.kind === 'line') d = `M${res.a.x},${res.a.y} L${res.b.x},${res.b.y}`;
    else if (res.kind === 'ellipse') { const b = res.box; d = `M${b.x},${b.y + b.h / 2} a${b.w / 2},${b.h / 2} 0 1,0 ${b.w},0 a${b.w / 2},${b.h / 2} 0 1,0 ${-b.w},0`; }
    else if (res.kind === 'rect') { const b = res.box; d = `M${b.x},${b.y} h${b.w} v${b.h} h${-b.w} Z`; }
    else d = 'M' + res.pts.map((q) => `${q.x},${q.y}`).join(' L') + ' Z';
    op.path.setAttribute('d', d);
    op.path.setAttribute('fill', 'none');
    op.path.setAttribute('stroke', adaptInk(op.cfg.color));
    op.path.setAttribute('stroke-width', sw);
    op.path.setAttribute('stroke-linejoin', 'round');
    op.path.setAttribute('stroke-linecap', 'round');
    op.path.removeAttribute('filter');
  }

  cancelDraw() { const op = this.op; clearTimeout(op?.stillTimer); op?.svg?.remove(); if (op?.nativeTried) liveInk.clear(true); this.op = null; }

  endDraw(cancel, op = this.op) {
    if (op?.kind !== 'draw') return;
    this.lastInkT = performance.now();
    this.op = null;
    clearTimeout(op.stillTimer);
    cancelAnimationFrame(op.raf);
    // La tinta nativa se borra en cuanto la web ha pintado el trazo definitivo (dos fotogramas después).
    // La tinta nativa se quita cuando el trazo definitivo ya está en pantalla (la web tarda unos fotogramas en
    // mostrarlo): así no hay un instante sin tinta (el «flash»).
    if (op.nativeTried) requestAnimationFrame(() => requestAnimationFrame(() => setTimeout(() => liveInk.clear(false), 90)));
    if (cancel || !op.pts.length) { op.svg.remove(); return; }
    if (op.raw) learnPressure(op.raw);   // aprende tu forma de apretar
    const { color, size, tool, opacity, tip } = op.cfg;
    // Garabato encima de algo = borrarlo (como en GoodNotes).
    if (!op.shape && settings.scribbleErase !== false && SCRIBBLE_TOOLS.has(tool) && this.scribbleErase(op.pts)) { op.svg.remove(); return; }
    let item;
    const s = op.shape;
    if (s?.kind === 'straightInk') item = makeInk(s.pts, { tool, color, size, opacity, tip }, uid());
    else if (s?.kind === 'line') item = { id: uid(), type: 'line', a: { x: s.a.x, y: s.a.y }, b: { x: s.b.x, y: s.b.y }, style: 'straight', color, width: size };
    else if (s?.kind === 'ellipse' || s?.kind === 'rect') item = { id: uid(), type: 'shape', shape: s.kind, ...s.box, rot: 0, fill: 'none', stroke: color, sw: size * this.vp.z > 0 ? size : 2, text: '', swWorld: true };
    else if (s?.kind === 'poly') {
      const b = s.box;
      const path = 'M' + s.pts.map((q) => `${(((q.x - b.x) / (b.w || 1)) * 100).toFixed(2)},${(((q.y - b.y) / (b.h || 1)) * 100).toFixed(2)}`).join(' L') + ' Z';
      item = { id: uid(), type: 'shape', shape: 'custom', path, ...b, rot: 0, fill: 'none', stroke: color, sw: size, text: '' };
    } else item = makeInk(op.pts, { tool, color, size, opacity, tip }, uid());
    // Aprende qué colores y grosores usas más (para los colores rápidos y «Lo que más usas»).
    if (item.type === 'ink' && recordUse(tool, color, op.cfg.sizeIdx)) { this.palette.refresh(); toast('Color añadido a tus colores rápidos', 1400); }
    // El grosor de las formas se mide en píxeles de pantalla (vector-effect), así que se convierte.
    if (item.type === 'shape') { item.sw = Math.max(1, Math.round(size * this.vp.z * 10) / 10); delete item.swWorld; }
    store.add(item);
    // Retira la vista previa en el siguiente fotograma para que no haya parpadeo.
    requestAnimationFrame(() => op.svg.remove());
  }

  /** Si el trazo es un garabato (zigzag) encima de escritura, borra lo que tapa. Devuelve true si borró algo. */
  /** ¿Es un garabato (muchas idas y vueltas sobre la misma zona)? */
  /**
   * ¿Es un garabato (muchas idas y vueltas sobre la misma zona)? Cuenta las vueltas en horizontal y en vertical:
   * se puede tachar de lado a lado («≡») o en zigzag de arriba abajo avanzando («WWW»).
   * strict: solo garabatos muy densos (lo que ya has coloreado), para no confundirlos con palabras como «mmm».
   * Devuelve { turns, spacing } o null.
   */
  isScribble(pts, strict = false) {
    if (pts.length < 12) return null;
    const box = G.bboxOfPoints(pts);
    const ext = Math.max(box.w, box.h);
    if (ext < 14 / this.vp.z) return null;
    let len = 0;
    for (let i = 1; i < pts.length; i++) len += Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y);
    if (len < ext * (strict ? 6 : 1.6)) return null;
    const turnsOn = (axis) => {
      const span = axis === 'x' ? box.w : box.h;
      const thr = Math.max(span * 0.22, 5 / this.vp.z);
      let dir = 0, anchor = pts[0][axis], turns = 0;
      for (const q of pts) {
        const d = q[axis] - anchor;
        if (d > thr && dir !== 1) { if (dir === -1) turns++; dir = 1; anchor = q[axis]; }
        else if (d < -thr && dir !== -1) { if (dir === 1) turns++; dir = -1; anchor = q[axis]; }
        else if ((dir === 1 && q[axis] > anchor) || (dir === -1 && q[axis] < anchor)) anchor = q[axis];
      }
      return turns;
    };
    const tx = turnsOn('x'), ty = turnsOn('y'), turns = Math.max(tx, ty);
    if (turns < (strict ? 6 : 4)) return null;
    // Separación entre pasadas: lo que avanza el garabato dividido por sus vueltas.
    const along = tx >= ty ? box.h : box.w;
    return { turns, spacing: along / (turns + 1) };
  }

  scribbleErase(pts) {
    const sc = this.isScribble(pts);
    if (!sc) return false;
    const box = G.bboxOfPoints(pts);
    const pad = 6 / this.vp.z;
    const zone = { x: box.x - pad, y: box.y - pad, w: box.w + pad * 2, h: box.h + pad * 2 };
    const inZone = (q) => q.x >= zone.x && q.y >= zone.y && q.x <= zone.x + zone.w && q.y <= zone.y + zone.h;
    const center = { x: box.x + box.w / 2, y: box.y + box.h / 2 };
    // Tachar es pasar POR ENCIMA de lo escrito: buena parte del trazo tiene que quedar pegada al garabato.
    // Lo que cuenta como «tachado»: cerca de alguna pasada (más margen si el garabato es suelto).
    const near = Math.max(10 / this.vp.z, sc.spacing * 0.6);
    const covered = (wp) => {
      const step = Math.max(1, Math.floor(wp.length / 60));
      let hit = 0, n = 0;
      for (let i = 0; i < wp.length; i += step, n++) if (G.distToPolyline(wp[i].x, wp[i].y, pts) <= near) hit++;
      return hit / (n || 1);
    };
    const targets = store.items.filter((it) => {
      if (it.locked || !G.boxesIntersect(G.aabb(it, this.map), zone)) return false;
      if (it.type === 'ink') {
        const wp = G.inkWorldPoints(it);
        if (wp.filter(inZone).length / wp.length < 0.5) return false;
        // Lo que ya has coloreado (otro garabato muy denso) no se borra al seguir coloreando encima.
        if (this.isScribble(wp, true)) return false;
        // Colorear DENTRO de algo (un círculo, un contorno): el contorno rodea el garabato y no se toca.
        const b = G.aabb(it, this.map);
        const closed = wp.length > 8 && Math.hypot(wp[0].x - wp[wp.length - 1].x, wp[0].y - wp[wp.length - 1].y) < Math.max(b.w, b.h) * 0.25;
        if (closed && b.w >= box.w * 0.75 && b.h >= box.h * 0.75 && G.pointInPoly(center.x, center.y, wp)) return false;
        return covered(wp) >= 0.3;
      }
      if (['line', 'shape', 'text', 'emoji'].includes(it.type)) return G.boxContains(zone, G.aabb(it, this.map));
      return false;
    }).map((i) => i.id);
    if (!targets.length) return false;
    store.remove(targets);
    vibrate(12);
    toast(targets.length === 1 ? 'Borrado con garabato' : `${targets.length} elementos borrados`, 1100);
    return true;
  }

  // Borrador ---------------------------------------------------------------------
  startErase(p, w) {
    if (this.op?.kind !== 'draw') this.clearSel();
    const cursor = h('div.eraser-cursor' + (settings.eraserTarget === 'marker' ? '.only-marker' : ''));
    this.ui.append(cursor);
    this.op = { kind: 'erase', p, prev: store.snapshot(), cursor, changed: false, last: null, prevMap: new Map(store.items.map((i) => [i.id, i])), keep: this.objectsUnderInk(), inked: false };
    this.eraseAt(p.x, p.y, p.type === 'pen' ? p.pr : 1);
  }

  /**
   * Objetos con algo escrito encima (una nota con texto a mano, una imagen subrayada…): la goma borra lo escrito
   * y deja el objeto. Se calcula al empezar a borrar, así el post-it sigue ahí aunque ya hayas borrado todo lo de encima.
   */
  objectsUnderInk() {
    const keep = new Set(), items = store.items, inks = [];
    for (let i = 0; i < items.length; i++) if (items[i].type === 'ink') inks.push({ i, b: G.aabb(items[i], this.map) });
    if (!inks.length) return keep;
    items.forEach((it, i) => {
      if (it.type === 'ink' || it.type === 'line' || it.type === 'frame') return;
      const b = G.aabb(it, this.map);
      if (inks.some((k) => k.i > i && G.boxesIntersect(k.b, b))) keep.add(it.id);
    });
    return keep;
  }

  moveErase(events) { for (const ev of events) this.eraseAt(ev.clientX, ev.clientY, ev.pointerType === 'pen' ? ev.pressure : 1); }

  eraseAt(cx, cy, pressure = 1) {
    const op = this.op;
    // Botón del S Pen pulsado en el aire: solo se mueve el cursor de la goma.
    if (!(pressure > 0)) { const r0 = this.vp.rect(); Object.assign(op.cursor.style, { left: `${cx - r0.left}px`, top: `${cy - r0.top}px` }); op.last = null; return; }
    // Interpola entre eventos para que un movimiento rápido no deje huecos sin borrar.
    if (op.last) {
      const d = Math.hypot(cx - op.last.x, cy - op.last.y), step = Math.max(2, ERASER_SIZES[settings.eraserSize ?? 1] / 3);
      const prev = op.last;
      for (let k = 1; k < Math.floor(d / step); k++) this.eraseAtPoint(prev.x + ((cx - prev.x) * k * step) / d, prev.y + ((cy - prev.y) * k * step) / d);
    }
    op.last = { x: cx, y: cy };
    this.eraseAtPoint(cx, cy);
  }

  eraseAtPoint(cx, cy) {
    const op = this.op;
    const rScreen = ERASER_SIZES[settings.eraserSize ?? 1] / 2;
    const r0 = this.vp.rect();
    Object.assign(op.cursor.style, { left: `${cx - r0.left}px`, top: `${cy - r0.top}px`, width: `${rScreen * 2}px`, height: `${rScreen * 2}px` });
    const w = this.vp.toWorld(cx, cy), r = rScreen / this.vp.z;
    const hitBox = { x: w.x - r, y: w.y - r, w: r * 2, h: r * 2 };
    let changed = false;
    const out = [];
    const removed = new Set();
    // «Solo subrayador»: la goma atraviesa todo lo demás sin tocarlo.
    const onlyMarker = settings.eraserTarget === 'marker';
    const touched = (it) => !it.locked && it.type !== 'frame' && !(onlyMarker && !(it.type === 'ink' && it.tool === 'marker'))
      && G.boxesIntersect(G.aabb(it, this.map), hitBox) && G.hit(it, w.x, w.y, r, this.map);
    // Si la goma está tocando escritura, solo borra escritura: lo que haya debajo (un post-it, una forma) se queda.
    const items = store.items, hits = items.map(touched);
    const inkHere = items.some((it, i) => hits[i] && it.type === 'ink');
    if (inkHere) op.inked = true;
    for (let i = 0; i < items.length; i++) {
      const it = items[i];
      if (!hits[i]) { out.push(it); continue; }
      // Objetos (notas, formas, imágenes, conectores…): se borran enteros al pasar por encima, salvo si tienen algo
      // escrito encima o si con esta pasada de goma ya estabas borrando escritura.
      if (it.type !== 'ink' && (inkHere || op.inked || op.keep?.has(it.id))) { out.push(it); continue; }
      changed = true;
      if (it.type !== 'ink' || settings.eraserMode === 'object') { removed.add(it.id); continue; }
      // Borrador de píxeles: parte el trazo por donde pasa el borrador.
      const scale = Math.sqrt((it.w / it.vw) * (it.h / it.vh));
      const size = it.size * scale;
      const pts = densify(G.inkWorldPoints(it).map((q, i) => ({ ...q, p: it.pts[i * 3 + 2] })), Math.max(1, r / 2));
      let run = [];
      const runs = [];
      for (let i = 0; i < pts.length; i++) {
        const q = pts[i];
        if (Math.hypot(q.x - w.x, q.y - w.y) <= r + size / 2) { if (run.length) runs.push(run); run = []; }
        else run.push(q);
      }
      if (run.length) runs.push(run);
      for (const rn of runs) if (rn.length > 1 || pts.length === 1) out.push(makeInk(rn, { tool: it.tool, color: it.color, size, opacity: it.opacity, tip: it.tip }, uid()));
    }
    if (!changed) return;
    op.changed = true;
    // Conectores cuyo objeto se ha borrado: el extremo se queda suelto donde estaba.
    const fixed = removed.size ? out.map((it) => {
      if (it.type !== 'line') return it;
      let n = it;
      for (const end of ['a', 'b']) if (it[end]?.id && removed.has(it[end].id)) { const q = G.endPoint(it, end, op.prevMap); n = { ...n, [end]: { x: q.x, y: q.y } }; }
      return n;
    }) : out;
    store.set(fixed, { silent: true });
  }

  endErase(op = this.op) {
    this.op = null;
    this.ui.querySelector('.eraser-cursor')?.remove();
    if (op?.changed) { store.record(op.prev); this.save(); this.saveThumb(); }
  }

  // Regla -----------------------------------------------------------------------
  renderRuler() {
    let el = this.ui.querySelector('.ruler');
    const on = settings.rulerOn && this.mode === 'draw';
    if (!on) { el?.remove(); return; }
    if (!el) {
      el = h('div.ruler', {}, h('div.ruler-ticks'), h('div.ruler-angle'));
      this.ui.append(el);
    }
    const r = this.vp.rect();
    el.style.left = `${this.ruler.cx - r.left}px`;
    el.style.top = `${this.ruler.cy - r.top}px`;
    el.style.transform = `translate(-50%,-50%) rotate(${this.ruler.ang}deg)`;
    el.querySelector('.ruler-angle').textContent = `${Math.round(((-this.ruler.ang % 360) + 360) % 180)}°`;
  }

  moveRuler() {
    const op = this.op;
    const a = this.pointers.get(op.id);
    if (!a) return;
    if (op.second) {
      const b = this.pointers.get(op.second.id);
      if (!b) return;
      if (!op.rot) op.rot = { a0: Math.atan2(b.y - a.y, b.x - a.x), ang0: this.ruler.ang, c0: { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }, r0: { ...this.ruler } };
      let ang = op.rot.ang0 + ((Math.atan2(b.y - a.y, b.x - a.x) - op.rot.a0) * 180) / Math.PI;
      for (const s of [-180, -135, -90, -45, 0, 45, 90, 135, 180]) if (Math.abs(ang - s) < 2.5) ang = s;
      const c = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
      this.ruler = { cx: op.rot.r0.cx + c.x - op.rot.c0.x, cy: op.rot.r0.cy + c.y - op.rot.c0.y, ang };
    } else {
      op.rot = null;
      this.ruler = { ...this.ruler, cx: op.start.cx + a.x - op.p.sx, cy: op.start.cy + a.y - op.p.sy };
    }
    this.renderRuler();
  }

  rulerSnapLine(p) {
    const { cx, cy, ang } = this.ruler;
    const a = (ang * Math.PI) / 180, ux = Math.cos(a), uy = Math.sin(a), nx = -uy, ny = ux;
    const half = 44;
    for (const sgn of [-1, 1]) {
      const ox = cx + nx * half * sgn, oy = cy + ny * half * sgn;
      const d = Math.abs((p.x - ox) * nx + (p.y - oy) * ny);
      if (d < 34) return { ox, oy, ux, uy };
    }
    return null;
  }

  // Edición de texto -----------------------------------------------------------------
  startEditing(it, { cell, selectAll = false } = {}) {
    if (!it || it.locked) return;
    if (this.mode === 'draw') this.setMode('select');
    if (this.editing) this.stopEditing();
    this.sel = new Set([it.id]);
    const el = this.r.elOf(it.id);
    if (!el) return;
    const target = cell ? el.querySelector(`.cell[data-r="${cell.r}"][data-c="${cell.c}"]`) : el.querySelector('.txt');
    if (!target) return;
    this.editing = { id: it.id, cell, target, original: target.innerText };
    this.r.editing = { id: it.id };
    el.classList.add('editing');
    target.classList.add('edit-target');
    try { target.contentEditable = 'plaintext-only'; } catch { target.contentEditable = 'true'; }
    if (target.contentEditable !== 'plaintext-only') target.contentEditable = 'true';
    target.spellcheck = true;
    target.focus({ preventScroll: true });
    const range = document.createRange();
    range.selectNodeContents(target);
    if (!selectAll) range.collapse(false);
    const s = getSelection(); s.removeAllRanges(); s.addRange(range);
    target.oninput = () => {
      if (it.type === 'note') this.r.fitText(el, it);
      if (it.type === 'text') this.scheduleOverlay();
    };
    target.onkeydown = (e) => { if (e.key === 'Escape') { e.preventDefault(); this.stopEditing(); } if (e.key === 'Tab' && cell) { e.preventDefault(); this.nextCell(e.shiftKey); } };
    this.updateOverlay();
    setTimeout(() => this.keepEditingVisible(), 350);
  }

  nextCell(back) {
    const ed = this.editing;
    const it = store.get(ed.id);
    let { r, c } = ed.cell;
    c += back ? -1 : 1;
    if (c >= it.colW.length) { c = 0; r++; } if (c < 0) { c = it.colW.length - 1; r--; }
    this.stopEditing();
    if (r >= 0 && r < it.rowH.length) this.startEditing(store.get(it.id), { cell: { r, c } });
  }

  keepEditingVisible() {
    if (!this.editing) return;
    const vv = window.visualViewport;
    const el = this.editing.cell ? this.editing.target : this.editing.target.closest('.item') || this.editing.target;
    if (!vv || !el?.isConnected) return;
    const rect = el.getBoundingClientRect();
    const bottomLimit = vv.height - 20;
    if (rect.bottom > bottomLimit) this.vp.animateTo(this.vp.x, this.vp.y - (rect.bottom - bottomLimit) - 20, this.vp.z, 200);
    this.scheduleOverlay();
  }

  stopEditing() {
    const ed = this.editing;
    if (!ed) return;
    this.editing = null;
    this.r.editing = null;
    const { target } = ed;
    const text = target.innerText.replace(/\n$/, '');
    target.contentEditable = 'false';
    target.classList.remove('edit-target');
    target.oninput = null;
    target.blur();
    getSelection()?.removeAllRanges();
    this.r.elOf(ed.id)?.classList.remove('editing');
    const it = store.get(ed.id);
    if (!it) return;
    this.r.invalidate(ed.id);
    if (it.type === 'text' && !text.trim()) { store.remove([it.id]); this.sel.delete(it.id); this.updateOverlay(); return; }
    if (ed.cell) {
      const cells = it.cells.map((row) => [...row]);
      if (cells[ed.cell.r][ed.cell.c] !== text) { cells[ed.cell.r][ed.cell.c] = text; store.update(it.id, { cells }); }
      else this.r.sync(store.items);
    } else if (text !== (it.text || '')) {
      const patch = { text };
      if (it.type === 'text') { const el = this.r.elOf(it.id); if (el) patch.h = el.offsetHeight; }
      store.update(it.id, patch);
    } else this.r.sync(store.items);
    this.refreshCtx();
  }

  // Comandos ------------------------------------------------------------------------
  undo() { if (this.editing) this.stopEditing(); store.undo(); this.save(); this.saveThumb(); }
  redo() { if (this.editing) this.stopEditing(); store.redo(); this.save(); this.saveThumb(); }

  deleteSel() {
    const ids = this.selItems().filter((i) => !i.locked).map((i) => i.id);
    if (!ids.length) { if (this.sel.size) toast('Los elementos bloqueados no se pueden eliminar'); return; }
    store.remove(ids);
    this.sel.clear();
    this.updateOverlay();
  }

  copy() {
    const items = this.selItems();
    if (!items.length) return;
    // Incluye conectores entre los elementos copiados.
    const ids = new Set(items.map((i) => i.id));
    const extra = store.items.filter((i) => i.type === 'line' && !ids.has(i.id) && i.a?.id && i.b?.id && ids.has(i.a.id) && ids.has(i.b.id));
    const list = cloneItems([...items, ...extra], 0, 0);
    this.app.setClipboard({ items: list, box: G.unionBox(list.map((i) => G.aabb(i, new Map(list.map((x) => [x.id, x]))))) });
    toast(items.length === 1 ? 'Copiado' : `${items.length} elementos copiados`, 1200);
  }

  cut() { this.copy(); this.deleteSel(); }

  paste(at) {
    const clip = this.app.clipboard();
    if (!clip?.items?.length) return;
    const target = at || this.vp.center();
    const dx = target.x - (clip.box.x + clip.box.w / 2), dy = target.y - (clip.box.y + clip.box.h / 2);
    const items = cloneItems(clip.items, dx, dy, new Map(clip.items.map((i) => [i.id, i])));
    store.add(items);
    this.select(items.map((i) => i.id));
    this.markFresh(items.map((i) => i.id));
  }

  duplicate() {
    const items = this.selItems();
    if (!items.length) return;
    const off = 24 / Math.min(1, this.vp.z);
    const ids = new Set(items.map((i) => i.id));
    const extra = store.items.filter((i) => i.type === 'line' && !ids.has(i.id) && i.a?.id && i.b?.id && ids.has(i.a.id) && ids.has(i.b.id));
    const copies = cloneItems([...items, ...extra], off, off);
    store.add(copies);
    this.select(copies.map((i) => i.id));
    this.markFresh(copies.map((i) => i.id));
  }

  toggleLock() {
    const items = this.selItems();
    const lock = !items.some((i) => i.locked);
    store.update(items.map((i) => i.id), { locked: lock });
    this.refreshCtx();
  }

  toggleGroup() {
    const items = this.selItems();
    const grouped = items.length > 1 && items.every((i) => i.group && i.group === items[0].group);
    const g = grouped ? undefined : uid();
    store.update(items.map((i) => i.id), { group: g });
    this.refreshCtx();
  }

  /** Alinea o distribuye varios elementos. */
  align(how) {
    const items = this.selItems().filter((i) => i.type !== 'line' && !i.locked);
    if (items.length < 2) return;
    const b = G.unionBox(items.map((i) => G.aabb(i)));
    const patch = new Map();
    if (how.startsWith('dist')) {
      const axis = how === 'distH' ? 'x' : 'y', size = axis === 'x' ? 'w' : 'h';
      const sorted = [...items].sort((p, q) => p[axis] - q[axis]);
      const total = sorted.reduce((s, i) => s + i[size], 0);
      const gap = ((axis === 'x' ? b.w : b.h) - total) / (sorted.length - 1);
      let pos = b[axis];
      for (const it of sorted) { patch.set(it.id, { [axis]: pos }); pos += it[size] + gap; }
    } else {
      for (const it of items) {
        const a = G.aabb(it), offx = it.x - a.x, offy = it.y - a.y;
        const p = {
          left: { x: b.x + offx }, hcenter: { x: b.x + b.w / 2 - a.w / 2 + offx }, right: { x: b.x + b.w - a.w + offx },
          top: { y: b.y + offy }, vcenter: { y: b.y + b.h / 2 - a.h / 2 + offy }, bottom: { y: b.y + b.h - a.h + offy },
        }[how];
        patch.set(it.id, p);
      }
    }
    store.mutate((all) => all.map((it) => (patch.has(it.id) ? { ...it, ...patch.get(it.id) } : it)));
  }

  /** Coloca un elemento nuevo centrado en la vista (o en un punto) y lo selecciona. */
  place(item, at) {
    const c = at || this.vp.center();
    item.x = c.x - item.w / 2;
    item.y = c.y - item.h / 2;
    // Evita apilar exactamente encima de otro elemento recién creado.
    while (store.items.some((i) => Math.abs(i.x - item.x) < 2 && Math.abs(i.y - item.y) < 2)) { item.x += 24; item.y += 24; }
    store.add(item);
    this.select([item.id]);
    this.markFresh([item.id]);
    return item;
  }

  /** Resalta un momento una zona (resultado de búsqueda). */
  flashBox(box) {
    this.live.querySelector('.find-flash')?.remove();
    const p = 6 / this.vp.z;
    const el = h('div.find-flash', { style: { left: `${box.x - p}px`, top: `${box.y - p}px`, width: `${box.w + p * 2}px`, height: `${box.h + p * 2}px` } });
    this.live.append(el);
    setTimeout(() => el.remove(), 2600);
  }

  /** Añade un marco de página (zona de exportación) en la vista, detrás de todo. */
  addFrame(opts) {
    const f = newFrame(this.vp.visibleBox(), opts);
    store.mutate((items) => [f, ...items]);
    this.select([f.id]);
    this.markFresh([f.id]);
    return f;
  }

  /** Tamaño base razonable en el mundo según el zoom actual. */
  unit(base) { return base / clamp(this.vp.z, 0.5, 1.6); }

  fitContent(animate = true) {
    if (NB.isNotebook()) { NB.fitPage(this, NB.currentPage(this), animate); return; }
    const b = G.unionBox(store.items.map((i) => G.aabb(i, this.map)));
    if (!b) { const r = this.vp.rect(); this.vp.animateTo(r.width / 2, r.height / 2, 1); return; }
    this.vp.fit(b, { maxZ: 1, animate });
  }

  // Teclado (teclados físicos y pruebas en escritorio) ------------------------------------
  onKey(e) {
    if (!this.root.classList.contains('active') || document.querySelector('.dlg-scrim')) return;
    if (this.editing || /INPUT|TEXTAREA/.test(document.activeElement?.tagName)) return;
    const mod = e.ctrlKey || e.metaKey;
    if (e.code === 'Space') { this.spaceDown = true; return; }
    if (mod && e.key.toLowerCase() === 'z') { e.preventDefault(); e.shiftKey ? this.redo() : this.undo(); }
    else if (mod && e.key.toLowerCase() === 'y') { e.preventDefault(); this.redo(); }
    else if (mod && e.key.toLowerCase() === 'c') this.copy();
    else if (mod && e.key.toLowerCase() === 'x') this.cut();
    else if (mod && e.key.toLowerCase() === 'd') { e.preventDefault(); this.duplicate(); }
    else if (mod && e.key.toLowerCase() === 'a') { e.preventDefault(); this.selectAll(); }
    else if (e.key === 'Delete' || e.key === 'Backspace') this.deleteSel();
    else if (e.key === 'Escape') { if (this.app.presenting) panels.stopPresent(this); else this.clearSel(); }
    else if (e.key === 'Enter' && this.sel.size === 1) { const it = this.selItems()[0]; if (TEXTUAL.has(it.type)) { e.preventDefault(); this.startEditing(it); } }
    else if (this.app.presenting && (e.key === 'ArrowRight' || e.key === 'ArrowLeft')) panels.presentStep(this, e.key === 'ArrowRight' ? 1 : -1);
    else if (e.key.startsWith('Arrow') && this.sel.size) {
      e.preventDefault();
      const d = (e.shiftKey ? 10 : 1);
      const dx = e.key === 'ArrowLeft' ? -d : e.key === 'ArrowRight' ? d : 0, dy = e.key === 'ArrowUp' ? -d : e.key === 'ArrowDown' ? d : 0;
      const ids = new Set(this.selItems().filter((i) => !i.locked).map((i) => i.id));
      store.mutate((all) => all.map((it) => (ids.has(it.id) ? translated(it, dx, dy) : it)));
    }
  }

  /** Atrás de Android: devuelve true si lo ha gestionado. */
  back() {
    if (this.app.presenting) { panels.stopPresent(this); return true; }
    if (this.editing) { this.stopEditing(); return true; }
    if (panels.findOpen()) { panels.closeFind(this); return true; }
    if (this.multi) { this.setMulti(false); return true; }
    if (this.sel.size) { this.clearSel(); return true; }
    if (this.mode === 'draw') { this.setMode('select'); return true; }
    return false;
  }
}

export function translated(it, dx, dy) {
  if (it.type === 'line') {
    const f = (e) => (e?.id ? e : { x: e.x + dx, y: e.y + dy });
    return { ...it, a: f(it.a), b: f(it.b) };
  }
  return { ...it, x: it.x + dx, y: it.y + dy };
}

/** ¿El evento del S Pen trae pulsado el botón lateral (o es el extremo borrador)? */
function penBits(e) {
  return e.pointerType === 'pen' && (((e.buttons ?? 0) & (2 | 32)) !== 0 || e.button === 2 || e.button === 5);
}

/** Añade puntos intermedios para que no haya tramos más largos que step. */
function densify(pts, step) {
  if (pts.length < 2) return pts;
  const out = [pts[0]];
  for (let i = 1; i < pts.length; i++) {
    const a = pts[i - 1], c = pts[i], d = Math.hypot(c.x - a.x, c.y - a.y);
    const n = Math.floor(d / step);
    for (let k = 1; k < n; k++) out.push({ x: a.x + ((c.x - a.x) * k) / n, y: a.y + ((c.y - a.y) * k) / n, p: a.p + ((c.p - a.p) * k) / n });
    out.push(c);
  }
  return out;
}

/** Puntos de una línea recta con la presión media del trazo original. */
function straightPts(a, b, src) {
  const p = src.reduce((s, q) => s + q.p, 0) / src.length;
  const n = Math.max(2, Math.ceil(Math.hypot(b.x - a.x, b.y - a.y) / 6));
  return Array.from({ length: n + 1 }, (_, i) => ({ x: a.x + ((b.x - a.x) * i) / n, y: a.y + ((b.y - a.y) * i) / n, p }));
}

function projectOnLine(x, y, L) {
  const t = (x - L.ox) * L.ux + (y - L.oy) * L.uy;
  return { x: L.ox + L.ux * t, y: L.oy + L.uy * t };
}

// La presión del S Pen (con lo que aprende de tu mano) vive en penpressure.js.
export { penPressure } from './penpressure.js';
