// Puente con Android (Capacitor). En el navegador cae a alternativas web.
import { readAsDataURL, h } from './util.js';

const Cap = window.Capacitor;
export const isNative = !!Cap?.isNativePlatform?.();
const plugin = (name) => Cap?.Plugins?.[name] || Cap?.registerPlugin?.(name);

const safeName = (n) => (n || 'archivo').replace(/[\\/:*?"<>|\n\r]+/g, '_').slice(0, 120);

/** Comparte (o guarda, según la app que elija el usuario) un archivo. text: mensaje que acompaña al archivo. */
export async function shareBlob(name, blob, title, text) {
  name = safeName(name);
  if (isNative) {
    const data = (await readAsDataURL(blob)).split(',')[1];
    const res = await plugin('Filesystem').writeFile({ path: `compartir/${name}`, data, directory: 'CACHE', recursive: true });
    try {
      await plugin('Share').share({ title: title || name, files: [res.uri], ...(text ? { text } : {}), dialogTitle: text ? 'Elige Claude' : 'Compartir o guardar' });
    } catch (e) {
      if (!/cancel/i.test(String(e?.message || e))) throw e;
    }
    return;
  }
  const url = URL.createObjectURL(blob);
  const a = h('a', { href: url, download: name });
  document.body.append(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}

export function onBackButton(fn) {
  if (!isNative) return;
  plugin('App').addListener('backButton', fn);
}

export function exitApp() { if (isNative) plugin('App').minimizeApp?.() ?? plugin('App').exitApp(); }

export function onAppPause(fn) {
  if (isNative) plugin('App').addListener('pause', fn);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden') fn(); });
}

export function openExternal(url) {
  window.open(url, '_blank', 'noopener');
}

/**
 * Tinta en vivo nativa (Android): mientras escribes, el trazo lo pinta Android directamente encima de la web, con
 * su técnica de baja latencia. La web la prepara (arm), confirma cada trazo (confirm) y la borra al terminar (clear).
 */
export const liveInk = {
  arm(opts) { return isNative ? plugin('LiveInk')?.arm(opts).catch(() => ({ ok: false })) : Promise.resolve({ ok: false }); },
  confirm() { return isNative ? plugin('LiveInk')?.confirm().then((r) => !!r?.ok).catch(() => false) : Promise.resolve(false); },
  clear(force = false) { if (isNative) plugin('LiveInk')?.clear({ force }).catch(() => {}); },
};
