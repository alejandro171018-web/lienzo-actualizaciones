// «Mejorar letra» (como Restyle de GoodNotes): lee lo escrito a mano con el lazo y lo reescribe
// con una letra más clara, en el mismo sitio y del mismo color. Se puede deshacer.
import { store } from './store.js';
import { h, icon, uid, clamp } from './util.js';
import { popover, toast, confirm, closeAllPopovers } from './ui.js';
import { FONTS, adaptInk } from './render.js';
import { isNative } from './native.js';
import * as G from './geom.js';

/** Estilos que se ofrecen (nombre de la letra en FONTS). */
export const STYLES = ['neat', 'pen', 'hand', 'script', 'round', 'thin', 'sans'];
const STYLE_NAMES = { neat: 'Ordenada', pen: 'Bolígrafo', hand: 'Natural', script: 'Caligrafía', round: 'Redondeada', thin: 'Fina', sans: 'A máquina' };
const LANG = 'es-ES';

const Ink = () => window.Capacitor?.Plugins?.Ink || window.Capacitor?.registerPlugin?.('Ink');
const lastStyle = () => { try { return localStorage.getItem('lienzo.restyle') || 'neat'; } catch { return 'neat'; } };

/** Icono «A» con cursor, como el de GoodNotes. */
export const RESTYLE_ICON = '<svg class="ic" width="21" height="21" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 19 8.5 5l5.5 14"/><path d="M5.2 14h6.6"/><path d="M19 5v14M17 5h4M17 19h4"/></svg>';

// Líneas de escritura ----------------------------------------------------------------------------
/** Agrupa los trazos en líneas (de arriba abajo); tildes y puntos se unen a la línea más cercana. */
export function splitLines(inks) {
  // Caja real de la tinta (la del elemento lleva un margen alrededor).
  const info = inks.map((it) => ({ it, b: G.bboxOfPoints(G.inkWorldPoints(it)), order: store.items.indexOf(it) }));
  const heights = info.map((x) => x.b.h).sort((a, b) => a - b);
  const median = heights[Math.floor(heights.length / 2)] || 1;
  const big = info.filter((x) => x.b.h >= median * 0.45).sort((a, b) => (a.b.y + a.b.h / 2) - (b.b.y + b.b.h / 2));
  const small = info.filter((x) => x.b.h < median * 0.45);
  const lines = [];
  for (const x of big) {
    const cy = x.b.y + x.b.h / 2;
    const line = lines.find((l) => cy >= l.top && cy <= l.bottom);
    if (line) { line.parts.push(x); line.top = Math.min(line.top, x.b.y); line.bottom = Math.max(line.bottom, x.b.y + x.b.h); }
    else lines.push({ parts: [x], top: x.b.y, bottom: x.b.y + x.b.h });
  }
  if (!lines.length && small.length) lines.push({ parts: [], top: small[0].b.y, bottom: small[0].b.y + small[0].b.h });
  for (const x of small) {
    const cy = x.b.y + x.b.h / 2;
    let best = lines[0], bd = Infinity;
    for (const l of lines) { const d = cy < l.top ? l.top - cy : cy > l.bottom ? cy - l.bottom : 0; if (d < bd) { bd = d; best = l; } }
    best.parts.push(x);
  }
  for (const l of lines) {
    l.parts.sort((a, b) => a.order - b.order);
    l.box = G.unionBox(l.parts.map((p) => p.b));
    // Altura «de letra»: la de los trazos grandes (sin tildes).
    const hs = l.parts.filter((p) => p.b.h >= median * 0.45).map((p) => p.b.h).sort((a, b) => a - b);
    l.letterH = Math.max(hs[hs.length - 1] || l.box.h, l.bottom - l.top);
  }
  return lines.sort((a, b) => a.top - b.top);
}

// Reconocimiento ----------------------------------------------------------------------------------
async function ensureModel() {
  let st;
  try { st = await Ink().status({ lang: LANG }); } catch (e) {
    if (/not implemented|no está implementado|UNIMPLEMENTED/i.test(String(e?.message || e)) || !Ink()) throw new Error('apk');
    throw e;
  }
  if (st.downloaded) return true;
  const ok = await confirm('Descargar el idioma', 'Para leer tu letra sin internet, Pizarra necesita descargar una sola vez el español (unos 20 MB). Después funciona sin conexión.', { ok: 'Descargar' });
  if (!ok) return false;
  const busy = h('div.toast.busy.in', { html: '<span class="spin"></span>Descargando el español…' });
  document.getElementById('overlay').append(busy);
  try { await Ink().download({ lang: LANG }); toast('Listo: ya puedes mejorar tu letra sin internet'); return true; }
  catch { toast('No se pudo descargar. La primera vez necesitas conexión a internet.', 3200); return false; }
  finally { busy.remove(); }
}

/** Lee cada línea. Devuelve el texto (líneas separadas por saltos de línea). */
async function recognize(lines) {
  const out = [];
  for (const l of lines) {
    const strokes = l.parts.map(({ it }) => G.inkWorldPoints(it).flatMap((q) => [Math.round((q.x - l.box.x) * 10) / 10, Math.round((q.y - l.box.y) * 10) / 10]));
    const pre = out.join(' ').slice(-20);
    const fn = window.__inkRecognize; // para pruebas en el ordenador
    const res = fn ? await fn(strokes, l.box) : await Ink().recognize({ lang: LANG, strokes, width: l.box.w, height: l.box.h, preContext: pre });
    out.push((res.candidates?.[0] || '').trim());
  }
  return out.join('\n').trim();
}

// Panel -----------------------------------------------------------------------------------------
export async function openRestyle(b, anchor, inks) {
  if (!inks.length) return;
  if (!isNative && !window.__inkRecognize) { toast('«Mejorar letra» funciona en la app de la tablet'); return; }
  const at = anchor.getBoundingClientRect();
  const lines = splitLines(inks);
  let text = '';
  const busy = h('div.toast.busy.in', { html: '<span class="spin"></span>Leyendo tu letra…' });
  try {
    if (!window.__inkRecognize && !(await ensureModel())) return;
    document.getElementById('overlay').append(busy);
    text = await recognize(lines);
  } catch (e) {
    if (e?.message === 'apk') toast('Para «Mejorar letra» instala la versión nueva de la app (el APK).', 3500);
    else { console.warn('restyle', e); toast('No se pudo leer lo escrito'); }
    return;
  } finally { busy.remove(); }
  if (!text) { toast('No he podido leer lo escrito. Prueba a seleccionar solo texto.'); return; }

  let style = STYLES.includes(lastStyle()) ? lastStyle() : 'neat';
  const color = inks[0].color || '#000000';
  const area = h('textarea.rs-text', { rows: Math.min(4, text.split('\n').length + 1), spellcheck: 'true' });
  area.value = text;
  const grid = h('div.rs-styles');
  const paint = () => {
    const sample = (area.value.split('\n')[0] || 'Hola').slice(0, 22);
    grid.innerHTML = '';
    for (const s of STYLES) {
      grid.append(h('button.rs-opt' + (s === style ? '.on' : ''), { onclick: () => { style = s; paint(); } },
        h('span.rs-sample', { text: sample, style: { fontFamily: FONTS[s].css, color: adaptInk(color) } }), h('small', { text: STYLE_NAMES[s] })));
    }
  };
  area.addEventListener('input', paint);
  paint();
  const pop = popover(at, h('div.pop-pad.rs-pop', {},
    h('div.pop-head', {}, h('b', { text: 'Mejorar letra' }), h('span.rs-note', { text: 'Revisa el texto si hace falta' })),
    area, grid,
    h('div.dlg-btns', {},
      h('button.btn', { text: 'Cancelar', onclick: () => pop.close() }),
      h('button.btn.primary', { html: `${icon('check', 18)} Aplicar`, onclick: async () => {
        const t = area.value.trim();
        if (!t) { toast('Escribe el texto'); return; }
        try { localStorage.setItem('lienzo.restyle', style); } catch { /* */ }
        pop.close();
        await apply(b, inks, lines, t, style, color);
      } }))), { className: 'restyle' });
}

/** Sustituye los trazos por el texto con la letra elegida, en el mismo sitio y tamaño. */
async function apply(b, inks, lines, text, style, color) {
  const box = G.unionBox(lines.map((l) => l.box));
  const rows = text.split('\n');
  // Tamaño de letra a partir de la altura de lo escrito. Las mayúsculas ocupan ~0,7 de la letra.
  const letterH = lines.reduce((s, l) => s + l.letterH, 0) / lines.length;
  const caps = /[A-ZÁÉÍÓÚÑ]/.test(text) && text === text.toUpperCase();
  const fsize = Math.round(clamp(caps ? letterH / 0.72 : letterH * 0.95, 8, 400) * 10) / 10;
  const css = FONTS[style].css;
  try { await document.fonts.load(`${fsize}px ${css}`, text); } catch { /* sigue con la de reserva */ }
  const ctx = document.createElement('canvas').getContext('2d');
  ctx.font = `${fsize}px ${css}`;
  const textW = Math.max(...rows.map((r) => ctx.measureText(r).width));
  const w = Math.ceil(textW + 14);                  // + relleno del cuadro de texto
  const hh = Math.ceil(rows.length * fsize * 1.3 + 8);
  // Mismo sitio: alineado a la izquierda de lo escrito y centrado en su altura.
  const item = { id: uid(), type: 'text', text, x: box.x - 6, y: box.y + box.h / 2 - hh / 2, w, h: hh, rot: 0, fsize, font: style, tcolor: color };
  const gone = new Set(inks.map((i) => i.id));
  store.mutate((items) => [...items.filter((i) => !gone.has(i.id)), item]);
  b.select([item.id]);
  closeAllPopovers();
}
