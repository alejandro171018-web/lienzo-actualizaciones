// Paneles del tablero: escenas, presentación, búsqueda y menús de la barra superior.
import { store } from './store.js';
import { h, icon, uid } from './util.js';
import { menu, prompt, toast, popover, segmented, confirm } from './ui.js';
import { renderToCanvas, exportPNG, exportPDF, contentBox, boardToJSON, exportNotebookPDF, notebookPagePNG } from './export.js';
import * as NB from './notebook.js';
import { shareBlob } from './native.js';
import { settings } from './settings.js';
import * as G from './geom.js';
import { moveToFolder, editTags } from './library.js';

// Escenas ---------------------------------------------------------------------------
function sceneBox(sc) { return { x: sc.cx - sc.w / 2, y: sc.cy - sc.h / 2, w: sc.w, h: sc.h }; }

export function addScene(b, name) {
  const r = b.vp.rect();
  const c = b.vp.center();
  const sc = { id: uid(), name: name || `Escena ${store.scenes.length + 1}`, cx: c.x, cy: c.y, z: b.vp.z, w: r.width / b.vp.z, h: r.height / b.vp.z };
  store.setScenes([...store.scenes, sc]);
  toast(`«${sc.name}» guardada`);
  return sc;
}

export function scenesPanel(b, anchor) {
  const list = h('div.scene-list');
  const draw = async () => {
    list.innerHTML = '';
    if (!store.scenes.length) list.append(h('p.empty-note', { text: 'Las escenas guardan zonas del tablero para volver a ellas o presentarlas. Encuadra una zona y toca «Añadir escena».' }));
    for (const [i, sc] of store.scenes.entries()) {
      const th = h('div.scene-th');
      const row = h('div.scene-row', {},
        h('button.scene-go', { onclick: () => { b.vp.showScene(sc); } }, th, h('span', {}, h('small', { text: `${i + 1}` }), h('b', { text: sc.name }))),
        h('button.btn.icon', { html: icon('ellipsis', 18), onclick: (e) => menu(e.currentTarget, [
          { label: 'Renombrar', icon: 'pencil', act: async () => { const n = await prompt('Nombre de la escena', sc.name); if (n) { store.setScenes(store.scenes.map((s) => (s.id === sc.id ? { ...s, name: n } : s))); draw(); } } },
          { label: 'Actualizar con la vista actual', icon: 'scan', act: () => { const r = b.vp.rect(), c = b.vp.center(); store.setScenes(store.scenes.map((s) => (s.id === sc.id ? { ...s, cx: c.x, cy: c.y, z: b.vp.z, w: r.width / b.vp.z, h: r.height / b.vp.z } : s))); draw(); } },
          i > 0 ? { label: 'Subir', icon: 'arrow-up', act: () => { const a = [...store.scenes]; [a[i - 1], a[i]] = [a[i], a[i - 1]]; store.setScenes(a); draw(); } } : null,
          i < store.scenes.length - 1 ? { label: 'Bajar', icon: 'arrow-down', act: () => { const a = [...store.scenes]; [a[i + 1], a[i]] = [a[i], a[i + 1]]; store.setScenes(a); draw(); } } : null,
          { label: 'Eliminar escena', icon: 'trash-2', danger: true, act: () => { store.setScenes(store.scenes.filter((s) => s.id !== sc.id)); draw(); } },
        ], { keep: true }) }));
      list.append(row);
      const box = sceneBox(sc);
      const items = store.items.filter((it) => G.boxesIntersect(G.aabb(it, b.map), box));
      renderToCanvas(items, box, Math.min(160 / box.w, 100 / box.h)).then((c) => { c.className = 'scene-canvas'; th.append(c); });
    }
  };
  draw();
  popover(anchor, h('div.pop-pad.scenes-pop', {},
    h('div.pop-head', {}, h('b', { text: 'Escenas' }), h('button.btn.small', { html: `${icon('play', 16)} Presentar`, onclick: () => startPresent(b) })),
    list,
    h('button.btn.full.primary', { html: `${icon('plus', 18)} Añadir escena`, onclick: () => { addScene(b); draw(); } })), { keep: false, className: 'scenes' });
}

// Presentación --------------------------------------------------------------------------
export function startPresent(b) {
  b.clearSel();
  if (b.mode === 'draw') b.setMode('select');
  b.app.presenting = { idx: 0 };
  b.root.classList.add('presenting');
  document.documentElement.requestFullscreen?.().catch(() => {});
  const bar = document.getElementById('present-bar');
  bar.innerHTML = '';
  bar.append(
    h('button.btn.icon', { html: icon('chevron-left', 24), onclick: () => presentStep(b, -1) }),
    h('span.present-count'),
    h('button.btn.icon', { html: icon('chevron-right', 24), onclick: () => presentStep(b, 1) }),
    h('button.btn.icon', { html: icon('x', 22), title: 'Salir', onclick: () => stopPresent(b) }));
  presentStep(b, 0);
}

export function presentStep(b, d) {
  const p = b.app.presenting;
  if (!p) return;
  const pages = !store.scenes.length && NB.isNotebook();
  const n = pages ? store.pages.length : store.scenes.length;
  if (!n) { b.fitContent(); document.querySelector('.present-count').textContent = 'Tablero completo'; return; }
  if (d === 0 && pages) p.idx = NB.currentPage(b);
  p.idx = Math.max(0, Math.min(n - 1, p.idx + d));
  const box = pages ? NB.pageRect(p.idx) : sceneBox(store.scenes[p.idx]);
  b.vp.fit(box, { pad: pages ? 12 : 0, maxZ: 4, insets: { top: 0, bottom: 0, left: 0, right: 0 } });
  document.querySelector('.present-count').textContent = pages ? `Página ${p.idx + 1} de ${n}` : `${p.idx + 1} de ${n} · ${store.scenes[p.idx].name}`;
}

export function stopPresent(b) {
  b.app.presenting = null;
  b.root.classList.remove('presenting');
  if (document.fullscreenElement) document.exitFullscreen?.().catch(() => {});
}

// Buscar --------------------------------------------------------------------------------
let findState = null;
export const findOpen = () => !!findState;

export function openFind(b) {
  const bar = document.getElementById('find-bar');
  const input = h('input.search', { type: 'search', placeholder: 'Buscar en el tablero', enterkeyhint: 'search' });
  const count = h('span.find-count');
  findState = { matches: [], i: -1 };
  const run = () => {
    const q = input.value.trim().toLowerCase();
    findState.matches = !q ? [] : store.items.filter((it) => {
      const texts = [it.text, it.name, it.title, it.url, ...(it.cells || []).flat()].filter(Boolean).join(' ').toLowerCase();
      return texts.includes(q);
    });
    findState.i = -1;
    count.textContent = q ? (findState.matches.length ? `${findState.matches.length} resultados` : 'Sin resultados') : '';
    if (findState.matches.length) go(1);
  };
  const go = (d) => {
    const m = findState.matches;
    if (!m.length) return;
    findState.i = (findState.i + d + m.length) % m.length;
    const it = m[findState.i];
    count.textContent = `${findState.i + 1} de ${m.length}`;
    b.select([it.id]);
    b.vp.fit(G.aabb(it, b.map), { maxZ: Math.max(1, b.vp.z), pad: 160 });
  };
  input.addEventListener('input', run);
  input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); go(e.shiftKey ? -1 : 1); input.blur(); } });
  bar.innerHTML = '';
  bar.append(h('span.find-ic', { html: icon('search', 18) }), input, count,
    h('button.btn.icon', { html: icon('chevron-left', 20), title: 'Anterior', onclick: () => go(-1) }),
    h('button.btn.icon', { html: icon('chevron-right', 20), title: 'Siguiente', onclick: () => go(1) }),
    h('button.btn', { text: 'OK', onclick: () => closeFind(b) }));
  bar.classList.add('in');
  setTimeout(() => input.focus(), 50);
}

export function closeFind() {
  findState = null;
  const bar = document.getElementById('find-bar');
  bar.classList.remove('in');
  bar.innerHTML = '';
}

// Menús de la barra superior ----------------------------------------------------------------
export function titleMenu(b, anchor) {
  const meta = store.meta;
  menu(anchor, [
    { label: 'Renombrar', icon: 'pencil', act: () => renameBoard(b) },
    { label: meta.favorite ? 'Quitar de favoritos' : 'Añadir a favoritos', icon: 'star', act: () => { meta.favorite = !meta.favorite; b.save(); } },
    { label: 'Duplicar tablero', icon: 'copy', act: () => b.app.duplicateBoard(meta.id, true) },
    { label: 'Mover a carpeta', icon: 'folder', act: () => moveToFolder(meta, anchor) },
    { label: 'Etiquetas', icon: 'sparkles', act: () => editTags(meta, anchor) },
    { sep: true },
    { label: 'Exportar como PDF', icon: 'file-text', act: () => exportBoard(b, 'pdf') },
    { label: NB.isNotebook() ? 'Exportar la página como imagen' : 'Exportar como imagen', icon: 'image', act: () => exportBoard(b, 'png') },
    { label: 'Copia del tablero (.lienzo)', icon: 'download', act: () => exportBoard(b, 'lienzo') },
    { sep: true },
    { label: 'Eliminar tablero', icon: 'trash-2', danger: true, act: async () => { if (await confirm('¿Eliminar este tablero?', 'Se moverá a «Eliminados recientemente» durante 30 días.', { ok: 'Eliminar', danger: true })) b.app.trashBoard(meta.id); } },
  ]);
}

export async function renameBoard(b) {
  const n = await prompt('Nombre del tablero', store.meta.title);
  if (!n) return;
  store.meta.title = n;
  document.getElementById('b-title').querySelector('span').textContent = n;
  b.save();
}

export function shareMenu(b, anchor) {
  if (NB.isNotebook()) {
    menu(anchor, [
      { label: 'Exportar cuaderno en PDF', icon: 'file-text', act: () => exportBoard(b, 'pdf') },
      { label: `Exportar la página ${NB.currentPage(b) + 1} en PDF`, icon: 'file-text', act: () => exportBoard(b, 'pdf-page') },
      { label: `Página ${NB.currentPage(b) + 1} como imagen (PNG)`, icon: 'image', act: () => exportBoard(b, 'png') },
      b.sel.size ? { label: 'Exportar la selección como imagen', icon: 'square-dashed', act: () => exportBoard(b, 'png-sel') } : null,
      { sep: true },
      { label: 'Copia del cuaderno (.lienzo)', icon: 'download', act: () => exportBoard(b, 'lienzo') },
    ]);
    return;
  }
  menu(anchor, [
    { label: 'Exportar como PDF', icon: 'file-text', act: () => exportBoard(b, 'pdf') },
    store.scenes.length ? { label: 'PDF con una página por escena', icon: 'presentation', act: () => exportBoard(b, 'pdf-scenes') } : null,
    { label: 'Exportar como imagen (PNG)', icon: 'image', act: () => exportBoard(b, 'png') },
    b.sel.size ? { label: 'Exportar la selección como imagen', icon: 'square-dashed', act: () => exportBoard(b, 'png-sel') } : null,
    { sep: true },
    { label: 'Copia del tablero (.lienzo)', icon: 'download', act: () => exportBoard(b, 'lienzo') },
  ]);
}

export async function exportBoard(b, kind) {
  if (b.editing) b.stopEditing();
  const items = store.items;
  const nb = NB.isNotebook();
  if (!items.length && kind !== 'lienzo' && !nb) { toast('El tablero está vacío'); return; }
  const title = store.meta.title || 'Tablero';
  const busy = h('div.toast.busy.in', { html: '<span class="spin"></span>Preparando…' });
  document.getElementById('overlay').append(busy);
  try {
    if (nb && kind === 'pdf') await shareBlob(`${title}.pdf`, await exportNotebookPDF(items, store.content()));
    else if (nb && kind === 'pdf-page') { const i = NB.currentPage(b); await shareBlob(`${title} (página ${i + 1}).pdf`, await exportNotebookPDF(items, store.content(), i)); }
    else if (nb && kind === 'png') { const i = NB.currentPage(b); await shareBlob(`${title} (página ${i + 1}).png`, await notebookPagePNG(items, store.content(), i)); }
    else if (kind === 'png') await shareBlob(`${title}.png`, await exportPNG(items));
    else if (kind === 'png-sel') { const sel = b.selItems(); await shareBlob(`${title} (selección).png`, await exportPNG(items, contentBox(sel))); }
    else if (kind === 'pdf') await shareBlob(`${title}.pdf`, await exportPDF(items, [contentBox(items)]));
    else if (kind === 'pdf-scenes') await shareBlob(`${title}.pdf`, await exportPDF(items, store.scenes.map(sceneBox)));
    else if (kind === 'lienzo') {
      const data = await boardToJSON(store.meta, store.content());
      await shareBlob(`${title}.lienzo`, new Blob([JSON.stringify(data)], { type: 'application/json' }));
    }
  } catch (e) { console.error(e); toast('No se pudo exportar'); }
  finally { busy.remove(); }
}

export function moreMenu(b, anchor) {
  if (NB.isNotebook()) {
    menu(anchor, [
      { label: 'Páginas', icon: 'files', act: () => NB.pagesPanel(b, document.getElementById('page-pill')) },
      { label: 'Añadir página', icon: 'file-plus', act: () => NB.addPage(b, NB.currentPage(b)) },
      { label: 'Papel de la página', icon: 'file-text', act: () => NB.templatePicker(b, anchor) },
      { label: 'Presentar página a página', icon: 'play', act: () => startPresent(b) },
      { sep: true },
      { label: 'Buscar en el cuaderno', icon: 'search', act: () => openFind(b) },
      { label: 'Seleccionar todo', icon: 'square-dashed', act: () => b.selectAll() },
      { label: 'Ajustar la página a la pantalla', icon: 'maximize', act: () => b.fitContent() },
      { sep: true },
      { label: 'Guías de alineación', checked: !!settings.snap, act: () => { settings.snap = !settings.snap; } },
      { label: 'Ajustes', icon: 'settings', act: () => b.app.settingsPanel(anchor) },
    ]);
    return;
  }
  menu(anchor, [
    { label: 'Escenas', icon: 'presentation', act: () => scenesPanel(b, anchor) },
    { label: 'Añadir escena', icon: 'plus', act: () => addScene(b) },
    { label: 'Presentar', icon: 'play', act: () => startPresent(b) },
    { sep: true },
    { label: 'Buscar en el tablero', icon: 'search', act: () => openFind(b) },
    { label: 'Seleccionar todo', icon: 'square-dashed', act: () => b.selectAll() },
    { label: 'Ajustar a la pantalla', icon: 'maximize', act: () => b.fitContent() },
    { sep: true },
    { label: 'Fondo: puntos', checked: store.bg === 'dots', act: () => store.setBg('dots') },
    { label: 'Fondo: cuadrícula', checked: store.bg === 'grid', act: () => store.setBg('grid') },
    { label: 'Fondo: líneas', checked: store.bg === 'lines', act: () => store.setBg('lines') },
    { label: 'Fondo: liso', checked: store.bg === 'none', act: () => store.setBg('none') },
    { sep: true },
    { label: 'Guías de alineación', checked: !!settings.snap, act: () => { settings.snap = !settings.snap; } },
    { label: 'Ajustes', icon: 'settings', act: () => b.app.settingsPanel(anchor) },
  ]);
}

export function zoomMenu(b, anchor) {
  const at = (z) => { const r = b.vp.rect(); b.vp.animateTo(...(() => { const c = b.vp.center(); return [r.width / 2 - c.x * z, r.height / 2 - c.y * z, z]; })()); };
  menu(anchor, [
    { label: 'Acercar', icon: 'zoom-in', act: () => at(Math.min(4, b.vp.z * 1.5)) },
    { label: 'Alejar', icon: 'zoom-out', act: () => at(Math.max(0.1, b.vp.z / 1.5)) },
    { sep: true },
    { label: NB.isNotebook() ? 'Ajustar la página' : 'Ajustar a la pantalla', icon: 'maximize', act: () => b.fitContent() },
    { label: '50 %', act: () => at(0.5) },
    { label: '100 %', act: () => at(1) },
    { label: '200 %', act: () => at(2) },
    store.scenes.length ? { sep: true } : null,
    ...store.scenes.map((sc) => ({ label: sc.name, icon: 'presentation', act: () => b.vp.showScene(sc) })),
  ], { placement: 'above' });
}

export { segmented };
