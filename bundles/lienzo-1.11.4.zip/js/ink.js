// Herramientas de dibujo: contorno de trazos con presión, texturas y reconocimiento de formas.
import { rdp, distToSeg, bboxOfPoints } from './geom.js';
import { getStroke } from '../vendor/perfect-freehand.mjs';

/**
 * Escritura como en GoodNotes (punta 'pf', desde la 1.11), con perfect-freehand: el trazo sigue al lápiz con suavidad
 * y la presión se reparte a lo largo del trazo. Cada lápiz, como su equivalente de GoodNotes:
 *  Pluma (estilográfica de GoodNotes): redondeada y sólida; la presión solo la matiza (±15 %).
 *  Bolígrafo: grosor constante, sin presión.
 *  Pincel (pluma pincel): rozar casi un pelo y apretar muy grueso, con los dos extremos acabando en punta.
 * En las puntas finas la presión se nota menos (para que apretar no engorde de golpe).
 */
function freehandPath(flat, tool, size) {
  const pts = [];
  for (let i = 0; i < flat.length; i += 3) pts.push([flat[i], flat[i + 1], Math.min(1, Math.max(0.02, flat[i + 2] ?? 0.5))]);
  if (!pts.length) return '';
  const sz = TOOLS[tool]?.sizes || TOOLS.pen.sizes;
  const t = Math.min(1, Math.max(0, Math.log(size / sz[0]) / Math.log(sz[sz.length - 1] / sz[0])));   // 0 punta fina, 1 gruesa
  let len = 0;
  for (let i = 1; i < pts.length; i++) len += Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]);
  const base = { size, smoothing: 0.62, streamline: 0.5, simulatePressure: false, last: true, start: { cap: true }, end: { cap: true } };
  const opts = tool === 'monoline' ? { ...base, thinning: 0 }
    : tool === 'fountain' ? { ...base, thinning: 0.6 + 0.2 * t, streamline: 0.45, easing: (x) => Math.sin((x * Math.PI) / 2),
      start: { cap: false, taper: Math.min(size * 5, len * 0.3) }, end: { cap: false, taper: Math.min(size * 8, len * 0.35) } }
    : { ...base, thinning: 0.12 + 0.04 * t };
  const outline = getStroke(pts, opts);
  if (outline.length < 3) { const [x, y] = pts[0], r = size / 2; return `M${f2(x - r)},${f2(y)}a${f2(r)},${f2(r)} 0 1,0 ${f2(r * 2)},0a${f2(r)},${f2(r)} 0 1,0 ${f2(-r * 2)},0Z`; }
  // Contorno con curvas por los puntos medios (sin esquinas).
  const avg = (a, b) => f2((a + b) / 2);
  let d = `M${f2(outline[0][0])},${f2(outline[0][1])}Q${f2(outline[1][0])},${f2(outline[1][1])} ${avg(outline[1][0], outline[2][0])},${avg(outline[1][1], outline[2][1])}T`;
  for (let i = 2; i < outline.length - 1; i++) d += `${avg(outline[i][0], outline[i + 1][0])},${avg(outline[i][1], outline[i + 1][1])} `;
  return d + 'Z';
}

export const TOOLS = {
  pen:        { name: 'Pluma',          sizes: [1.5, 2.5, 4, 6, 10],   size: 2,  kind: 'fill' },
  monoline:   { name: 'Bolígrafo',      sizes: [1.5, 2.5, 4, 6, 10],   size: 2,  kind: 'stroke' },
  fountain:   { name: 'Pincel',  sizes: [1.5, 2.5, 4, 6, 10],   size: 2,  kind: 'fill' },
  marker:     { name: 'Rotulador',      sizes: [8, 12, 18, 26, 36],    size: 2,  kind: 'fill', alpha: 0.6, blend: true },
  // pressureAlpha: [base, extra] — el lápiz y la cera se ven más claros cuanto menos aprietas (como el grafito).
  pencil:     { name: 'Lápiz',          sizes: [1.5, 2.5, 4, 6, 9],    size: 2,  kind: 'fill', alpha: 0.92, filter: 'tx-pencil', pressureAlpha: [0.38, 0.85] },
  crayon:     { name: 'Cera',           sizes: [6, 9, 13, 18, 24],     size: 2,  kind: 'fill', alpha: 0.95, filter: 'tx-crayon', pressureAlpha: [0.6, 0.6] },
  watercolor: { name: 'Acuarela',       sizes: [10, 16, 24, 34, 46],   size: 2,  kind: 'fill', alpha: 0.38, filter: 'tx-water', blend: true },
};
export const ERASER_SIZES = [8, 16, 28, 44, 64];
export const DRAW_TOOLS = Object.keys(TOOLS);

const toPts = (flat) => { const o = []; for (let i = 0; i < flat.length; i += 3) o.push({ x: flat[i], y: flat[i + 1], p: flat[i + 2] }); return o; };
const f2 = (n) => Math.round(n * 100) / 100;

/**
 * Estabilizado tipo GoodNotes: una pasada extra de suavizado (1-4-6-4-1) sobre posición y presión. Los
 * extremos no se mueven, así el trazo empieza y acaba donde tocaste, pero los temblores de la mano desaparecen.
 */
function stabilize(pts) {
  if (pts.length < 5) return pts;
  const out = pts.map((p) => ({ ...p }));
  for (let i = 2; i < pts.length - 2; i++) {
    for (const k of ['x', 'y', 'p']) out[i][k] = (pts[i - 2][k] + 4 * pts[i - 1][k] + 6 * pts[i][k] + 4 * pts[i + 1][k] + pts[i + 2][k]) / 16;
  }
  return out;
}

/**
 * Curva suave por los puntos del lápiz (Catmull-Rom centrípeta, un método estándar): al escribir deprisa el lápiz
 * manda pocos puntos y unirlos en línea recta dejaba quiebros («a trozos»). Así el trazo es una curva continua,
 * con un punto cada `step` de recorrido. La presión se reparte en línea recta entre punto y punto.
 */
function resample(pts, step) {
  if (pts.length < 3) return pts;
  const out = [pts[0]];
  const d = (a, b) => Math.max(1e-4, Math.sqrt(Math.hypot(b.x - a.x, b.y - a.y)));
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[i - 1] || pts[i], p1 = pts[i], p2 = pts[i + 1], p3 = pts[i + 2] || pts[i + 1];
    const len = Math.hypot(p2.x - p1.x, p2.y - p1.y);
    const n = Math.max(1, Math.min(40, Math.ceil(len / step)));
    const t0 = 0, t1 = t0 + d(p0, p1), t2 = t1 + d(p1, p2), t3 = t2 + d(p2, p3);
    const lerp = (a, b, ta, tb, t) => { const w = (t - ta) / (tb - ta || 1); return { x: a.x + (b.x - a.x) * w, y: a.y + (b.y - a.y) * w }; };
    for (let k = 1; k <= n; k++) {
      const u = k / n, t = t1 + (t2 - t1) * u;
      const A1 = lerp(p0, p1, t0, t1, t), A2 = lerp(p1, p2, t1, t2, t), A3 = lerp(p2, p3, t2, t3, t);
      const B1 = lerp(A1, A2, t0, t2, t), B2 = lerp(A2, A3, t1, t3, t);
      const C = lerp(B1, B2, t1, t2, t);
      out.push({ x: C.x, y: C.y, p: p1.p + (p2.p - p1.p) * u });
    }
  }
  return out;
}

/** Contorno sin puntos de sobra (la curva ya es suave): ocupa menos y se dibuja más rápido. */
function slimPoly(poly, size) {
  return poly.length > 24 ? rdp(poly, Math.max(0.04, size * 0.015)) : poly;
}

function prepare(flat, size, stab = 0) {
  let pts = toPts(flat);
  // Elimina puntos casi duplicados.
  const minD = Math.max(0.4, size * 0.12);
  const out = [pts[0]];
  for (let i = 1; i < pts.length; i++) {
    const l = out[out.length - 1];
    if (Math.hypot(pts[i].x - l.x, pts[i].y - l.y) >= minD || i === pts.length - 1) out.push(pts[i]);
  }
  pts = out;
  // Suavizado ligero (media móvil ponderada) de posición y presión.
  if (pts.length > 3) {
    const s = pts.map((p) => ({ ...p }));
    for (let i = 1; i < pts.length - 1; i++) {
      s[i].x = (pts[i - 1].x + pts[i].x * 2 + pts[i + 1].x) / 4;
      s[i].y = (pts[i - 1].y + pts[i].y * 2 + pts[i + 1].y) / 4;
      s[i].p = (pts[i - 1].p + pts[i].p * 2 + pts[i + 1].p) / 4;
    }
    pts = s;
  }
  // Estabilizado del pulso (sobre los puntos reales, antes de trazar la curva entre ellos).
  for (let k = 0; k < stab; k++) pts = stabilize(pts);
  return resample(pts, Math.min(2.5, Math.max(0.6, size * 0.35)));
}

/**
 * Presión por tramos adaptada al grosor elegido: escribir normal (p≈0,5) da justo el grosor; rozar y apretar lo
 * cambian en proporción a la punta (en la más fina apretar engorda poco; en la más gruesa, mucho).
 * fuerte: la Estilográfica (mucha diferencia); si no, la Pluma (casi uniforme, como la de GoodNotes: del 88 % al 115 %).
 */
function pressureMul(p, tool, size, fuerte) {
  const s = TOOLS[tool]?.sizes || TOOLS.pen.sizes;
  const t = Math.min(1, Math.max(0, Math.log(size / s[0]) / Math.log(s[s.length - 1] / s[0])));   // 0 = la más fina, 1 = la más gruesa
  const lo = fuerte ? 0.42 - 0.27 * t : 0.88 - 0.05 * t;   // rozar
  const hi = fuerte ? 1.35 + 0.55 * t : 1.08 + 0.07 * t;   // apretar
  p = Math.min(1, Math.max(0, p));
  return p < 0.5 ? lo + (1 - lo) * Math.pow(p / 0.5, 0.85) : 1 + (hi - 1) * Math.pow((p - 0.5) / 0.5, 1.15);
}

/** Presión suavizada a lo largo del trazo (ventana de ±3 puntos): el grosor cambia sin temblores ni bultos. */
function smoothPressure(pts, win = 3) {
  if (pts.length < 5) return pts;
  return pts.map((q, i) => {
    let sum = 0, w = 0;
    for (let k = -win; k <= win; k++) { const o = pts[i + k]; if (!o) continue; const wk = win + 1 - Math.abs(k); sum += o.p * wk; w += wk; }
    return { ...q, p: sum / w };
  });
}

// Plumín de la estilográfica: canto inclinado unos 34° hacia arriba a la derecha (como se sujeta con la mano derecha).
// Los trazos hacia abajo salen gruesos y los que suben en diagonal, finos como un pelo.
const NIB = -0.6;

function radiusFn(tool, size) {
  const r = size / 2;
  switch (tool) {
    // Bolígrafo como en Freeform: rozar lo deja fino, escribir normal en medio y apretar lo engorda mucho. La velocidad
    // ya viene incluida en p al dibujar (rápido = fino, frenando = gordo), por eso p puede pasar de 1.
    case 'pen': return (p) => r * (0.2 + 2.2 * Math.pow(Math.min(p.p, 1.2), 1.6));
    // Estilográfica: manda la dirección del trazo respecto al plumín; apretar abre un poco más las puntas.
    case 'fountain': return (p, ang) => r * (0.25 + 1.5 * Math.pow(p.p, 1.3)) * (0.3 + 0.85 * Math.abs(Math.sin(ang - NIB)));
    case 'pencil': return (p) => r * (0.4 + 1.1 * p.p);
    // Monolínea con presión: escribiendo normal tiene justo su grosor de siempre; rozar afina y apretar engorda.
    case 'monoline': return (p) => r * (0.55 + 0.9 * Math.min(1, p.p));
    case 'crayon': return (p) => r * (0.55 + 0.65 * p.p);
    case 'watercolor': return (p) => r * (0.4 + 0.9 * p.p);
    default: return () => r;
  }
}

function smoothClosed(poly) {
  if (poly.length < 3) return '';
  const m = (a, b) => `${f2((a.x + b.x) / 2)},${f2((a.y + b.y) / 2)}`;
  let d = `M${m(poly[0], poly[1])}`;
  for (let i = 1; i < poly.length; i++) d += `Q${f2(poly[i].x)},${f2(poly[i].y)} ${m(poly[i], poly[(i + 1) % poly.length])}`;
  d += `Q${f2(poly[0].x)},${f2(poly[0].y)} ${m(poly[0], poly[1])}Z`;
  return d;
}

function smoothOpen(pts) {
  if (pts.length === 1) return `M${f2(pts[0].x)},${f2(pts[0].y)}l0.01,0`;
  if (pts.length === 2) return `M${f2(pts[0].x)},${f2(pts[0].y)}L${f2(pts[1].x)},${f2(pts[1].y)}`;
  let d = `M${f2(pts[0].x)},${f2(pts[0].y)}`;
  for (let i = 1; i < pts.length - 1; i++) d += `Q${f2(pts[i].x)},${f2(pts[i].y)} ${f2((pts[i].x + pts[i + 1].x) / 2)},${f2((pts[i].y + pts[i + 1].y) / 2)}`;
  const l = pts[pts.length - 1];
  return d + `L${f2(l.x)},${f2(l.y)}`;
}

/**
 * Pluma y bolígrafo estilo Samsung: el trazo definitivo se calcula EXACTAMENTE igual que la tinta en vivo que pinta
 * Android mientras escribes (LiveInk.java): mismos puntos, misma curva de punto medio a punto medio y el mismo
 * grosor punto a punto (presión, entrada más fina y cambio suave). Así, al levantar el lápiz, el trazo definitivo
 * cae justo encima del que estabas viendo y no hay ninguna «corrección».
 */
function liveMatchPath(flat, size, tool, tip, nz) {
  const pts = toPts(flat);
  if (!pts.length) return '';
  const R = size / 2, tipIn = tip === 'sn' ? size * 1.5 : 0;
  const width = (p, dist) => {
    const ramp = tipIn > 0 ? Math.min(1, dist / tipIn) : 1, e = ramp * ramp * (3 - 2 * ramp);
    return 2 * R * widthFactor(tool, tip, p) * (0.45 + 0.55 * e);
  };
  let px = pts[0].x, py = pts[0].y, mx = px, my = py, dist = 0, w = width(pts[0].p, 0);
  const smp = [{ x: px, y: py, r: w / 2 }];
  // Android descarta los puntos a menos de 0,75 píxeles de pantalla: lo mismo aquí (en unidades del tablero).
  const minD = nz ? 0.75 / nz : 0.35, step = Math.max(0.5, size * 0.25);
  for (let i = 1; i < pts.length; i++) {
    const q = pts[i], d = Math.hypot(q.x - px, q.y - py);
    if (d < minD) continue;
    dist += d;
    const nmx = (px + q.x) / 2, nmy = (py + q.y) / 2;
    const nw = w + (width(q.p, dist) - w) * 0.45;
    const len = Math.hypot(px - mx, py - my) + Math.hypot(nmx - px, nmy - py);
    const n = Math.max(1, Math.min(24, Math.ceil(len / step)));
    for (let k = 1; k <= n; k++) {
      const t = k / n, u = 1 - t;
      smp.push({ x: u * u * mx + 2 * u * t * px + t * t * nmx, y: u * u * my + 2 * u * t * py + t * t * nmy, r: (w + (nw - w) * t) / 2 });
    }
    mx = nmx; my = nmy; px = q.x; py = q.y; w = nw;
  }
  // Igual que la tinta en vivo, el trazo acaba en el último punto medio (así no cambia nada al soltar).
  const n = smp.length;
  if (n === 1) {
    const { x, y, r: rr } = smp[0];
    return `M${f2(x - rr)},${f2(y)}a${f2(rr)},${f2(rr)} 0 1,0 ${f2(rr * 2)},0a${f2(rr)},${f2(rr)} 0 1,0 ${f2(-rr * 2)},0Z`;
  }
  const left = [], right = [], dirs = [];
  for (let i = 0; i < n; i++) {
    const a = smp[Math.max(0, i - 1)], b = smp[Math.min(n - 1, i + 1)];
    let dx = b.x - a.x, dy = b.y - a.y;
    const l = Math.hypot(dx, dy) || 1; dx /= l; dy /= l;
    dirs.push({ dx, dy });
    left.push({ x: smp[i].x - dy * smp[i].r, y: smp[i].y + dx * smp[i].r });
    right.push({ x: smp[i].x + dy * smp[i].r, y: smp[i].y - dx * smp[i].r });
  }
  const cap = (p, rr, dir, start) => {
    const out = [], base = Math.atan2(dir.dy, dir.dx) + (start ? Math.PI / 2 : -Math.PI / 2);
    for (let j = 1; j < 6; j++) { const a = base + (Math.PI * j) / 6; out.push({ x: p.x + Math.cos(a) * rr, y: p.y + Math.sin(a) * rr }); }
    return out.reverse();
  };
  return smoothClosed(slimPoly([...left, ...cap(smp[n - 1], smp[n - 1].r, dirs[n - 1], false), ...right.reverse(), ...cap(smp[0], smp[0].r, dirs[0], true)], size));
}

/** Factor de grosor (respecto a la mitad del tamaño) del cuerpo del trazo según la presión ya ajustada (0–1).
 *  Lo usa la tinta en vivo nativa para parecerse al trazo definitivo. */
export function widthFactor(tool, tip, p) {
  p = Math.min(1, Math.max(0, p));
  if (tip === 'sn') return 0.25 + 1.25 * Math.pow(p, 0.9);
  if (tip === 'mb') return 0.88 + 0.24 * p;
  if (tip === 'gf') return pressureMulPublic(p, tool);
  if (tool === 'monoline') return tip === 'pressure' ? 0.55 + 0.9 * p : 1;
  if (tool === 'pen') return 0.2 + 2.2 * Math.pow(p, 1.6);
  return 1;
}
const pressureMulPublic = (p, tool) => pressureMul(p, tool, TOOLS[tool]?.sizes?.[2] || 4, false);

/** Devuelve el trazado SVG de un trazo. kind 'fill' = contorno relleno, 'stroke' = línea con grosor. */
export function inkPath(flat, tool, size, tip, nz) {
  if (!flat?.length) return '';
  const def = TOOLS[tool] || TOOLS.pen;
  if (tool === 'marker') return markerPath(flat, size, tip);
  if (tip === 'pf') return freehandPath(flat, tool, size);
  // 'sn' Pluma estilo Samsung Notes (desde la 1.10.5).
  if (tip === 'sn') return liveMatchPath(flat, size, tool, tip, nz);
  // 'mb' Bolígrafo estilo Samsung Notes (desde la 1.11): línea limpia de grosor casi fijo, extremos redondos.
  if (tip === 'mb') return liveMatchPath(flat, size, tool, tip, nz);
  // Puntas con presión suave y extremos redondos (cada trazo guarda la suya, así lo antiguo se ve igual que siempre):
  //  'gf' Pluma (desde la 1.10): como la estilográfica de GoodNotes, fluida, sólida y con presión moderada.
  //  'gn' Estilográfica (desde la 1.10, antes era la Pluma): mucha diferencia entre rozar y apretar.
  //  'smooth' Pluma antigua (antes de la 1.10).
  const smooth = (tool === 'pen' && (tip === 'smooth' || tip === 'gn' || tip === 'gf')) || (tool === 'fountain' && tip === 'gn');
  let pts = smooth ? prepare(flat, size, 1) : prepare(flat, size);
  if (tip === 'gf') pts = smoothPressure(pts, 5);
  else if (tip === 'gn' && tool === 'fountain') pts = smoothPressure(pts);
  // Monolínea clásica (trazos antiguos): línea de grosor fijo. Con presión ('pressure') va como contorno relleno.
  if (def.kind === 'stroke' && tip !== 'pressure') return smoothOpen(pts);
  const rf = tip === 'gf' ? (p) => (size / 2) * pressureMul(p.p, tool, size, false)
    : tip === 'gn' && tool === 'fountain' ? (p) => (size / 2) * pressureMul(p.p, tool, size, true)
    // Pluma de la 1.10 (sin adaptar al grosor): se dibuja igual que cuando se escribió.
    : tip === 'gn' ? (p) => (size / 2) * (0.15 + 1.75 * Math.pow(Math.min(1, Math.max(0, p.p)), 1.1))
    : smooth ? (p) => (size / 2) * (0.5 + 1.0 * Math.min(1, p.p)) : radiusFn(tool, size);
  if (pts.length === 1) {
    const r = rf(pts[0], 0), { x, y } = pts[0];
    return `M${f2(x - r)},${f2(y)}a${f2(r)},${f2(r)} 0 1,0 ${f2(r * 2)},0a${f2(r)},${f2(r)} 0 1,0 ${f2(-r * 2)},0Z`;
  }
  // Longitud acumulada para afinar inicio y final (como un trazo real).
  const n = pts.length, acc = [0];
  for (let i = 1; i < n; i++) acc.push(acc[i - 1] + Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y));
  const total = acc[n - 1];
  const taper = smooth ? 0 : tool === 'pen' ? Math.min(size * 1.5, total / 4) : tool === 'fountain' ? Math.min(size * 2, total / 4) : 0;
  // La estilográfica mira la dirección en un tramo algo más largo, para que el grosor no tiemble en trazos lentos.
  const win = tool === 'fountain' && !smooth ? 2 : 1;
  const left = [], right = [], rads = [], dirs = [];
  for (let i = 0; i < n; i++) {
    const a = pts[Math.max(0, i - win)], b = pts[Math.min(n - 1, i + win)];
    let dx = b.x - a.x, dy = b.y - a.y;
    const l = Math.hypot(dx, dy) || 1; dx /= l; dy /= l;
    let r = rf(pts[i], Math.atan2(dy, dx));
    if (tool === 'fountain' && !smooth) {
      // Estilográfica antigua (plumín): entra y sale en punta, como la tinta de un plumín.
      const t = Math.min(acc[i], total - acc[i]) / Math.max(1, taper);
      if (t < 1) r *= 0.3 + 0.7 * t;
    } else if (taper) {
      // Bolígrafo: entra algo más fino; el final lo decide la velocidad (si frenas, acaba en gota gruesa, como en Freeform).
      const s = acc[i] / taper;
      if (s < 1) r *= 0.7 + 0.3 * s;
    }
    rads.push(r); dirs.push({ dx, dy });
    left.push({ x: pts[i].x - dy * r, y: pts[i].y + dx * r });
    right.push({ x: pts[i].x + dy * r, y: pts[i].y - dx * r });
  }
  const cap = (p, r, dir, start) => {
    const out = [], base = Math.atan2(dir.dy, dir.dx) + (start ? Math.PI / 2 : -Math.PI / 2);
    for (let k = 1; k < 6; k++) { const a = base + (Math.PI * k) / 6; out.push({ x: p.x + Math.cos(a) * r, y: p.y + Math.sin(a) * r }); }
    // Recorrido en el mismo sentido que el contorno (de un borde al otro), para que no se cruce.
    return out.reverse();
  };
  const poly = [...left, ...cap(pts[n - 1], rads[n - 1], dirs[n - 1], false), ...right.reverse(), ...cap(pts[0], rads[0], dirs[0], true)];
  return smoothClosed(slimPoly(poly, size));
}

// Subrayador ---------------------------------------------------------------------------------------
// Una punta de fieltro redondeada y algo ovalada (como un fluorescente gastado, ligeramente inclinada) que se
// desliza por el trazo. Cada tramo es la zona que barre la punta, así que ir y volver repinta el mismo sitio
// sin dientes ni huecos. El pulso se estabiliza al vuelo (sin recolocar lo ya pintado) para que fluya.
const NIB_ANGLE = 1.84;                                  // eje largo casi vertical: algo más ancho en horizontal
const NIB_U = { x: Math.cos(NIB_ANGLE), y: Math.sin(NIB_ANGLE) }, NIB_V = { x: -NIB_U.y, y: NIB_U.x };
const NIB_SHAPE = Array.from({ length: 18 }, (_, i) => { const t = (i / 18) * Math.PI * 2; return [Math.cos(t), Math.sin(t)]; });

/**
 * Punta redonda (como la monolínea) que sí engorda al apretar: rozar deja la mitad de ancho y apretar
 * un cuarto más. Va por el mismo camino que la punta biselada, así ir y volver tampoco deja huecos.
 */
function roundNibAt(p, size) {
  const r = (size / 2) * (0.45 + 0.8 * Math.min(1, p.p ?? 0.5));
  return NIB_SHAPE.map(([cu, cv]) => ({ x: p.x + cu * r, y: p.y + cv * r }));
}

function nibAt(p, size, tip) {
  if (tip === 'round') return roundNibAt(p, size);
  const k = 0.92 + 0.16 * (p.p ?? 0.5);                 // un poco de presión
  const a = (size / 2) * k, b = size * 0.4 * k;         // óvalo suave: 1 de alto por 0,8 de grueso
  return NIB_SHAPE.map(([cu, cv]) => { const u = cu * a, v = cv * b; return { x: p.x + NIB_U.x * u + NIB_V.x * v, y: p.y + NIB_U.y * u + NIB_V.y * v }; });
}

/** Envolvente convexa (siempre en el mismo sentido, para que el relleno una todos los tramos). */
function hull(points) {
  const P = [...points].sort((a, b) => a.x - b.x || a.y - b.y);
  const cross = (o, a, b) => (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x);
  const lower = [], upper = [];
  for (const p of P) { while (lower.length >= 2 && cross(lower[lower.length - 2], lower[lower.length - 1], p) <= 0) lower.pop(); lower.push(p); }
  for (let i = P.length - 1; i >= 0; i--) { const p = P[i]; while (upper.length >= 2 && cross(upper[upper.length - 2], upper[upper.length - 1], p) <= 0) upper.pop(); upper.push(p); }
  return lower.slice(0, -1).concat(upper.slice(0, -1));
}

const f1 = (n) => Math.round(n * 10) / 10;
const polyD = (poly) => 'M' + poly.map((q) => `${f1(q.x)},${f1(q.y)}`).join('L') + 'Z';

/**
 * Puntos del subrayador: suavizado «hacia delante» (cada punto solo depende de los anteriores, así lo ya
 * dibujado no se mueve al seguir escribiendo) y un último punto en la posición real del lápiz.
 * Devuelve { pts, stable }: los primeros `stable` puntos ya no cambiarán.
 */
export function markerPoints(flat, size) {
  const n = flat.length / 3;
  if (!n) return { pts: [], stable: 0 };
  const step = Math.max(0.5, size * 0.12), follow = 0.5;
  let sx = flat[0], sy = flat[1], sp = flat[2];
  const pts = [{ x: sx, y: sy, p: sp }];
  for (let i = 1; i < n; i++) {
    sx += (flat[i * 3] - sx) * follow; sy += (flat[i * 3 + 1] - sy) * follow; sp += (flat[i * 3 + 2] - sp) * follow;
    const l = pts[pts.length - 1];
    if (Math.hypot(sx - l.x, sy - l.y) >= step) pts.push({ x: sx, y: sy, p: sp });
  }
  const stable = pts.length;
  const lx = flat[(n - 1) * 3], ly = flat[(n - 1) * 3 + 1], l = pts[pts.length - 1];
  if (n > 1 && Math.hypot(lx - l.x, ly - l.y) > 0.3) pts.push({ x: lx, y: ly, p: sp });
  return { pts, stable };
}

/** Trazado de un tramo (de a a b) o de un toque (solo a). */
export function markerSegment(a, b, size, tip) {
  return polyD(b ? hull([...nibAt(a, size, tip), ...nibAt(b, size, tip)]) : nibAt(a, size, tip));
}

function markerPath(flat, size, tip) {
  const { pts } = markerPoints(flat, size);
  if (pts.length === 1) return markerSegment(pts[0], null, size, tip);
  let d = '';
  for (let i = 1; i < pts.length; i++) d += markerSegment(pts[i - 1], pts[i], size, tip);
  return d;
}

/** Atributos SVG del trazo según la herramienta. */
/** Opacidad del trazo: la de la herramienta, la elegida y, en lápiz y cera, la presión media con que se hizo. */
export function inkAlpha(it) {
  const def = TOOLS[it.tool] || TOOLS.pen;
  let a = (def.alpha ?? 1) * (it.opacity ?? 1);
  const pa = def.pressureAlpha, pts = it.pts;
  if (pa && pts?.length) {
    let sum = 0, n = 0;
    for (let i = 2; i < pts.length; i += 3) { sum += pts[i]; n++; }
    a *= Math.min(1, pa[0] + pa[1] * (sum / n));
  }
  return Math.round(a * 100) / 100;
}

/** ¿Se dibuja como línea de grosor fijo? (la monolínea antigua; la nueva sigue la presión y va rellena) */
export const isStrokeInk = (it) => (TOOLS[it.tool] || TOOLS.pen).kind === 'stroke' && it.tip !== 'pressure' && it.tip !== 'pf' && it.tip !== 'mb';

export function inkStyle(it, dark) {
  const def = TOOLS[it.tool] || TOOLS.pen;
  const alpha = inkAlpha(it);
  const attrs = isStrokeInk(it)
    ? `fill="none" stroke="${it.color}" stroke-width="${it.size}" stroke-linecap="${def.cap || 'round'}" stroke-linejoin="round"`
    : `fill="${it.color}"`;
  return `${attrs} opacity="${alpha}"${def.filter ? ` filter="url(#${def.filter})"` : ''}`;
}

/** Mezcla del trazo con lo que tiene debajo: el subrayador multiplica, así el texto de debajo sigue nítido. */
export function inkBlend(tool, dark) {
  if (!TOOLS[tool]?.blend) return '';
  return dark ? 'screen' : 'multiply';
}

/** Crea un elemento de tinta a partir de puntos del mundo [{x,y,p}]. */
export function makeInk(worldPts, { tool, color, size, opacity, tip, nz }, id) {
  const pad = size * 1.5 + 8;
  const b = bboxOfPoints(worldPts);
  const ox = b.x - pad, oy = b.y - pad, w = b.w + pad * 2, h = b.h + pad * 2;
  const pts = [];
  for (const p of worldPts) pts.push(f2(p.x - ox), f2(p.y - oy), Math.round((p.p ?? 0.5) * 100) / 100);
  const it = { id, type: 'ink', x: ox, y: oy, w, h, vw: w, vh: h, rot: 0, pts, tool, color, size, opacity };
  if (tip) it.tip = tip;
  // Escala de pantalla al escribir (zoom × densidad): la pluma y el bolígrafo Samsung la necesitan para contar los
  // mismos puntos que la tinta en vivo de Android y quedar idénticos.
  if (nz) it.nz = Math.round(nz * 100) / 100;   // subrayador de punta redonda
  return it;
}

// Reconocimiento de formas (mantener el lápiz quieto al terminar el trazo) -----------------
export function recognize(pts) {
  if (pts.length < 6) return null;
  let L = 0;
  for (let i = 1; i < pts.length; i++) L += Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y);
  if (L < 30) return null;
  const a = pts[0], z = pts[pts.length - 1];
  const gap = Math.hypot(z.x - a.x, z.y - a.y);
  const b = bboxOfPoints(pts);
  const diag = Math.hypot(b.w, b.h);

  if (gap > L * 0.3) {
    let maxD = 0;
    for (const p of pts) maxD = Math.max(maxD, distToSeg(p.x, p.y, a.x, a.y, z.x, z.y));
    if (maxD < Math.max(6, L * 0.06)) return { kind: 'line', a, b: z };
    return null;
  }
  if (gap > diag * 0.35) return null;

  const cx = b.x + b.w / 2, cy = b.y + b.h / 2, rx = b.w / 2 || 1, ry = b.h / 2 || 1;
  let err = 0;
  for (const p of pts) err += Math.abs(Math.hypot((p.x - cx) / rx, (p.y - cy) / ry) - 1);
  err /= pts.length;

  let simp = rdp(pts, diag * 0.075);
  if (simp.length > 2 && Math.hypot(simp[0].x - simp[simp.length - 1].x, simp[0].y - simp[simp.length - 1].y) < diag * 0.2) simp = simp.slice(0, -1);
  // Une vértices muy próximos.
  simp = simp.filter((p, i) => i === 0 || Math.hypot(p.x - simp[i - 1].x, p.y - simp[i - 1].y) > diag * 0.08);

  if (err < 0.11 && simp.length > 4) return { kind: 'ellipse', box: b };
  if (simp.length === 3) return { kind: 'poly', pts: simp, box: bboxOfPoints(simp) };
  if (simp.length === 4) {
    const ang = Math.atan2(simp[1].y - simp[0].y, simp[1].x - simp[0].x) * 180 / Math.PI;
    const off = Math.abs(((ang % 90) + 90) % 90);
    if (off < 12 || off > 78) return { kind: 'rect', box: b };
    return { kind: 'poly', pts: simp, box: bboxOfPoints(simp) };
  }
  if (err < 0.17) return { kind: 'ellipse', box: b };
  if (simp.length >= 5 && simp.length <= 8) return { kind: 'poly', pts: simp, box: bboxOfPoints(simp) };
  return null;
}
