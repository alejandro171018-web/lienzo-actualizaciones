// Exportación: dibuja el tablero en un canvas (miniaturas, PNG, PDF) y copias de seguridad.
import * as G from './geom.js';
import { inkPath, inkAlpha, isStrokeInk, TOOLS } from './ink.js';
import { shapeById } from './shapes.js';
import { FONTS, NOTE_COLORS } from './render.js';
import { blobURL, getBlob, putBlob, saveBoard, getContent, blobIdsOf } from './db.js';
import { loadImage, readAsDataURL, dataURLToBlob, uid, isLight } from './util.js';
import { drawTemplate, PAGE_SIZES, PAGE_GAP } from './paper.js';
import { PdfDoc, withRecordedPaths } from './pdf.js';

const imgCache = new Map();
function imageFor(id) {
  if (!imgCache.has(id)) imgCache.set(id, blobURL(id).then((u) => (u ? loadImage(u) : null)).catch(() => null));
  return imgCache.get(id);
}

function wrap(ctx, text, maxW) {
  const out = [];
  for (const para of String(text || '').split('\n')) {
    const words = para.split(/(\s+)/);
    let line = '';
    for (const w of words) {
      const test = line + w;
      if (ctx.measureText(test).width > maxW && line.trim()) { out.push(line.trimEnd()); line = w.trimStart(); }
      else line = test;
      while (ctx.measureText(line).width > maxW && line.length > 1) {
        let i = line.length - 1;
        while (i > 1 && ctx.measureText(line.slice(0, i)).width > maxW) i--;
        out.push(line.slice(0, i)); line = line.slice(i);
      }
    }
    out.push(line);
  }
  return out;
}

function fontOf(it, size) {
  const f = (FONTS[it.font || 'sans'] || FONTS.sans).css;
  return `${it.italic ? 'italic ' : ''}${it.bold ? '700' : '400'} ${size}px ${f}`;
}

function drawText(ctx, it, box, { size, align = 'left', valign = 'top', color = '#1C1C1E', pad = 8, auto = false }) {
  if (!it.text && !auto) return;
  let s = size;
  let lines;
  const maxW = box.w - pad * 2;
  for (let guard = 0; guard < 30; guard++) {
    ctx.font = fontOf(it, s);
    lines = wrap(ctx, it.text, maxW);
    if (!auto || lines.length * s * 1.25 <= box.h - pad * 2 || s < 9) break;
    s *= 0.9;
  }
  const lh = s * 1.25, total = lines.length * lh;
  let y = box.y + (valign === 'middle' ? (box.h - total) / 2 : pad);
  ctx.fillStyle = color;
  ctx.textBaseline = 'top';
  ctx.textAlign = align;
  const x = align === 'center' ? box.x + box.w / 2 : align === 'right' ? box.x + box.w - pad : box.x + pad;
  for (const l of lines) { ctx.fillText(l, x, y + (lh - s) / 2); if (it.underline || it.strike) { const w = ctx.measureText(l).width, x0 = align === 'center' ? x - w / 2 : align === 'right' ? x - w : x; ctx.fillRect(x0, y + (it.strike ? lh * 0.55 : lh * 0.92), w, Math.max(1, s / 14)); } y += lh; }
}

function roundRect(ctx, x, y, w, hh, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + hh, r); ctx.arcTo(x + w, y + hh, x, y + hh, r); ctx.arcTo(x, y + hh, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
}

function arrow(ctx, x, y, ang, w, kind) {
  const s = Math.max(10, w * 3.2);
  ctx.beginPath();
  if (kind === 'dot') ctx.arc(x, y, s * 0.38, 0, Math.PI * 2);
  else { ctx.moveTo(x, y); ctx.lineTo(x + Math.cos(ang + Math.PI * 0.84) * s, y + Math.sin(ang + Math.PI * 0.84) * s); ctx.lineTo(x + Math.cos(ang - Math.PI * 0.84) * s, y + Math.sin(ang - Math.PI * 0.84) * s); ctx.closePath(); }
  ctx.fill();
}

async function drawItem(ctx, it, map) {
  if (it.type === 'frame') return; // los marcos de página son solo una guía
  ctx.save();
  if (it.type === 'line') {
    const g = G.lineGeom(it, map);
    ctx.strokeStyle = ctx.fillStyle = it.color || '#000';
    ctx.lineWidth = it.width || 2; ctx.lineCap = 'round'; ctx.lineJoin = 'round';
    if (it.dash === 'dash') ctx.setLineDash([ctx.lineWidth * 4, ctx.lineWidth * 2.5]);
    if (it.dash === 'dot') ctx.setLineDash([0.1, ctx.lineWidth * 2.4]);
    ctx.stroke(new Path2D(g.d));
    ctx.setLineDash([]);
    if (it.arrowA) arrow(ctx, g.A.x, g.A.y, g.angA, ctx.lineWidth, it.arrowA);
    if (it.arrowB) arrow(ctx, g.B.x, g.B.y, g.angB, ctx.lineWidth, it.arrowB);
    ctx.restore();
    return;
  }
  const c = G.center(it);
  ctx.translate(c.x, c.y);
  if (it.rot) ctx.rotate((it.rot * Math.PI) / 180);
  ctx.translate(-it.w / 2, -it.h / 2);
  if (it.opacity != null && it.type !== 'ink') ctx.globalAlpha = it.opacity;
  const flip = () => { if (it.flipX || it.flipY) { ctx.translate(it.flipX ? it.w : 0, it.flipY ? it.h : 0); ctx.scale(it.flipX ? -1 : 1, it.flipY ? -1 : 1); } };
  const box = { x: 0, y: 0, w: it.w, h: it.h };
  switch (it.type) {
    case 'note': {
      ctx.shadowColor = 'rgba(0,0,0,.18)'; ctx.shadowBlur = it.w * 0.05; ctx.shadowOffsetY = it.w * 0.015;
      ctx.fillStyle = it.color || NOTE_COLORS[0]; ctx.fillRect(0, 0, it.w, it.h);
      ctx.shadowColor = 'transparent';
      const auto = !it.fsize || it.fsize === 'auto';
      drawText(ctx, it, box, { size: auto ? Math.min(48, Math.max(14, it.h / 6.5)) : it.fsize, align: it.align || 'center', valign: it.valign === 'top' ? 'top' : 'middle', color: it.tcolor || '#1C1C1E', pad: it.w * 0.08, auto });
      break;
    }
    case 'text':
      if (it.fill && it.fill !== 'none') { ctx.fillStyle = it.fill; roundRect(ctx, 0, 0, it.w, it.h, 6); ctx.fill(); }
      if (it.check) {
        // Casilla de un plan: cuadrado (con marca si está hecha) y el texto a su derecha.
        const s = (it.fsize || 24) * 0.9, y0 = 6 + (it.fsize || 24) * 0.17;
        ctx.strokeStyle = it.tcolor || '#1C1C1E'; ctx.lineWidth = Math.max(1.5, s / 12); roundRect(ctx, 6, y0, s, s, s * 0.2); ctx.stroke();
        if (it.done) { ctx.beginPath(); ctx.moveTo(6 + s * 0.22, y0 + s * 0.52); ctx.lineTo(6 + s * 0.42, y0 + s * 0.72); ctx.lineTo(6 + s * 0.8, y0 + s * 0.28); ctx.lineWidth = Math.max(2, s / 8); ctx.lineCap = 'round'; ctx.stroke(); }
        drawText(ctx, { ...it, strike: it.done || it.strike }, { x: s + 10, y: 0, w: it.w - s - 10, h: it.h }, { size: it.fsize || 24, align: 'left', color: it.done ? '#8E8E93' : (it.tcolor || '#1C1C1E'), pad: 6 });
        break;
      }
      drawText(ctx, it, box, { size: it.fsize || 24, align: it.align || 'left', color: it.tcolor || '#1C1C1E', pad: 6 });
      break;
    case 'shape': {
      const sh = shapeById(it.shape);
      const d = it.shape === 'custom' ? it.path : sh?.d;
      ctx.save(); flip();
      const p = new Path2D();
      p.addPath(new Path2D(d || ''), new DOMMatrix().scale(it.w / 100, it.h / 100));
      if (it.fill && it.fill !== 'none') { ctx.fillStyle = it.fill; ctx.fill(p, 'evenodd'); }
      if (it.stroke && it.stroke !== 'none') {
        ctx.strokeStyle = it.stroke; ctx.lineWidth = it.sw ?? 2; ctx.lineJoin = 'round';
        if (it.dash === 'dash') ctx.setLineDash([ctx.lineWidth * 3, ctx.lineWidth * 2]);
        if (it.dash === 'dot') { ctx.setLineDash([0.1, ctx.lineWidth * 2.2]); ctx.lineCap = 'round'; }
        ctx.stroke(p);
        if (sh?.deco) { const q = new Path2D(); q.addPath(new Path2D(sh.deco), new DOMMatrix().scale(it.w / 100, it.h / 100)); ctx.stroke(q); }
      }
      ctx.restore();
      const fill = it.fill && it.fill !== 'none' ? it.fill : null;
      drawText(ctx, it, box, { size: it.fsize || 20, align: it.align || 'center', valign: 'middle', color: it.tcolor || (fill && !isLight(fill) ? '#FFFFFF' : '#1C1C1E'), pad: it.w * 0.1 });
      break;
    }
    case 'ink': {
      flip();
      ctx.scale(it.w / it.vw, it.h / it.vh);
      const def = TOOLS[it.tool] || TOOLS.pen;
      ctx.globalAlpha = inkAlpha(it);
      // El subrayador se multiplica con lo de debajo, igual que en pantalla.
      if (def.blend) ctx.globalCompositeOperation = 'multiply';
      const p = new Path2D(inkPath(it.pts, it.tool, it.size, it.tip, it.nz));
      if (isStrokeInk(it)) { ctx.strokeStyle = it.color; ctx.lineWidth = it.size; ctx.lineCap = 'round'; ctx.lineJoin = 'round'; ctx.stroke(p); }
      else { ctx.fillStyle = it.color; ctx.fill(p); }
      break;
    }
    case 'emoji':
      flip();
      ctx.font = `${Math.min(it.w, it.h) * 0.82}px "Noto Color Emoji", "Apple Color Emoji", "Segoe UI Emoji", sans-serif`;
      ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      ctx.fillText(it.text, it.w / 2, it.h / 2 + it.h * 0.04);
      break;
    case 'image': {
      const img = await imageFor(it.blob);
      if (it.mask === 'circle') { ctx.beginPath(); ctx.ellipse(it.w / 2, it.h / 2, it.w / 2, it.h / 2, 0, 0, Math.PI * 2); ctx.clip(); }
      else if (it.mask === 'rounded') { roundRect(ctx, 0, 0, it.w, it.h, Math.min(it.w, it.h) * 0.12); ctx.clip(); }
      if (img) {
        const cr = it.crop || { l: 0, t: 0, r: 0, b: 0 };
        const iw = img.naturalWidth || img.width, ih = img.naturalHeight || img.height;
        flip();
        ctx.drawImage(img, cr.l * iw, cr.t * ih, iw * (1 - cr.l - cr.r), ih * (1 - cr.t - cr.b), 0, 0, it.w, it.h);
      } else { ctx.fillStyle = '#E5E5EA'; ctx.fillRect(0, 0, it.w, it.h); }
      if (it.border) { ctx.strokeStyle = it.borderColor || '#000'; ctx.lineWidth = it.border * 2; ctx.strokeRect(0, 0, it.w, it.h); }
      break;
    }
    case 'video': {
      const v = document.querySelector(`.item[data-id="${it.id}"] video`);
      try { if (v?.readyState >= 2) ctx.drawImage(v, 0, 0, it.w, it.h); else throw 0; } catch { ctx.fillStyle = '#1C1C1E'; ctx.fillRect(0, 0, it.w, it.h); }
      ctx.fillStyle = 'rgba(255,255,255,.9)';
      const r = Math.min(it.w, it.h) * 0.12;
      ctx.beginPath(); ctx.arc(it.w / 2, it.h / 2, r, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#1C1C1E'; ctx.beginPath(); ctx.moveTo(it.w / 2 - r * 0.35, it.h / 2 - r * 0.5); ctx.lineTo(it.w / 2 + r * 0.55, it.h / 2); ctx.lineTo(it.w / 2 - r * 0.35, it.h / 2 + r * 0.5); ctx.fill();
      break;
    }
    case 'file': case 'link': case 'audio': {
      ctx.shadowColor = 'rgba(0,0,0,.12)'; ctx.shadowBlur = 10; ctx.shadowOffsetY = 2;
      ctx.fillStyle = '#FFFFFF'; roundRect(ctx, 0, 0, it.w, it.h, 12); ctx.fill();
      ctx.shadowColor = 'transparent';
      let ty = 0;
      if (it.preview) { const img = await imageFor(it.preview); if (img) { const ph = it.h - 58 * (it.w / 220); ctx.save(); roundRect(ctx, 0, 0, it.w, ph, 12); ctx.clip(); ctx.drawImage(img, 0, 0, it.w, ph); ctx.restore(); ty = ph; } }
      const s = Math.max(11, Math.min(18, it.h * (it.preview ? 0.07 : 0.22)));
      const title = it.type === 'link' ? (it.title || it.url) : it.name || 'Archivo';
      ctx.font = `600 ${s}px Inter, sans-serif`; ctx.fillStyle = '#1C1C1E'; ctx.textBaseline = 'top'; ctx.textAlign = 'left';
      const x0 = it.preview ? 12 : it.h * 0.95;
      ctx.fillText(wrap(ctx, title, it.w - x0 - 12)[0] || '', x0, ty + (it.preview ? 12 : it.h * 0.25));
      ctx.font = `400 ${s * 0.82}px Inter, sans-serif`; ctx.fillStyle = '#8E8E93';
      const sub = it.type === 'link' ? (() => { try { return new URL(it.url).hostname; } catch { return it.url; } })() : it.type === 'audio' ? 'Audio' : (it.pages ? `${it.pages} pág.` : (it.name || '').split('.').pop().toUpperCase());
      ctx.fillText(sub, x0, ty + (it.preview ? 14 + s * 1.3 : it.h * 0.25 + s * 1.35));
      if (!it.preview) { ctx.fillStyle = it.type === 'link' ? '#007AFF' : it.type === 'audio' ? '#FF2D55' : '#5856D6'; roundRect(ctx, it.h * 0.18, it.h * 0.18, it.h * 0.64, it.h * 0.64, 10); ctx.fill(); }
      break;
    }
    case 'table': {
      const tw = it.colW.reduce((a, b) => a + b, 0), th = it.rowH.reduce((a, b) => a + b, 0);
      let y = 0;
      for (let r = 0; r < it.rowH.length; r++) {
        const rh = (it.rowH[r] / th) * it.h;
        let x = 0;
        for (let cIdx = 0; cIdx < it.colW.length; cIdx++) {
          const cw = (it.colW[cIdx] / tw) * it.w;
          const head = it.header && r === 0;
          ctx.fillStyle = head ? '#F2F2F7' : (it.fill || '#FFFFFF');
          ctx.fillRect(x, y, cw, rh);
          ctx.strokeStyle = it.stroke || '#C7C7CC'; ctx.lineWidth = 1; ctx.strokeRect(x, y, cw, rh);
          drawText(ctx, { ...it, text: it.cells?.[r]?.[cIdx] || '', bold: head || it.bold }, { x, y, w: cw, h: rh }, { size: it.fsize || 16, align: it.align || 'left', valign: 'middle', color: it.tcolor || '#1C1C1E', pad: 8 });
          x += cw;
        }
        y += rh;
      }
      break;
    }
    default: break;
  }
  ctx.restore();
}

/** Dibuja elementos en un canvas nuevo. box = zona del mundo; scale = píxeles por unidad. */
export async function renderToCanvas(items, box, scale, { bg = '#FFFFFF', pad = 0, page = null } = {}) {
  await document.fonts?.ready;
  const map = new Map(items.map((i) => [i.id, i]));
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round((box.w + pad * 2) * scale));
  c.height = Math.max(1, Math.round((box.h + pad * 2) * scale));
  const ctx = c.getContext('2d');
  if (bg) { ctx.fillStyle = bg; ctx.fillRect(0, 0, c.width, c.height); }
  ctx.scale(scale, scale);
  ctx.translate(-box.x + pad, -box.y + pad);
  // Página de cuaderno: papel con su plantilla y lo que se salga, recortado.
  if (page) {
    ctx.save(); ctx.translate(box.x, box.y); drawTemplate(ctx, page.tpl, box.w, box.h, page.color); ctx.restore();
    ctx.beginPath(); ctx.rect(box.x, box.y, box.w, box.h); ctx.clip();
  }
  for (const it of items) {
    try { await drawItem(ctx, it, map); } catch (e) { console.warn('render', it.type, e); }
  }
  return c;
}

export function contentBox(items) {
  const map = new Map(items.map((i) => [i.id, i]));
  return G.unionBox(items.filter((i) => i.type !== 'frame').map((i) => G.aabb(i, map)));
}

function fitScale(box, maxSide = 4096, maxArea = 12e6) {
  let s = Math.min(maxSide / box.w, maxSide / box.h, 3);
  if (box.w * box.h * s * s > maxArea) s = Math.sqrt(maxArea / (box.w * box.h));
  return s;
}

export async function thumbnail(items) {
  const visible = items.slice(-300);
  const box = contentBox(visible);
  const W = 480, H = 300;
  if (!box) return null;
  const pad = Math.max(box.w, box.h) * 0.06 + 10;
  const b2 = { x: box.x - pad, y: box.y - pad, w: box.w + pad * 2, h: box.h + pad * 2 };
  // Encaja manteniendo proporción 16:10 centrada.
  const s = Math.min(W / b2.w, H / b2.h, 1.2);
  const fb = { x: b2.x - (W / s - b2.w) / 2, y: b2.y - (H / s - b2.h) / 2, w: W / s, h: H / s };
  const c = await renderToCanvas(visible, fb, s);
  return c.toDataURL('image/jpeg', 0.78);
}

/** Miniatura de un cuaderno: la primera página sobre un fondo gris, como una libreta. */
export async function notebookThumb(items, content) {
  const { w, h: hh } = PAGE_SIZES[content.paper?.orient] || PAGE_SIZES.portrait;
  const W = 480, H = 300;
  const s = Math.min((H - 36) / hh, (W - 36) / w);
  const page = await renderToCanvas(items.filter((it) => it.y < hh + PAGE_GAP / 2).slice(-300), { x: 0, y: 0, w, h: hh }, s * 2, { page: { tpl: content.pages[0].tpl, color: content.paper.color } });
  const c = document.createElement('canvas');
  c.width = W; c.height = H;
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#E9E9EE'; ctx.fillRect(0, 0, W, H);
  const pw = w * s, ph = hh * s, x = (W - pw) / 2, y = (H - ph) / 2;
  ctx.shadowColor = 'rgba(0,0,0,.18)'; ctx.shadowBlur = 10; ctx.shadowOffsetY = 2;
  ctx.drawImage(page, x, y, pw, ph);
  return c.toDataURL('image/jpeg', 0.8);
}

/** PDF de un cuaderno: una hoja A4 por página, con su papel. */
async function rasterNotebookPDF(items, content, only = null) {
  const { w, h: hh } = PAGE_SIZES[content.paper?.orient] || PAGE_SIZES.portrait;
  const map = new Map(items.map((i) => [i.id, i]));
  const out = [];
  for (const [i, p] of content.pages.entries()) {
    if (only != null && i !== only) continue;
    const box = { x: 0, y: i * (hh + PAGE_GAP), w, h: hh };
    const its = items.filter((it) => G.boxesIntersect(G.aabb(it, map), box));
    const c = await renderToCanvas(its, box, 2.5, { page: { tpl: p.tpl, color: content.paper.color } });
    const blob = await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.92));
    out.push({ jpg: new Uint8Array(await blob.arrayBuffer()), w: c.width, h: c.height, ptW: (w * 72) / 96, ptH: (hh * 72) / 96 });
  }
  return new Blob([buildPdf(out)], { type: 'application/pdf' });
}

/** Imagen de una página del cuaderno. */
export async function notebookPagePNG(items, content, i) {
  const { w, h: hh } = PAGE_SIZES[content.paper?.orient] || PAGE_SIZES.portrait;
  const box = { x: 0, y: i * (hh + PAGE_GAP), w, h: hh };
  const map = new Map(items.map((x) => [x.id, x]));
  const c = await renderToCanvas(items.filter((it) => G.boxesIntersect(G.aabb(it, map), box)), box, 2.5, { page: { tpl: content.pages[i].tpl, color: content.paper.color } });
  return new Promise((r) => c.toBlob(r, 'image/png'));
}

export async function exportPNG(items, region) {
  const box = region || contentBox(items);
  if (!box) return null;
  const pad = 40;
  const s = fitScale({ w: box.w + pad * 2, h: box.h + pad * 2 });
  const c = await renderToCanvas(items, box, s, { pad });
  return new Promise((r) => c.toBlob(r, 'image/png'));
}

/**
 * PDF con hojas de tamaño real (A4 o Carta) a 200 ppp: cada hoja muestra una zona del tablero encajada
 * y nítida. sheets: [{ box, ptW, ptH, margin }] (margen en puntos). Se pinta hoja a hoja para no gastar memoria.
 */
async function rasterSheetsPDF(items, sheets, onProgress) {
  const DPI = 200, map = new Map(items.map((i) => [i.id, i]));
  const pages = [];
  for (const [n, sh] of sheets.entries()) {
    onProgress?.(n + 1, sheets.length);
    const W = Math.round((sh.ptW / 72) * DPI), H = Math.round((sh.ptH / 72) * DPI), m = ((sh.margin || 0) / 72) * DPI;
    const s = Math.min((W - m * 2) / sh.box.w, (H - m * 2) / sh.box.h);
    const its = items.filter((it) => G.boxesIntersect(G.aabb(it, map), sh.box));
    const inner = await renderToCanvas(its, sh.box, s);
    const c = document.createElement('canvas');
    c.width = W; c.height = H;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#FFFFFF'; ctx.fillRect(0, 0, W, H);
    ctx.drawImage(inner, Math.round((W - inner.width) / 2), Math.round((H - inner.height) / 2));
    inner.width = inner.height = 0;
    const blob = await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.9));
    c.width = c.height = 0;
    pages.push({ jpg: new Uint8Array(await blob.arrayBuffer()), w: W, h: H, ptW: sh.ptW, ptH: sh.ptH });
  }
  return new Blob([buildPdf(pages)], { type: 'application/pdf' });
}

async function rasterPDF(items, regions) {
  const pages = [];
  for (const box of regions) {
    const pad = 30;
    const s = fitScale({ w: box.w + pad * 2, h: box.h + pad * 2 }, 3000, 8e6);
    const c = await renderToCanvas(items, box, s, { pad });
    const blob = await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.92));
    pages.push({ jpg: new Uint8Array(await blob.arrayBuffer()), w: c.width, h: c.height });
  }
  return new Blob([buildPdf(pages)], { type: 'application/pdf' });
}

// PDF vectorial ------------------------------------------------------------------------------------
// Trazos, formas, flechas y textos como vectores y letras (nítidos con cualquier zoom); las fotos, a su resolución.
// Si algo falla, se hace como antes (imagen) para que exportar no deje de funcionar nunca.

/** Dibuja la zona box del tablero en una página nueva de wPt×hPt, a k puntos por unidad y desplazada (ox, oy). */
async function pdfPage(doc, items, box, { wPt, hPt, k, ox = 0, oy = 0, clip = null, page = null }) {
  const ctx = doc.page(wPt, hPt);
  ctx.fillStyle = '#FFFFFF'; ctx.fillRect(0, 0, wPt, hPt);
  ctx.translate(ox, oy); ctx.scale(k, k); ctx.translate(-box.x, -box.y);
  if (page) {
    ctx.save(); ctx.translate(box.x, box.y); drawTemplate(ctx, page.tpl, box.w, box.h, page.color); ctx.restore();
  }
  const c = clip || (page ? box : null);
  if (c) { ctx.beginPath(); ctx.rect(c.x, c.y, c.w, c.h); ctx.clip(); }
  const map = new Map(items.map((i) => [i.id, i]));
  for (const it of items) {
    try { await drawItem(ctx, it, map); } catch (err) { console.warn('pdf', it.type, err); }
  }
  await ctx.flush();
}

async function vector(build, fallback) {
  try {
    await document.fonts?.ready;
    return await withRecordedPaths(async () => { const doc = new PdfDoc(); await build(doc); return doc.build(); });
  } catch (err) {
    console.warn('PDF vectorial no disponible, se hace como imagen', err);
    return fallback();
  }
}

/** Genera un PDF con una página por zona (todo el tablero o una por escena). */
export function exportPDF(items, regions) {
  return vector(async (doc) => {
    for (const box of regions) {
      const pad = 30, W = box.w + pad * 2, H = box.h + pad * 2;
      const k = Math.min(0.75, 14000 / Math.max(W, H));   // 1 px = 0,75 pt; los PDF admiten hasta ~5 m por lado
      const area = { x: box.x - pad, y: box.y - pad, w: W, h: H };
      await pdfPage(doc, items, area, { wPt: W * k, hPt: H * k, k, clip: area });
    }
  }, () => rasterPDF(items, regions));
}

/** PDF con hojas de tamaño real (A4 o Carta): cada hoja muestra una zona del tablero encajada. */
export function exportSheetsPDF(items, sheets, onProgress) {
  return vector(async (doc) => {
    const map = new Map(items.map((i) => [i.id, i]));
    for (const [n, sh] of sheets.entries()) {
      onProgress?.(n + 1, sheets.length);
      const m = sh.margin || 0;
      const k = Math.min((sh.ptW - m * 2) / sh.box.w, (sh.ptH - m * 2) / sh.box.h);
      const its = items.filter((it) => G.boxesIntersect(G.aabb(it, map), sh.box));
      await pdfPage(doc, its, sh.box, { wPt: sh.ptW, hPt: sh.ptH, k, ox: (sh.ptW - sh.box.w * k) / 2, oy: (sh.ptH - sh.box.h * k) / 2, clip: sh.box });
    }
  }, () => rasterSheetsPDF(items, sheets, onProgress));
}

/** PDF de un cuaderno: una hoja A4 por página, con su papel. */
export function exportNotebookPDF(items, content, only = null) {
  return vector(async (doc) => {
    const { w, h: hh } = PAGE_SIZES[content.paper?.orient] || PAGE_SIZES.portrait;
    const map = new Map(items.map((i) => [i.id, i]));
    for (const [i, p] of content.pages.entries()) {
      if (only != null && i !== only) continue;
      const box = { x: 0, y: i * (hh + PAGE_GAP), w, h: hh };
      const its = items.filter((it) => G.boxesIntersect(G.aabb(it, map), box));
      await pdfPage(doc, its, box, { wPt: w * 0.75, hPt: hh * 0.75, k: 0.75, page: { tpl: p.tpl, color: content.paper.color } });
    }
  }, () => rasterNotebookPDF(items, content, only));
}

function buildPdf(pages) {
  const enc = new TextEncoder();
  const parts = [];
  const offsets = [];
  let pos = 0;
  const push = (x) => { const b = typeof x === 'string' ? enc.encode(x) : x; parts.push(b); pos += b.length; };
  const obj = (n, body) => { offsets[n] = pos; push(`${n} 0 obj\n`); for (const b of [].concat(body)) push(b); push('\nendobj\n'); };
  push('%PDF-1.4\n%\xE2\xE3\xCF\xD3\n');
  const n = pages.length;
  const pageIds = pages.map((_, i) => 3 + i * 3);
  obj(1, '<< /Type /Catalog /Pages 2 0 R >>');
  obj(2, `<< /Type /Pages /Kids [${pageIds.map((id) => `${id} 0 R`).join(' ')}] /Count ${n} >>`);
  pages.forEach((p, i) => {
    const id = pageIds[i];
    const W = p.ptW ?? (p.w * 72) / 150, H = p.ptH ?? (p.h * 72) / 150;
    const content = `q ${W.toFixed(2)} 0 0 ${H.toFixed(2)} 0 0 cm /Im0 Do Q`;
    obj(id, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${W.toFixed(2)} ${H.toFixed(2)}] /Resources << /XObject << /Im0 ${id + 1} 0 R >> >> /Contents ${id + 2} 0 R >>`);
    obj(id + 1, [`<< /Type /XObject /Subtype /Image /Width ${p.w} /Height ${p.h} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${p.jpg.length} >>\nstream\n`, p.jpg, '\nendstream']);
    obj(id + 2, `<< /Length ${content.length} >>\nstream\n${content}\nendstream`);
  });
  const total = 3 + n * 3;
  const xref = pos;
  push(`xref\n0 ${total}\n0000000000 65535 f \n`);
  for (let i = 1; i < total; i++) push(`${String(offsets[i]).padStart(10, '0')} 00000 n \n`);
  push(`trailer\n<< /Size ${total} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`);
  return new Blob(parts);
}

// Copias de seguridad ---------------------------------------------------------------------
export async function boardToJSON(meta, content) {
  const blobs = {};
  for (const id of blobIdsOf(content.items || [])) {
    const b = await getBlob(id);
    if (b) blobs[id] = await readAsDataURL(b);
  }
  return { app: 'lienzo', version: 1, meta: { title: meta.title, created: meta.created, updated: meta.updated, favorite: !!meta.favorite }, content: { items: content.items, scenes: content.scenes || [], bg: content.bg || 'dots', kind: content.kind, paper: content.paper, pages: content.pages }, blobs };
}

export async function importBoardJSON(data) {
  for (const [id, url] of Object.entries(data.blobs || {})) if (!(await getBlob(id))) await putBlob(await dataURLToBlob(url), id);
  const meta = { id: uid(), title: data.meta?.title || 'Tablero importado', created: data.meta?.created || Date.now(), updated: Date.now(), favorite: !!data.meta?.favorite, thumb: null };
  const content = { items: data.content?.items || [], scenes: data.content?.scenes || [], bg: data.content?.bg || 'dots', view: null };
  if (data.content?.kind === 'notebook' && data.content.pages?.length) Object.assign(content, { kind: 'notebook', paper: data.content.paper, pages: data.content.pages });
  meta.kind = content.kind || 'board';
  meta.thumb = await (content.kind === 'notebook' ? notebookThumb(content.items, content) : thumbnail(content.items)).catch(() => null);
  await saveBoard(meta, content);
  return meta;
}

export async function backupAll(metas) {
  const boards = [];
  for (const m of metas) boards.push(await boardToJSON(m, (await getContent(m.id)) || { items: [] }));
  return new Blob([JSON.stringify({ app: 'lienzo-backup', version: 1, date: Date.now(), boards })], { type: 'application/json' });
}
