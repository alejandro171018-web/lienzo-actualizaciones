// Herramientas de dibujo: contorno de trazos con presión, texturas y reconocimiento de formas.
import { rdp, distToSeg, bboxOfPoints } from './geom.js';

export const TOOLS = {
  pen:        { name: 'Pluma',          sizes: [1.5, 2.5, 4, 6, 10],   size: 2,  kind: 'fill' },
  monoline:   { name: 'Monolínea',      sizes: [1.5, 2.5, 4, 6, 10],   size: 2,  kind: 'stroke' },
  fountain:   { name: 'Estilográfica',  sizes: [2, 3.5, 5, 8, 12],     size: 2,  kind: 'fill' },
  marker:     { name: 'Rotulador',      sizes: [8, 12, 18, 26, 36],    size: 2,  kind: 'fill', alpha: 0.6, blend: true },
  // pressureAlpha: [base, extra] — el lápiz y la cera se ven más claros cuanto menos aprietas (como el grafito).
  pencil:     { name: 'Lápiz',          sizes: [1.5, 2.5, 4, 6, 9],    size: 2,  kind: 'fill', alpha: 0.92, filter: 'tx-pencil', pressureAlpha: [0.38, 0.85] },
  crayon:     { name: 'Cera',           sizes: [6, 9, 13, 18, 24],     size: 2,  kind: 'fill', alpha: 0.95, filter: 'tx-crayon', pressureAlpha: [0.6, 0.6] },
  watercolor: { name: 'Acuarela',       sizes: [10, 16, 24, 34, 46],   size: 2,  kind: 'fill', alpha: 0.38, filter: 'tx-water', blend: true },
};
export const ERASER_SIZES = [8, 16, 28, 44, 64];
export const DRAW_TOOLS = Object.keys(TOOLS);

const toPts = (flat) => { const o = []; for (let i = 0; i < flat.length; i += 3) o.push({ x: flat[i], y: flat[i + 1], p: flat[i + 2] }); return o; };
const f2 = (n) => Math.round(n * 100) / 100;

function prepare(flat, size) {
  let pts = toPts(flat);
  // Elimina puntos casi duplicados.
  const minD = Math.max(0.4, size * 0.12);
  const out = [pts[0]];
  for (let i = 1; i < pts.length; i++) {
    const l = out[out.length - 1];
    if (Math.hypot(pts[i].x - l.x, pts[i].y - l.y) >= minD || i === pts.length - 1) out.push(pts[i]);
  }
  pts = out;
  // Suavizado ligero (media móvil ponderada) de posición y presión.
  if (pts.length > 3) {
    const s = pts.map((p) => ({ ...p }));
    for (let i = 1; i < pts.length - 1; i++) {
      s[i].x = (pts[i - 1].x + pts[i].x * 2 + pts[i + 1].x) / 4;
      s[i].y = (pts[i - 1].y + pts[i].y * 2 + pts[i + 1].y) / 4;
      s[i].p = (pts[i - 1].p + pts[i].p * 2 + pts[i + 1].p) / 4;
    }
    pts = s;
  }
  return pts;
}

// Plumín de la estilográfica: canto inclinado unos 34° hacia arriba a la derecha (como se sujeta con la mano derecha).
// Los trazos hacia abajo salen gruesos y los que suben en diagonal, finos como un pelo.
const NIB = -0.6;

function radiusFn(tool, size) {
  const r = size / 2;
  switch (tool) {
    // Bolígrafo como en Freeform: rozar lo deja fino, escribir normal en medio y apretar lo engorda mucho. La velocidad
    // ya viene incluida en p al dibujar (rápido = fino, frenando = gordo), por eso p puede pasar de 1.
    case 'pen': return (p) => r * (0.26 + 1.5 * Math.pow(p.p, 1.3));
    // Estilográfica: manda la dirección del trazo respecto al plumín; apretar abre un poco más las puntas.
    case 'fountain': return (p, ang) => r * (0.35 + 1.1 * p.p) * (0.3 + 0.85 * Math.abs(Math.sin(ang - NIB)));
    case 'pencil': return (p) => r * (0.45 + 0.85 * p.p);
    case 'crayon': return (p) => r * (0.55 + 0.65 * p.p);
    case 'watercolor': return (p) => r * (0.4 + 0.9 * p.p);
    default: return () => r;
  }
}

function smoothClosed(poly) {
  if (poly.length < 3) return '';
  const m = (a, b) => `${f2((a.x + b.x) / 2)},${f2((a.y + b.y) / 2)}`;
  let d = `M${m(poly[0], poly[1])}`;
  for (let i = 1; i < poly.length; i++) d += `Q${f2(poly[i].x)},${f2(poly[i].y)} ${m(poly[i], poly[(i + 1) % poly.length])}`;
  d += `Q${f2(poly[0].x)},${f2(poly[0].y)} ${m(poly[0], poly[1])}Z`;
  return d;
}

function smoothOpen(pts) {
  if (pts.length === 1) return `M${f2(pts[0].x)},${f2(pts[0].y)}l0.01,0`;
  if (pts.length === 2) return `M${f2(pts[0].x)},${f2(pts[0].y)}L${f2(pts[1].x)},${f2(pts[1].y)}`;
  let d = `M${f2(pts[0].x)},${f2(pts[0].y)}`;
  for (let i = 1; i < pts.length - 1; i++) d += `Q${f2(pts[i].x)},${f2(pts[i].y)} ${f2((pts[i].x + pts[i + 1].x) / 2)},${f2((pts[i].y + pts[i + 1].y) / 2)}`;
  const l = pts[pts.length - 1];
  return d + `L${f2(l.x)},${f2(l.y)}`;
}

/** Devuelve el trazado SVG de un trazo. kind 'fill' = contorno relleno, 'stroke' = línea con grosor. */
export function inkPath(flat, tool, size) {
  if (!flat?.length) return '';
  const def = TOOLS[tool] || TOOLS.pen;
  if (tool === 'marker') return markerPath(flat, size);
  const pts = prepare(flat, size);
  if (def.kind === 'stroke') return smoothOpen(pts);
  const rf = radiusFn(tool, size);
  if (pts.length === 1) {
    const r = rf(pts[0], 0), { x, y } = pts[0];
    return `M${f2(x - r)},${f2(y)}a${f2(r)},${f2(r)} 0 1,0 ${f2(r * 2)},0a${f2(r)},${f2(r)} 0 1,0 ${f2(-r * 2)},0Z`;
  }
  // Longitud acumulada para afinar inicio y final (como un trazo real).
  const n = pts.length, acc = [0];
  for (let i = 1; i < n; i++) acc.push(acc[i - 1] + Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y));
  const total = acc[n - 1];
  const taper = tool === 'pen' ? Math.min(size * 1.5, total / 4) : tool === 'fountain' ? Math.min(size * 2, total / 4) : 0;
  // La estilográfica mira la dirección en un tramo algo más largo, para que el grosor no tiemble en trazos lentos.
  const win = tool === 'fountain' ? 2 : 1;
  const left = [], right = [], rads = [], dirs = [];
  for (let i = 0; i < n; i++) {
    const a = pts[Math.max(0, i - win)], b = pts[Math.min(n - 1, i + win)];
    let dx = b.x - a.x, dy = b.y - a.y;
    const l = Math.hypot(dx, dy) || 1; dx /= l; dy /= l;
    let r = rf(pts[i], Math.atan2(dy, dx));
    if (tool === 'fountain') {
      // Estilográfica: entra y sale en punta, como la tinta de un plumín.
      const t = Math.min(acc[i], total - acc[i]) / Math.max(1, taper);
      if (t < 1) r *= 0.3 + 0.7 * t;
    } else if (taper) {
      // Bolígrafo: entra algo más fino; el final lo decide la velocidad (si frenas, acaba en gota gruesa, como en Freeform).
      const s = acc[i] / taper;
      if (s < 1) r *= 0.7 + 0.3 * s;
    }
    rads.push(r); dirs.push({ dx, dy });
    left.push({ x: pts[i].x - dy * r, y: pts[i].y + dx * r });
    right.push({ x: pts[i].x + dy * r, y: pts[i].y - dx * r });
  }
  const cap = (p, r, dir, start) => {
    const out = [], base = Math.atan2(dir.dy, dir.dx) + (start ? Math.PI / 2 : -Math.PI / 2);
    for (let k = 1; k < 6; k++) { const a = base + (Math.PI * k) / 6; out.push({ x: p.x + Math.cos(a) * r, y: p.y + Math.sin(a) * r }); }
    // Recorrido en el mismo sentido que el contorno (de un borde al otro), para que no se cruce.
    return out.reverse();
  };
  const poly = [...left, ...cap(pts[n - 1], rads[n - 1], dirs[n - 1], false), ...right.reverse(), ...cap(pts[0], rads[0], dirs[0], true)];
  return smoothClosed(poly);
}

// Subrayador ---------------------------------------------------------------------------------------
// Una punta de fieltro redondeada y algo ovalada (como un fluorescente gastado, ligeramente inclinada) que se
// desliza por el trazo. Cada tramo es la zona que barre la punta, así que ir y volver repinta el mismo sitio
// sin dientes ni huecos. El pulso se estabiliza al vuelo (sin recolocar lo ya pintado) para que fluya.
const NIB_ANGLE = 1.84;                                  // eje largo casi vertical: algo más ancho en horizontal
const NIB_U = { x: Math.cos(NIB_ANGLE), y: Math.sin(NIB_ANGLE) }, NIB_V = { x: -NIB_U.y, y: NIB_U.x };
const NIB_SHAPE = Array.from({ length: 18 }, (_, i) => { const t = (i / 18) * Math.PI * 2; return [Math.cos(t), Math.sin(t)]; });

function nibAt(p, size) {
  const k = 0.92 + 0.16 * (p.p ?? 0.5);                 // un poco de presión
  const a = (size / 2) * k, b = size * 0.4 * k;         // óvalo suave: 1 de alto por 0,8 de grueso
  return NIB_SHAPE.map(([cu, cv]) => { const u = cu * a, v = cv * b; return { x: p.x + NIB_U.x * u + NIB_V.x * v, y: p.y + NIB_U.y * u + NIB_V.y * v }; });
}

/** Envolvente convexa (siempre en el mismo sentido, para que el relleno una todos los tramos). */
function hull(points) {
  const P = [...points].sort((a, b) => a.x - b.x || a.y - b.y);
  const cross = (o, a, b) => (a.x - o.x) * (b.y - o.y) - (a.y - o.y) * (b.x - o.x);
  const lower = [], upper = [];
  for (const p of P) { while (lower.length >= 2 && cross(lower[lower.length - 2], lower[lower.length - 1], p) <= 0) lower.pop(); lower.push(p); }
  for (let i = P.length - 1; i >= 0; i--) { const p = P[i]; while (upper.length >= 2 && cross(upper[upper.length - 2], upper[upper.length - 1], p) <= 0) upper.pop(); upper.push(p); }
  return lower.slice(0, -1).concat(upper.slice(0, -1));
}

const f1 = (n) => Math.round(n * 10) / 10;
const polyD = (poly) => 'M' + poly.map((q) => `${f1(q.x)},${f1(q.y)}`).join('L') + 'Z';

/**
 * Puntos del subrayador: suavizado «hacia delante» (cada punto solo depende de los anteriores, así lo ya
 * dibujado no se mueve al seguir escribiendo) y un último punto en la posición real del lápiz.
 * Devuelve { pts, stable }: los primeros `stable` puntos ya no cambiarán.
 */
export function markerPoints(flat, size) {
  const n = flat.length / 3;
  if (!n) return { pts: [], stable: 0 };
  const step = Math.max(0.5, size * 0.12), follow = 0.5;
  let sx = flat[0], sy = flat[1], sp = flat[2];
  const pts = [{ x: sx, y: sy, p: sp }];
  for (let i = 1; i < n; i++) {
    sx += (flat[i * 3] - sx) * follow; sy += (flat[i * 3 + 1] - sy) * follow; sp += (flat[i * 3 + 2] - sp) * follow;
    const l = pts[pts.length - 1];
    if (Math.hypot(sx - l.x, sy - l.y) >= step) pts.push({ x: sx, y: sy, p: sp });
  }
  const stable = pts.length;
  const lx = flat[(n - 1) * 3], ly = flat[(n - 1) * 3 + 1], l = pts[pts.length - 1];
  if (n > 1 && Math.hypot(lx - l.x, ly - l.y) > 0.3) pts.push({ x: lx, y: ly, p: sp });
  return { pts, stable };
}

/** Trazado de un tramo (de a a b) o de un toque (solo a). */
export function markerSegment(a, b, size) {
  return polyD(b ? hull([...nibAt(a, size), ...nibAt(b, size)]) : nibAt(a, size));
}

function markerPath(flat, size) {
  const { pts } = markerPoints(flat, size);
  if (pts.length === 1) return markerSegment(pts[0], null, size);
  let d = '';
  for (let i = 1; i < pts.length; i++) d += markerSegment(pts[i - 1], pts[i], size);
  return d;
}

/** Atributos SVG del trazo según la herramienta. */
/** Opacidad del trazo: la de la herramienta, la elegida y, en lápiz y cera, la presión media con que se hizo. */
export function inkAlpha(it) {
  const def = TOOLS[it.tool] || TOOLS.pen;
  let a = (def.alpha ?? 1) * (it.opacity ?? 1);
  const pa = def.pressureAlpha, pts = it.pts;
  if (pa && pts?.length) {
    let sum = 0, n = 0;
    for (let i = 2; i < pts.length; i += 3) { sum += pts[i]; n++; }
    a *= Math.min(1, pa[0] + pa[1] * (sum / n));
  }
  return Math.round(a * 100) / 100;
}

export function inkStyle(it, dark) {
  const def = TOOLS[it.tool] || TOOLS.pen;
  const alpha = inkAlpha(it);
  const attrs = def.kind === 'stroke'
    ? `fill="none" stroke="${it.color}" stroke-width="${it.size}" stroke-linecap="${def.cap || 'round'}" stroke-linejoin="round"`
    : `fill="${it.color}"`;
  return `${attrs} opacity="${alpha}"${def.filter ? ` filter="url(#${def.filter})"` : ''}`;
}

/** Mezcla del trazo con lo que tiene debajo: el subrayador multiplica, así el texto de debajo sigue nítido. */
export function inkBlend(tool, dark) {
  if (!TOOLS[tool]?.blend) return '';
  return dark ? 'screen' : 'multiply';
}

/** Crea un elemento de tinta a partir de puntos del mundo [{x,y,p}]. */
export function makeInk(worldPts, { tool, color, size, opacity }, id) {
  const pad = size * 1.5 + 8;
  const b = bboxOfPoints(worldPts);
  const ox = b.x - pad, oy = b.y - pad, w = b.w + pad * 2, h = b.h + pad * 2;
  const pts = [];
  for (const p of worldPts) pts.push(f2(p.x - ox), f2(p.y - oy), Math.round((p.p ?? 0.5) * 100) / 100);
  return { id, type: 'ink', x: ox, y: oy, w, h, vw: w, vh: h, rot: 0, pts, tool, color, size, opacity };
}

// Reconocimiento de formas (mantener el lápiz quieto al terminar el trazo) -----------------
export function recognize(pts) {
  if (pts.length < 6) return null;
  let L = 0;
  for (let i = 1; i < pts.length; i++) L += Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y);
  if (L < 30) return null;
  const a = pts[0], z = pts[pts.length - 1];
  const gap = Math.hypot(z.x - a.x, z.y - a.y);
  const b = bboxOfPoints(pts);
  const diag = Math.hypot(b.w, b.h);

  if (gap > L * 0.3) {
    let maxD = 0;
    for (const p of pts) maxD = Math.max(maxD, distToSeg(p.x, p.y, a.x, a.y, z.x, z.y));
    if (maxD < Math.max(6, L * 0.06)) return { kind: 'line', a, b: z };
    return null;
  }
  if (gap > diag * 0.35) return null;

  const cx = b.x + b.w / 2, cy = b.y + b.h / 2, rx = b.w / 2 || 1, ry = b.h / 2 || 1;
  let err = 0;
  for (const p of pts) err += Math.abs(Math.hypot((p.x - cx) / rx, (p.y - cy) / ry) - 1);
  err /= pts.length;

  let simp = rdp(pts, diag * 0.075);
  if (simp.length > 2 && Math.hypot(simp[0].x - simp[simp.length - 1].x, simp[0].y - simp[simp.length - 1].y) < diag * 0.2) simp = simp.slice(0, -1);
  // Une vértices muy próximos.
  simp = simp.filter((p, i) => i === 0 || Math.hypot(p.x - simp[i - 1].x, p.y - simp[i - 1].y) > diag * 0.08);

  if (err < 0.11 && simp.length > 4) return { kind: 'ellipse', box: b };
  if (simp.length === 3) return { kind: 'poly', pts: simp, box: bboxOfPoints(simp) };
  if (simp.length === 4) {
    const ang = Math.atan2(simp[1].y - simp[0].y, simp[1].x - simp[0].x) * 180 / Math.PI;
    const off = Math.abs(((ang % 90) + 90) % 90);
    if (off < 12 || off > 78) return { kind: 'rect', box: b };
    return { kind: 'poly', pts: simp, box: bboxOfPoints(simp) };
  }
  if (err < 0.17) return { kind: 'ellipse', box: b };
  if (simp.length >= 5 && simp.length <= 8) return { kind: 'poly', pts: simp, box: bboxOfPoints(simp) };
  return null;
}
