// Dónde busca la app las actualizaciones (repositorio público con la versión web compilada).
export const UPDATE_MANIFEST = 'https://raw.githubusercontent.com/alejandro171018-web/lienzo-actualizaciones/main/latest.json';
