// Presión del S Pen.
//
// El S Pen manda la presión de 0 a 1, pero cada tablet (y cada mano) la usa a su manera: en muchas Samsung,
// escribir normal ya da casi 1, así que todos los trazos salían igual de gordos y apretar no cambiaba nada.
// Aquí se aprende sola cuál es TU rango real (lo que más se repite al escribir) y se reparte entre el trazo
// fino y el gordo: escribir normal queda en el medio, rozar adelgaza y apretar engorda de verdad.
// La calibración manual (Ajustes) sigue mandando si la has hecho.
import { settings } from './settings.js';

const BINS = 50;          // histograma de 0 a 1 en pasos de 0,02
const MIN_SPAN = 0.22;    // aunque escribas siempre igual, no se exagera el temblor de la mano
let cache = null;

/** Rango aprendido { min, max } o null si aún no hay datos suficientes. */
export function autoRange() {
  if (cache !== null) return cache || null;
  const h = settings.pressureHist;
  cache = false;
  if (!Array.isArray(h) || h.length !== BINS) return null;
  const total = h.reduce((a, b) => a + b, 0);
  if (total < 120) return null;   // unos pocos trazos antes de fiarse
  const at = (q) => {
    let acc = 0;
    for (let i = 0; i < BINS; i++) { acc += h[i]; if (acc >= q * total) return (i + 0.5) / BINS; }
    return 1;
  };
  let lo = at(0.06), hi = at(0.94);
  if (hi - lo < MIN_SPAN) { const mid = (lo + hi) / 2; lo = mid - MIN_SPAN / 2; hi = mid + MIN_SPAN / 2; }
  // Lo de arriba del todo queda para cuando aprietas más de lo normal.
  hi = Math.min(1, hi + (hi - lo) * 0.12);
  cache = { min: Math.max(0, lo), max: hi };
  return cache;
}

/** Se llama al terminar cada trazo con el S Pen, con la presión tal como llegó (sin el principio ni el final). */
export function learnPressure(raw) {
  if (!raw || raw.length < 8) return;
  const k = Math.floor(raw.length * 0.15);
  const mid = raw.slice(k, raw.length - k);
  let h = settings.pressureHist;
  if (!Array.isArray(h) || h.length !== BINS) h = new Array(BINS).fill(0);
  // Lo antiguo pesa cada vez menos: si cambias de forma de escribir, se adapta.
  const decay = 0.985;
  h = h.map((v) => Math.round(v * decay * 100) / 100);
  // Cada trazo cuenta lo mismo, sea largo o corto (hasta 40 muestras).
  const step = Math.max(1, Math.floor(mid.length / 40));
  for (let i = 0; i < mid.length; i += step) {
    const p = mid[i];
    if (!(p > 0)) continue;
    h[Math.min(BINS - 1, Math.floor(Math.min(1, p) * BINS))] += 1;
  }
  settings.pressureHist = h;
  cache = null;
}

export function resetLearnedPressure() { settings.pressureHist = null; cache = null; }

/**
 * Presión lista para dibujar (0–1): tu rango real repartido entre fino y gordo, con la sensibilidad de cada lápiz.
 * Con sensibilidad 0 el lápiz no cambia de grosor.
 */
export function penPressure(raw, tool) {
  const cal = settings.pressureCal || autoRange();
  let n = cal ? (raw - cal.min) / Math.max(0.05, cal.max - cal.min) : raw;
  n = Math.min(1, Math.max(0, n));
  const sens = (settings.tools[tool]?.sens ?? 60) / 60;   // 0 = sin presión, 60 = normal, 100 = muy sensible
  return Math.min(1, Math.max(0.03, 0.5 + (n - 0.5) * sens));
}
