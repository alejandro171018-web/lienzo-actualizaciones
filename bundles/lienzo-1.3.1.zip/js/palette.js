// Paleta de herramientas de dibujo (estilo iPad): lápices, borrador, lazo, láser, regla y colores.
// Se puede arrastrar y anclar abajo, arriba, a la izquierda o a la derecha, y minimizar.
import { settings, saveSettings } from './settings.js';
import { TOOLS, DRAW_TOOLS, ERASER_SIZES } from './ink.js';
import { h, icon } from './util.js';
import { popover, colorPicker, segmented, slider, menu, closeAllPopovers } from './ui.js';
import { store } from './store.js';

export const PALETTE_TOOLS = [...DRAW_TOOLS, 'eraser', 'lasso', 'laser'];
const NAMES = { eraser: 'Borrador', lasso: 'Lazo', laser: 'Puntero láser' };
export const toolName = (t) => TOOLS[t]?.name || NAMES[t] || t;
/** Herramientas que usan color (los lápices y el láser). */
export const hasColor = (t) => !!TOOLS[t] || t === 'laser';

/** Ilustración de cada herramienta (caja de 34×92, punta hacia arriba). La punta usa el color actual. */
export function toolSVG(tool, color, opacity = 1) {
  const line = 'stroke="var(--pk-line)" stroke-width=".8"';
  const body = `<rect x="6" y="40" width="22" height="56" fill="url(#pkBody)" ${line}/><path d="M9 42v52" stroke="#fff" stroke-opacity=".7" stroke-width="1.4"/>`;
  const band = `<rect x="6" y="44" width="22" height="4.5" fill="${color}"/>`;
  const cone = (d) => `<path d="${d}" fill="url(#pkBody)" ${line}/>`;
  const tips = {
    pen: cone('M6 40 L17 7 L28 40Z') + `<path d="M14.6 14.2 L17 7 L19.4 14.2Z" fill="${color}"/>` + body + band,
    monoline: cone('M6 40 L14 13 Q17 6.5 20 13 L28 40Z') + `<path d="M14.3 14.2 Q17 7.6 19.7 14.2Z" fill="${color}"/>` + body + band,
    fountain: `<path d="M6 40 L9.5 26 L24.5 26 L28 40Z" fill="#3A3A3C" ${line}/><path d="M10.5 26 L17 3 L23.5 26Z" fill="url(#pkMetal)" ${line}/><path d="M17 9 V22" stroke="#6E6E73" stroke-width=".8"/><circle cx="17" cy="20" r="1.3" fill="#6E6E73"/><path d="M15.7 7.4 L17 3 L18.3 7.4Z" fill="${color}"/>` + body + band,
    marker: cone('M6 40 L8.5 19 L25.5 13 L28 40Z') + `<path d="M8.5 19 L25.5 13 L25.5 19.5 L8.5 25.5Z" fill="${color}" ${line}/>` + body + band,
    pencil: `<path d="M6 40 L17 7 L28 40 Q25 37.5 22.5 40 Q20 37.5 17 40 Q14 37.5 11.5 40 Q9 37.5 6 40Z" fill="url(#pkWood)" ${line}/><path d="M14.3 15 L17 7 L19.7 15Z" fill="${color}"/>` + body + band,
    crayon: `<path d="M8 40 L9 17 Q17 4 25 17 L26 40Z" fill="${color}" ${line}/><path d="M9.5 24 H24.5" stroke="#000" stroke-opacity=".12" stroke-width="1.2"/>` + `<rect x="6" y="40" width="22" height="56" fill="url(#pkBody)" ${line}/><rect x="6" y="52" width="22" height="16" fill="${color}" opacity=".85"/><path d="M6 56 H28 M6 64 H28" stroke="#fff" stroke-opacity=".5"/>`,
    watercolor: `<path d="M9 40 L10 25 L24 25 L25 40Z" fill="url(#pkMetal)" ${line}/><path d="M10 25 Q8.5 13 17 3 Q25.5 13 24 25Z" fill="${color}" ${line}/>` + body,
    eraser: `<path d="M6 96 V22 Q6 9 17 9 Q28 9 28 22 V96Z" fill="url(#pkBody)" ${line}/><path d="M6 30 H28" stroke="var(--pk-line)" stroke-width=".8"/><path d="M9 24 V94" stroke="#fff" stroke-opacity=".7" stroke-width="1.4"/>`,
    lasso: cone('M6 40 L17 14 L28 40Z') + `<circle cx="17" cy="10" r="6.2" fill="none" stroke="var(--accent)" stroke-width="1.6" stroke-dasharray="2.6 2"/>` + body,
    laser: `<path d="M6 40 L12 19 L22 19 L28 40Z" fill="#2C2C2E" ${line}/><circle cx="17" cy="13" r="5.5" fill="${color}" opacity=".35"/><circle cx="17" cy="13" r="3.4" fill="${color}"/><circle cx="17" cy="13" r="1.3" fill="#fff"/>` + `<rect x="6" y="40" width="22" height="56" fill="#3A3A3C" ${line}/><path d="M9 42v52" stroke="#fff" stroke-opacity=".18" stroke-width="1.4"/>`,
  };
  const op = opacity < 1 ? `<text x="17" y="78" text-anchor="middle" font-size="8.5" font-weight="600" fill="var(--fg3)" font-family="Inter, sans-serif">${Math.round(opacity * 100)}</text>` : '';
  return `<svg viewBox="0 0 34 96" class="pk-svg">${tips[tool] || tips.pen}${op}</svg>`;
}

export class Palette {
  constructor(board) {
    this.b = board;
    this.el = document.getElementById('palette');
    this.tempEraser = false;
    this.build();
    this.bindDrag();
  }

  build() {
    const el = this.el;
    el.innerHTML = '';
    this.undoBtn = h('button.pk-icon', { title: 'Deshacer', html: icon('undo-2', 20), onclick: () => this.b.undo() });
    this.redoBtn = h('button.pk-icon', { title: 'Rehacer', html: icon('redo-2', 20), onclick: () => this.b.redo() });
    const tools = h('div.pk-tools');
    for (const t of PALETTE_TOOLS) {
      tools.append(h('button.pk-tool', { 'data-tool': t, title: toolName(t), 'aria-label': toolName(t), onclick: (e) => this.pick(t, e.currentTarget) }, h('span.pk-body')));
    }
    this.tools = tools;
    this.rulerBtn = h('button.pk-icon', { title: 'Regla', html: icon('ruler', 22), onclick: () => { settings.rulerOn = !settings.rulerOn; this.refresh(); this.b.renderRuler(); } });
    this.colors = h('div.pk-colors');
    this.wheel = h('button.pk-wheel', { title: 'Más colores', onclick: (e) => this.openPicker(e.currentTarget) });
    const more = h('button.pk-icon', { title: 'Opciones', html: icon('ellipsis', 22), onclick: (e) => this.options(e.currentTarget) });
    this.mini = h('button.pk-mini', { title: 'Mostrar herramientas', onclick: () => { if (!this.dragMoved) this.setMin(false); } });
    el.append(h('div.pk-grip', { title: 'Arrastra para mover la paleta' }), h('div.pk-group.pk-undo', {}, this.undoBtn, this.redoBtn), tools,
      h('div.pk-group.pk-colgroup', {}, this.colors), h('div.pk-group.pk-ruler', {}, this.rulerBtn, more), this.mini);
    this.applyDock();
    this.refresh();
  }

  show(on) {
    this.el.classList.toggle('in', on);
    if (!on) this.setMin(false, true);
    if (on) this.refresh();
  }

  applyDock() {
    const dock = settings.paletteDock || 'bottom';
    this.el.classList.remove('dock-bottom', 'dock-top', 'dock-left', 'dock-right');
    this.el.classList.add('dock-' + dock);
    this.b.root.dataset.dock = dock;
  }

  /** Minimizar: queda solo un círculo con la herramienta actual (como en iPad). */
  setMin(on, silent) {
    this.el.classList.toggle('min', on);
    if (!silent) this.refresh();
  }
  autoMinimize() { if (settings.paletteAutoMin && this.el.classList.contains('in')) this.setMin(true); }

  updateUndo() {
    this.undoBtn.disabled = !store.canUndo();
    this.redoBtn.disabled = !store.canRedo();
  }

  /** Herramienta que se ve activa (el borrador mientras se mantiene el botón del S Pen). */
  shownTool() { return this.tempEraser ? 'eraser' : settings.tool; }

  refresh() {
    const active = this.shownTool();
    for (const btn of this.tools.children) {
      const t = btn.dataset.tool;
      const cfg = settings.tools[t];
      const color = cfg?.color || '#000';
      const body = btn.querySelector('.pk-body');
      body.innerHTML = toolSVG(t, color, TOOLS[t] ? cfg.opacity ?? 1 : 1);
      if (TOOLS[t]) {
        const sz = TOOLS[t].sizes[cfg.size];
        body.append(h('i.pk-width', { style: { height: `${Math.min(7, Math.max(1.5, sz / 4))}px`, background: color } }));
      }
      btn.classList.toggle('on', t === active);
    }
    this.rulerBtn.classList.toggle('on', !!settings.rulerOn);
    const cur = hasColor(settings.tool) ? settings.tools[settings.tool].color : null;
    this.colors.innerHTML = '';
    for (const c of settings.quickColors) {
      this.colors.append(h('button.pk-sw' + (cur && cur.toUpperCase() === c.toUpperCase() ? '.on' : ''), { style: { background: c, color: c }, title: c, onclick: () => this.setColor(c) }));
    }
    // El arcoíris va dentro de la cuadrícula de colores, como en iPad.
    this.colors.insertBefore(this.wheel, this.colors.children[4] || null);
    this.wheel.classList.toggle('on', !!cur && !settings.quickColors.some((c) => c.toUpperCase() === cur.toUpperCase()));
    this.wheel.style.setProperty('--cur', cur || 'transparent');
    this.mini.innerHTML = '';
    this.mini.append(h('span.pk-body', { html: toolSVG(active, settings.tools[active]?.color || '#000') }));
    this.updateUndo();
  }

  pick(t, btn) {
    if (this.dragMoved) return;
    if (settings.tool === t) { this.toolOptions(t, btn); return; }
    this.select(t);
  }

  select(t) {
    if (settings.tool !== 'eraser') settings.prevTool = settings.tool;
    settings.tool = t;
    if (TOOLS[t]) settings.lastDraw = t;
    if (t !== 'lasso') this.b.clearSel();
    this.refresh();
  }

  /** Alterna entre el borrador y la herramienta anterior (clic del botón del S Pen). */
  toggleEraser() {
    if (settings.tool === 'eraser') this.select(settings.prevTool && settings.prevTool !== 'eraser' ? settings.prevTool : (settings.lastDraw || 'pen'));
    else this.select('eraser');
  }

  setTempEraser(on) {
    if (this.tempEraser === on) return;
    this.tempEraser = on;
    this.refresh();
  }

  setColor(c) {
    let t = settings.tool;
    if (!hasColor(t)) { t = settings.lastDraw || 'pen'; settings.tool = t; }
    settings.tools[t].color = c;
    saveSettings();
    this.refresh();
  }

  openPicker(anchor) {
    const t = hasColor(settings.tool) ? settings.tool : (settings.lastDraw || 'pen');
    colorPicker(anchor, {
      value: settings.tools[t].color, title: t === 'laser' ? 'Color del láser' : 'Color del lápiz', keep: false,
      onChange: (c) => { settings.tools[t].color = c; saveSettings(); this.refresh(); },
    });
  }

  toolOptions(t, anchor) {
    const body = h('div.pop-pad.pk-opts');
    const placement = this.popPlacement();
    if (TOOLS[t]) {
      const cfg = settings.tools[t];
      body.append(h('div.pop-title', { text: TOOLS[t].name }));
      const sizes = h('div.pk-sizes');
      TOOLS[t].sizes.forEach((s, i) => {
        sizes.append(h('button' + (cfg.size === i ? '.on' : ''), { title: `Grosor ${i + 1}`, onclick: (e) => { cfg.size = i; saveSettings(); sizes.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === e.currentTarget)); this.refresh(); } },
          h('i', { style: { width: `${Math.min(26, 3 + i * 5)}px`, height: `${Math.min(26, 3 + i * 5)}px`, background: cfg.color } })));
      });
      body.append(sizes, slider({ label: 'Opacidad', min: 5, max: 100, value: Math.round((cfg.opacity ?? 1) * 100), fmt: (v) => `${v} %`, onChange: (v) => { cfg.opacity = v / 100; saveSettings(); this.refresh(); } }));
      if (t === 'marker') body.append(h('p.pop-note', { text: 'Subraya sin tapar: el texto de debajo se sigue viendo nítido. Mantén el lápiz quieto al acabar y la línea se endereza.' }));
    } else if (t === 'eraser') {
      body.append(h('div.pop-title', { text: 'Borrador' }),
        segmented([{ value: 'pixel', label: 'De píxeles' }, { value: 'object', label: 'De objetos' }], settings.eraserMode, (v) => { settings.eraserMode = v; }));
      const sizes = h('div.pk-sizes');
      ERASER_SIZES.forEach((s, i) => sizes.append(h('button' + ((settings.eraserSize ?? 1) === i ? '.on' : ''), { onclick: (e) => { settings.eraserSize = i; sizes.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === e.currentTarget)); } }, h('i', { style: { width: `${6 + i * 5}px`, height: `${6 + i * 5}px` } }))));
      body.append(sizes, h('p.pop-note', { text: 'Con el S Pen: mantén pulsado el botón lateral mientras escribes para borrar, o púlsalo sin tocar la pantalla para cambiar entre lápiz y borrador.' }));
    } else if (t === 'laser') {
      body.append(h('div.pop-title', { text: 'Puntero láser' }),
        segmented([{ value: 'trail', label: 'Trazo' }, { value: 'dot', label: 'Punto' }], settings.laserMode || 'trail', (v) => { settings.laserMode = v; }),
        h('p.pop-note', { text: 'Señala sin dibujar: el trazo brilla y desaparece solo. Ideal para presentar escenas.' }));
    } else {
      body.append(h('div.pop-title', { text: 'Lazo' }), h('p.pop-note', { text: 'Rodea trazos u objetos para seleccionarlos. Después arrástralos, cambia su color o bórralos.' }));
    }
    popover(anchor, body, { placement });
  }

  popPlacement() { const d = settings.paletteDock || 'bottom'; return d === 'top' ? 'below' : d === 'bottom' ? 'above' : 'auto'; }

  options(anchor) {
    const dock = settings.paletteDock || 'bottom';
    const setDock = (d) => { settings.paletteDock = d; this.applyDock(); };
    menu(anchor, [
      { label: 'Minimizar automáticamente', checked: !!settings.paletteAutoMin, act: () => { settings.paletteAutoMin = !settings.paletteAutoMin; } },
      { label: 'Minimizar ahora', icon: 'minimize-2', act: () => this.setMin(true) },
      { row: [
        { label: 'Abajo', icon: 'arrow-down', act: () => setDock('bottom') },
        { label: 'Izquierda', icon: 'chevron-left', act: () => setDock('left') },
        { label: 'Derecha', icon: 'chevron-right', act: () => setDock('right') },
        { label: 'Arriba', icon: 'arrow-up', act: () => setDock('top') },
      ] },
      { sep: true },
      { label: 'Dibujar con el dedo: automático', checked: settings.fingerDraw === 'auto', act: () => { settings.fingerDraw = 'auto'; } },
      { label: 'Dibujar siempre con el dedo', checked: settings.fingerDraw === 'on', act: () => { settings.fingerDraw = 'on'; } },
      { label: 'Solo el S Pen dibuja (el dedo desplaza)', checked: settings.fingerDraw === 'off', act: () => { settings.fingerDraw = 'off'; settings.penSeen = true; } },
      { sep: true },
      { label: 'Reconocer formas al mantener el lápiz', checked: !!settings.autoShape, act: () => { settings.autoShape = !settings.autoShape; } },
      { label: 'Borrar haciendo un garabato encima', checked: settings.scribbleErase !== false, act: () => { settings.scribbleErase = settings.scribbleErase === false; } },
      { label: 'Grosor fijo en pantalla (no crece con el zoom)', checked: !!settings.inkScreenWidth, act: () => { settings.inkScreenWidth = !settings.inkScreenWidth; } },
      { label: 'Vista previa al acercar el S Pen', checked: settings.hoverPreview !== false, act: () => { settings.hoverPreview = settings.hoverPreview === false; } },
      { label: 'Mostrar regla', checked: !!settings.rulerOn, act: () => { settings.rulerOn = !settings.rulerOn; this.refresh(); this.b.renderRuler(); } },
      { label: 'Personalizar colores rápidos', icon: 'palette', act: () => this.editQuick(anchor) },
      { sep: true },
      { label: 'Terminar de dibujar', icon: 'check', act: () => this.b.setMode('select') },
    ], { placement: this.popPlacement() });
    void dock;
  }

  editQuick(anchor) {
    const row = h('div.pk-colors.edit');
    settings.quickColors.forEach((c, i) => row.append(h('button.pk-sw', { style: { background: c }, onclick: (e) => colorPicker(e.currentTarget, { value: c, onChange: (nc) => { settings.quickColors[i] = nc; saveSettings(); e.target.style.background = nc; this.refresh(); } }) })));
    popover(anchor, h('div.pop-pad', {}, h('div.pop-title', { text: 'Toca un color para cambiarlo' }), row), { placement: this.popPlacement() });
  }

  // Arrastrar para anclar en otro borde ------------------------------------------------
  bindDrag() {
    const el = this.el;
    let drag = null;
    el.addEventListener('pointerdown', (e) => {
      if (el.classList.contains('min')) { drag = { x0: e.clientX, y0: e.clientY, armed: true, mini: true }; }
      else if (e.target.closest('button') && !e.target.closest('.pk-tool')) return;
      else drag = { x0: e.clientX, y0: e.clientY, armed: !e.target.closest('.pk-tool'), tool: !!e.target.closest('.pk-tool'), t0: performance.now() };
      this.dragMoved = false;
      drag.id = e.pointerId;
    });
    el.addEventListener('pointermove', (e) => {
      if (!drag) return;
      const d = Math.hypot(e.clientX - drag.x0, e.clientY - drag.y0);
      // Sobre un lápiz hay que arrastrar más para no confundirlo con un toque.
      if (!this.dragMoved && d > (drag.tool ? 26 : 8)) {
        this.dragMoved = true;
        closeAllPopovers();
        const r = el.getBoundingClientRect();
        drag.offX = drag.x0 - r.left; drag.offY = drag.y0 - r.top;
        el.classList.add('dragging');
        try { el.setPointerCapture(drag.id); } catch { /* */ }
        this.b.root.classList.add('palette-dragging');
      }
      if (!this.dragMoved) return;
      el.style.left = `${e.clientX - drag.offX}px`;
      el.style.top = `${e.clientY - drag.offY}px`;
      this.showDockHint(this.nearestDock(e.clientX, e.clientY));
    });
    const end = (e) => {
      if (!drag) return;
      const moved = this.dragMoved;
      if (moved) {
        settings.paletteDock = this.nearestDock(e.clientX, e.clientY);
        el.classList.remove('dragging');
        el.style.left = el.style.top = '';
        this.b.root.classList.remove('palette-dragging');
        this.showDockHint(null);
        this.applyDock();
      }
      drag = null;
      // El clic que sigue a un arrastre no debe activar un botón.
      setTimeout(() => { this.dragMoved = false; }, 0);
    };
    el.addEventListener('pointerup', end);
    el.addEventListener('pointercancel', end);
  }

  nearestDock(x, y) {
    const W = innerWidth, H = innerHeight;
    const d = { left: x / W, right: (W - x) / W, top: (y / H) * 1.25, bottom: (H - y) / H };
    return Object.entries(d).sort((a, b) => a[1] - b[1])[0][0];
  }

  showDockHint(dock) {
    let hint = this.b.root.querySelector('.dock-hint');
    if (!dock) { hint?.remove(); return; }
    if (!hint) { hint = h('div.dock-hint'); this.b.root.append(hint); }
    hint.className = 'dock-hint at-' + dock;
  }
}
