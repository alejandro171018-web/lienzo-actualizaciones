// Preferencias del usuario (guardadas en el dispositivo).
import { TOOLS, DRAW_TOOLS } from './ink.js';

const KEY = 'lienzo.settings';
const defaults = {
  fingerDraw: 'auto',   // 'auto': el dedo dibuja hasta que se usa el S Pen; 'on' | 'off'
  snap: true,           // guías de alineación
  autoShape: true,      // mantener el lápiz quieto al final convierte el trazo en forma
  theme: 'system',      // 'system' | 'light' | 'dark'
  homeView: 'grid',
  sort: 'updated',
  tool: 'pen',
  eraserMode: 'pixel',
  eraserSize: 1,
  rulerOn: false,
  tools: Object.fromEntries(DRAW_TOOLS.map((t) => [t, { color: t === 'marker' ? '#FFCC00' : t === 'watercolor' ? '#007AFF' : '#000000', size: TOOLS[t].size, opacity: 1 }])),
  quickColors: ['#FFCC00', '#000000', '#FF3B30', '#007AFF', '#34C759'],
  penSeen: false,
  paletteDock: 'left',  // 'bottom' | 'top' | 'left' | 'right'
  paletteAutoMin: false,
  hoverPreview: true,
  laserMode: 'trail',     // 'trail' | 'dot'
};

let data;
try { data = { ...defaults, ...JSON.parse(localStorage.getItem(KEY) || '{}') }; } catch { data = { ...defaults }; }
defaults.tools.laser = { color: '#FF3B30', size: 2, opacity: 1 };
for (const t of [...DRAW_TOOLS, 'laser']) data.tools[t] = { ...defaults.tools[t], ...(data.tools?.[t] || {}) };

export const settings = new Proxy(data, {
  set(obj, k, v) {
    obj[k] = v;
    try { localStorage.setItem(KEY, JSON.stringify(obj)); } catch { /* sin almacenamiento */ }
    return true;
  },
});
export const saveSettings = () => { try { localStorage.setItem(KEY, JSON.stringify(data)); } catch { /* */ } };
