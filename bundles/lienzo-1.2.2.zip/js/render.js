// Renderizado DOM de los elementos del tablero, con actualización incremental (solo lo que cambia).
import { esc, icon, fmtSize, isLight } from './util.js';
import { inkPath, inkStyle, inkBlend } from './ink.js';
import { shapeById } from './shapes.js';
import { lineGeom } from './geom.js';
import { blobURL, cachedURL } from './db.js';

export const FONTS = {
  sans: { name: 'Sistema', css: 'Inter, system-ui, sans-serif' },
  serif: { name: 'Serif', css: '"Noto Serif", Georgia, "Times New Roman", serif' },
  mono: { name: 'Monoespaciada', css: 'ui-monospace, "Roboto Mono", "Droid Sans Mono", monospace' },
  hand: { name: 'Manuscrita', css: 'Caveat, "Comic Sans MS", cursive' },
};

export const NOTE_COLORS = ['#FFE380', '#FFC58F', '#FFB3C1', '#E4C1F9', '#A9D6FF', '#B8F0B0', '#E5E5EA'];

const darkMQ = matchMedia('(prefers-color-scheme: dark)');
export const isDark = () => document.documentElement.dataset.theme === 'dark' || (document.documentElement.dataset.theme !== 'light' && darkMQ.matches);

/** En modo oscuro, el negro de la tinta se vuelve blanco y viceversa (como en iPad). */
export function adaptInk(color) {
  if (!isDark() || !color) return color;
  const c = color.toUpperCase();
  if (c === '#000000' || c === '#1C1C1E' || c === '#000') return '#F2F2F7';
  if (c === '#FFFFFF' || c === '#FFF') return '#000000';
  return color;
}

export function textStyle(it, defaults = {}) {
  const f = FONTS[it.font || defaults.font || 'sans'] || FONTS.sans;
  const st = [`font-family:${f.css}`, `text-align:${it.align || defaults.align || 'left'}`];
  if (it.fsize && it.fsize !== 'auto') st.push(`font-size:${it.fsize}px`);
  if (it.bold) st.push('font-weight:700');
  if (it.italic) st.push('font-style:italic');
  const deco = [it.underline && 'underline', it.strike && 'line-through'].filter(Boolean).join(' ');
  if (deco) st.push(`text-decoration:${deco}`);
  if (it.tcolor) st.push(`color:${adaptInk(it.tcolor)}`);
  return st.join(';');
}

function arrowHead(x, y, ang, w, kind) {
  const s = Math.max(10, w * 3.2);
  if (kind === 'dot') return `<circle cx="${x}" cy="${y}" r="${s * 0.38}" />`;
  const a1 = ang + Math.PI * 0.84, a2 = ang - Math.PI * 0.84;
  return `<path d="M${x},${y} L${x + Math.cos(a1) * s},${y + Math.sin(a1) * s} L${x + Math.cos(a2) * s},${y + Math.sin(a2) * s} Z" />`;
}

const PLACEHOLDER_IMG = 'data:image/gif;base64,R0lGODlhAQABAAAAACw=';

export class Renderer {
  constructor(world) {
    this.world = world;
    this.els = new Map();   // id -> { item, el, deps }
    this.map = new Map();
    this.editing = null;
    this.onMeasure = null;  // (id, h) => void, para textos que crecen
  }

  elOf(id) { return this.els.get(id)?.el; }

  /** Sincroniza el DOM con la lista de elementos. */
  sync(items, force = false) {
    const map = new Map(items.map((i) => [i.id, i]));
    this.map = map;
    for (const [id, rec] of this.els) if (!map.has(id)) { rec.el.remove(); this.els.delete(id); }
    let prevEl = null;
    for (const it of items) {
      let rec = this.els.get(it.id);
      const depsChanged = it.type === 'line' && rec && (['a', 'b'].some((e) => it[e]?.id && map.get(it[e].id) !== rec.deps?.[e]));
      if (rec && rec.item !== it && this.editing?.id === it.id && !force) {
        // Elemento en edición: solo se actualizan estilos para no perder el cursor.
        this.patchEditing(rec.el, it, map);
        rec.item = it;
      } else if (!rec || rec.item !== it || depsChanged || force) {
        const el = this.build(it, map);
        if (rec) rec.el.replaceWith(el);
        rec = { item: it, el, deps: it.type === 'line' ? { a: map.get(it.a?.id), b: map.get(it.b?.id) } : null };
        this.els.set(it.id, rec);
        if (this.editing?.id === it.id) el.classList.add('editing');
      }
      // Orden en el DOM = orden de apilado.
      const expected = prevEl ? prevEl.nextSibling : this.world.firstChild;
      if (rec.el !== expected) this.world.insertBefore(rec.el, expected);
      prevEl = rec.el;
    }
  }

  patchEditing(el, it, map) {
    const fresh = this.build(it, map);
    el.style.cssText = fresh.style.cssText;
    for (const sel of ['.txt', '.tbl']) {
      const a = el.querySelector(sel), b = fresh.querySelector(sel);
      if (a && b) a.setAttribute('style', b.getAttribute('style'));
    }
    const sa = el.querySelector('svg.shp'), sb = fresh.querySelector('svg.shp');
    if (sa && sb) sa.replaceWith(sb);
  }

  /** Fuerza a reconstruir un elemento en el siguiente sync. */
  invalidate(id) { const rec = this.els.get(id); if (rec) rec.item = null; }

  build(it, map) {
    const el = document.createElement('div');
    el.className = `item t-${it.type}`;
    el.dataset.id = it.id;
    if (it.type === 'line') return this.buildLine(el, it, map);
    el.style.cssText = `left:${it.x}px;top:${it.y}px;width:${it.w}px;height:${it.h}px;${it.rot ? `transform:rotate(${it.rot}deg);` : ''}${it.flipX || it.flipY ? `--fx:${it.flipX ? -1 : 1};--fy:${it.flipY ? -1 : 1};` : ''}`;
    if (it.opacity != null && it.type !== 'ink') el.style.opacity = it.opacity;
    const fn = this['r_' + it.type];
    if (fn) fn.call(this, el, it); else el.textContent = '?';
    return el;
  }

  r_note(el, it) {
    el.style.background = it.color || NOTE_COLORS[0];
    el.innerHTML = `<div class="txt" style="${textStyle(it, { align: 'center' })}">${esc(it.text)}</div>`;
    el.classList.toggle('valign-top', it.valign === 'top');
    this.fitText(el, it);
  }

  r_text(el, it) {
    el.style.height = 'auto';
    el.style.minHeight = '20px';
    el.innerHTML = `<div class="txt" style="${textStyle(it)};font-size:${it.fsize || 24}px">${esc(it.text) || ''}</div>`;
    if (it.fill && it.fill !== 'none') el.style.background = it.fill;
    queueMicrotask(() => requestAnimationFrame(() => {
      if (!el.isConnected) return;
      const hNow = el.offsetHeight;
      if (Math.abs(hNow - it.h) > 1) this.onMeasure?.(it.id, hNow);
    }));
  }

  r_shape(el, it) {
    const sh = shapeById(it.shape) || { d: it.path || '' };
    const d = it.shape === 'custom' ? it.path : sh.d;
    const fill = it.fill && it.fill !== 'none' ? it.fill : 'none';
    const stroke = it.stroke && it.stroke !== 'none' ? adaptInk(it.stroke) : 'none';
    const sw = it.sw ?? 2;
    const dash = it.dash === 'dash' ? `stroke-dasharray="${sw * 3} ${sw * 2}"` : it.dash === 'dot' ? `stroke-dasharray="0.1 ${sw * 2.2}" stroke-linecap="round"` : '';
    el.innerHTML = `<svg class="shp" viewBox="0 0 100 100" preserveAspectRatio="none" style="transform:scale(var(--fx,1),var(--fy,1))">
      <path d="${d}" fill="${fill}" fill-rule="evenodd" stroke="${stroke}" stroke-width="${sw}" ${dash} vector-effect="non-scaling-stroke" stroke-linejoin="round"/>
      ${sh.deco ? `<path d="${sh.deco}" fill="none" stroke="${stroke === 'none' ? 'rgba(0,0,0,.25)' : stroke}" stroke-width="${sw}" vector-effect="non-scaling-stroke"/>` : ''}
    </svg><div class="txt" style="${textStyle(it, { align: 'center' })};font-size:${it.fsize || 20}px;${!it.tcolor ? `color:${fill === 'none' ? 'var(--fg)' : isLight(fill) ? '#1C1C1E' : '#FFFFFF'}` : ''}">${esc(it.text)}</div>`;
  }

  r_ink(el, it) {
    const blend = inkBlend(it.tool, isDark());
    if (blend) el.style.mixBlendMode = blend;
    const d = it._d || inkPath(it.pts, it.tool, it.size);
    el.innerHTML = `<svg viewBox="0 0 ${it.vw} ${it.vh}" preserveAspectRatio="none" style="transform:scale(var(--fx,1),var(--fy,1))"><path d="${d}" ${inkStyle({ ...it, color: adaptInk(it.color) }, isDark())}/></svg>`;
  }

  r_emoji(el, it) {
    el.innerHTML = `<div class="emo" style="font-size:${Math.min(it.w, it.h) * 0.82}px;transform:scale(var(--fx,1),var(--fy,1))">${esc(it.text)}</div>`;
  }

  r_image(el, it) {
    const src = cachedURL(it.blob);
    const c = it.crop || { l: 0, t: 0, r: 0, b: 0 };
    const fw = it.w / (1 - c.l - c.r), fh = it.h / (1 - c.t - c.b);
    el.innerHTML = `<div class="clip mask-${it.mask || 'none'}"><img draggable="false" alt="" src="${src || PLACEHOLDER_IMG}" style="width:${fw}px;height:${fh}px;left:${-c.l * fw}px;top:${-c.t * fh}px;transform:scale(var(--fx,1),var(--fy,1))"></div>`;
    if (it.border) el.firstChild.style.boxShadow = `0 0 0 ${it.border}px ${adaptInk(it.borderColor || '#000000')}`;
    if (!src) blobURL(it.blob).then((u) => { const img = el.querySelector('img'); if (u && img) img.src = u; });
  }

  r_video(el, it) {
    el.innerHTML = `<div class="clip mask-${it.mask || 'none'}"><video playsinline preload="metadata" muted="false"></video></div><button class="media-btn" data-act="play">${icon('play', 26)}</button>`;
    const v = el.querySelector('video');
    const set = (u) => { if (u) v.src = u + '#t=0.1'; };
    const u = cachedURL(it.blob); if (u) set(u); else blobURL(it.blob).then(set);
    v.addEventListener('ended', () => el.classList.remove('playing'));
  }

  r_audio(el, it) {
    el.innerHTML = `<div class="card audio"><button class="media-btn small" data-act="play">${icon('play', 20)}</button>
      <div class="meta"><b>${esc(it.name || 'Audio')}</b><span class="sub">${it.duration ? fmtDur(it.duration) : 'Audio'}</span><div class="bar"><i></i></div></div><audio preload="metadata"></audio></div>`;
    const a = el.querySelector('audio');
    const set = (u) => { if (u) a.src = u; };
    const u = cachedURL(it.blob); if (u) set(u); else blobURL(it.blob).then(set);
    a.addEventListener('timeupdate', () => { el.querySelector('.bar i').style.width = `${(a.currentTime / (a.duration || 1)) * 100}%`; });
    a.addEventListener('ended', () => el.classList.remove('playing'));
  }

  r_file(el, it) {
    const ext = (it.name || '').split('.').pop().toUpperCase().slice(0, 4);
    el.innerHTML = `<div class="card file">${it.preview ? `<div class="pv"><img draggable="false" alt=""></div>` : `<div class="fico"><span>${esc(ext)}</span></div>`}
      <div class="meta"><b>${esc(it.name || 'Archivo')}</b><span class="sub">${[it.pages ? `${it.pages} pág.` : '', it.size ? fmtSize(it.size) : ''].filter(Boolean).join(' · ')}</span></div></div>`;
    if (it.preview) {
      const img = el.querySelector('img');
      const u = cachedURL(it.preview); if (u) img.src = u; else blobURL(it.preview).then((x) => { if (x) img.src = x; });
    }
  }

  r_link(el, it) {
    let host = it.url;
    try { host = new URL(it.url).hostname.replace(/^www\./, ''); } catch { /* url libre */ }
    el.innerHTML = `<div class="card link"><div class="lico">${icon('link', 22)}</div><div class="meta"><b>${esc(it.title || host)}</b><span class="sub">${esc(host)}</span></div></div>`;
  }

  r_table(el, it) {
    const cols = it.colW, rows = it.rowH;
    const tw = cols.reduce((a, b) => a + b, 0), th = rows.reduce((a, b) => a + b, 0);
    let html = `<div class="tbl" style="${textStyle(it)};font-size:${it.fsize || 16}px;grid-template-columns:${cols.map((c) => `${(c / tw) * 100}%`).join(' ')};grid-template-rows:${rows.map((r) => `${(r / th) * 100}%`).join(' ')};--tb:${it.stroke || 'var(--tbl-line)'}">`;
    for (let r = 0; r < rows.length; r++) {
      for (let c = 0; c < cols.length; c++) {
        const head = (it.header && r === 0);
        html += `<div class="cell${head ? ' head' : ''}" data-r="${r}" data-c="${c}" style="${it.fill && !head ? `background:${it.fill}` : ''}">${esc(it.cells?.[r]?.[c] || '')}</div>`;
      }
    }
    el.innerHTML = html + '</div>';
  }

  buildLine(el, it, map) {
    const g = lineGeom(it, map);
    const pad = Math.max(20, (it.width || 2) * 5);
    let x1 = Infinity, y1 = Infinity, x2 = -Infinity, y2 = -Infinity;
    for (const p of g.samples) { x1 = Math.min(x1, p.x); y1 = Math.min(y1, p.y); x2 = Math.max(x2, p.x); y2 = Math.max(y2, p.y); }
    x1 -= pad; y1 -= pad; x2 += pad; y2 += pad;
    el.style.cssText = `left:${x1}px;top:${y1}px;width:${x2 - x1}px;height:${y2 - y1}px`;
    const color = adaptInk(it.color || '#000000'), w = it.width || 2;
    const dash = it.dash === 'dash' ? `stroke-dasharray="${w * 4} ${w * 2.5}"` : it.dash === 'dot' ? `stroke-dasharray="0.1 ${w * 2.4}"` : '';
    el.innerHTML = `<svg viewBox="${x1} ${y1} ${x2 - x1} ${y2 - y1}" width="${x2 - x1}" height="${y2 - y1}">
      <path d="${g.d}" fill="none" stroke="${color}" stroke-width="${w}" stroke-linecap="round" stroke-linejoin="round" ${dash}/>
      <g fill="${color}">${it.arrowA ? arrowHead(g.A.x, g.A.y, g.angA, w, it.arrowA) : ''}${it.arrowB ? arrowHead(g.B.x, g.B.y, g.angB, w, it.arrowB) : ''}</g></svg>`;
    return el;
  }

  /** Ajusta el tamaño de letra automático de las notas para que el texto quepa. */
  fitText(el, it) {
    if (it.fsize && it.fsize !== 'auto') return;
    const txt = el.querySelector('.txt');
    requestAnimationFrame(() => {
      if (!txt.isConnected) return;
      let size = Math.min(48, Math.max(14, it.h / 6.5));
      txt.style.fontSize = size + 'px';
      let guard = 30;
      while (guard-- > 0 && size > 9 && (txt.scrollHeight > el.clientHeight - 4 || txt.scrollWidth > el.clientWidth)) { size *= 0.9; txt.style.fontSize = size + 'px'; }
    });
  }
}

function fmtDur(s) { s = Math.round(s); return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; }
