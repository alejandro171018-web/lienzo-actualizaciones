// Insertar contenido en el tablero: notas, texto, formas, tablas, multimedia, archivos y enlaces.
import { store } from './store.js';
import { uid, h, icon, pickFiles, clamp, loadImage, fmtSize } from './util.js';
import { toast, prompt, popover, menu, closeAllPopovers } from './ui.js';
import { EMOJI } from './shapes.js';
import { putBlob, getBlob, blobURL } from './db.js';
import { shareBlob, openExternal } from './native.js';
import { settings } from './settings.js';

export const EMOJI_GROUPS = () => Object.fromEntries(Object.entries(EMOJI).map(([k, v]) => [k, v.split(' ').filter(Boolean)]));

const fsizeFor = (b, base) => Math.round(base / clamp(b.vp.z, 0.5, 1.6));

export function addNote(b, at) {
  const s = b.unit(200);
  const last = (() => { try { return localStorage.getItem('lienzo.noteColor'); } catch { return null; } })();
  const it = b.place({ id: uid(), type: 'note', w: s, h: s, rot: 0, color: last || '#FFE380', text: '', fsize: 'auto' }, at);
  b.startEditing(store.get(it.id));
}

export function addText(b, at) {
  const it = b.place({ id: uid(), type: 'text', w: b.unit(320), h: 40, rot: 0, text: '', fsize: fsizeFor(b, 24) }, at);
  b.startEditing(store.get(it.id));
}

export function addShape(b, s, at) {
  if (s.emoji) return addEmoji(b, s.emoji, at);
  const sz = b.unit(160);
  const lineLike = false;
  void lineLike;
  b.place({ id: uid(), type: 'shape', shape: s.id, w: sz, h: sz, rot: 0, fill: '#7FB2FF', stroke: 'none', sw: 2, text: '', fsize: fsizeFor(b, 20) }, at);
}

export function addEmoji(b, e, at) {
  const s = b.unit(120);
  b.place({ id: uid(), type: 'emoji', text: e, w: s, h: s, rot: 0 }, at);
}

export function addLine(b, kind) {
  const c = b.vp.center(), L = b.unit(220);
  const it = { id: uid(), type: 'line', a: { x: c.x - L / 2, y: c.y }, b: { x: c.x + L / 2, y: c.y }, style: kind === 'curve' ? 'curved' : 'straight', bend: kind === 'curve' ? -L * 0.5 : 0, color: '#000000', width: 2, arrowB: kind === 'arrow' ? 'arrow' : undefined };
  store.add(it);
  b.select([it.id]);
}

export function addTable(b, rows = 3, cols = 3) {
  const cw = b.unit(130), rh = b.unit(48);
  b.place({ id: uid(), type: 'table', w: cw * cols, h: rh * rows, rot: 0, colW: Array(cols).fill(1), rowH: Array(rows).fill(1), cells: Array.from({ length: rows }, () => Array(cols).fill('')), header: true, fsize: fsizeFor(b, 16) });
}

export function tablePicker(b, anchor) {
  const grid = h('div.tbl-pick');
  const label = h('div.pop-title', { text: 'Tabla 3 × 3' });
  let sel = [3, 3];
  for (let r = 1; r <= 8; r++) for (let c = 1; c <= 8; c++) {
    const cell = h('button', { 'data-r': r, 'data-c': c });
    const hl = () => { sel = [r, c]; label.textContent = `Tabla ${r} × ${c}`; grid.querySelectorAll('button').forEach((x) => x.classList.toggle('on', +x.dataset.r <= r && +x.dataset.c <= c)); };
    cell.addEventListener('pointerenter', hl);
    cell.addEventListener('click', () => { hl(); closeAllPopovers(); addTable(b, sel[0], sel[1]); });
    grid.append(cell);
  }
  popover(anchor, h('div.pop-pad', {}, label, grid));
  grid.querySelectorAll('button').forEach((x) => x.classList.toggle('on', +x.dataset.r <= 3 && +x.dataset.c <= 3));
}

export function normalizeUrl(u) {
  u = u.trim();
  if (!/^[a-z]+:\/\//i.test(u)) u = 'https://' + u;
  return u;
}

export async function addLink(b) {
  const url = await prompt('Añadir enlace', '', { placeholder: 'https://…', ok: 'Añadir' });
  if (!url) return;
  const title = await prompt('Título (opcional)', '', { placeholder: 'Ej.: Inspiración para la web', ok: 'Listo' });
  b.place({ id: uid(), type: 'link', url: normalizeUrl(url), title: title || '', w: b.unit(300), h: b.unit(76), rot: 0 });
}

// Imágenes ------------------------------------------------------------------------
const MAX_PX = 2600;

async function prepareImage(file, { scan = false } = {}) {
  let bmp;
  try { bmp = await createImageBitmap(file, { imageOrientation: 'from-image' }); }
  catch { const img = await loadImage(URL.createObjectURL(file)); bmp = img; }
  const w0 = bmp.width, h0 = bmp.height;
  const k = Math.min(1, MAX_PX / Math.max(w0, h0));
  const keepOriginal = k === 1 && !scan && file.size < 6e6 && /image\/(png|jpeg|webp|gif)/.test(file.type);
  if (keepOriginal) return { blob: file, w: w0, h: h0 };
  const c = document.createElement('canvas');
  c.width = Math.round(w0 * k); c.height = Math.round(h0 * k);
  const ctx = c.getContext('2d');
  ctx.drawImage(bmp, 0, 0, c.width, c.height);
  if (scan) enhanceDocument(ctx, c.width, c.height);
  const png = /png|gif|webp/.test(file.type) && !scan;
  const blob = await new Promise((r) => c.toBlob(r, png ? 'image/png' : 'image/jpeg', 0.9));
  return { blob, w: c.width, h: c.height };
}

/** Mejora un documento fotografiado: escala de grises con niveles automáticos y más contraste. */
function enhanceDocument(ctx, w, hh) {
  const img = ctx.getImageData(0, 0, w, hh), d = img.data;
  const hist = new Array(256).fill(0);
  for (let i = 0; i < d.length; i += 4) { const g = (d[i] * 0.299 + d[i + 1] * 0.587 + d[i + 2] * 0.114) | 0; d[i] = g; hist[g]++; }
  const total = w * hh;
  let lo = 0, hi = 255, acc = 0;
  for (let i = 0; i < 256; i++) { acc += hist[i]; if (acc > total * 0.02) { lo = i; break; } }
  acc = 0;
  for (let i = 255; i >= 0; i--) { acc += hist[i]; if (acc > total * 0.12) { hi = i; break; } }
  const range = Math.max(1, hi - lo);
  for (let i = 0; i < d.length; i += 4) {
    let v = ((d[i] - lo) / range) * 255;
    v = 255 / (1 + Math.exp(-(v - 128) / 34));
    d[i] = d[i + 1] = d[i + 2] = clamp(v, 0, 255);
  }
  ctx.putImageData(img, 0, 0);
}

async function addImageFile(b, file, at, opts = {}) {
  const { blob, w, h: hh } = await prepareImage(file, opts);
  const id = await putBlob(blob);
  await blobURL(id);
  const max = b.unit(opts.scan ? 520 : 440);
  const k = Math.min(1, max / Math.max(w, hh));
  return b.place({ id: uid(), type: 'image', blob: id, w: w * k, h: hh * k, rot: 0, name: file.name || 'Imagen' }, at);
}

export async function insertPhotos(b) {
  const files = await pickFiles({ accept: 'image/*,video/*', multiple: true });
  await insertFileList(b, files);
}

export async function insertCamera(b, scan = false) {
  const files = await pickFiles({ accept: 'image/*', capture: 'environment' });
  if (!files.length) return;
  const busy = toastBusy(scan ? 'Mejorando el documento…' : 'Añadiendo foto…');
  try { await addImageFile(b, files[0], null, { scan }); } finally { busy(); }
}

export async function insertFiles(b) {
  const files = await pickFiles({ accept: '*/*', multiple: true });
  await insertFileList(b, files);
}

/** Inserta varios archivos colocándolos en fila. */
export async function insertFileList(b, files, at) {
  if (!files.length) return;
  const busy = toastBusy(files.length > 1 ? `Añadiendo ${files.length} archivos…` : 'Añadiendo…');
  const placed = [];
  try {
    let c = at || b.vp.center();
    for (const f of files) {
      let it = null;
      try {
        if (f.type.startsWith('image/') && !/svg|heic|heif/.test(f.type)) it = await addImageFile(b, f, c);
        else if (f.type.startsWith('video/')) it = await addVideo(b, f, c);
        else if (f.type.startsWith('audio/')) it = await addAudio(b, f, f.name, c);
        else it = await addFile(b, f, c);
      } catch (e) { console.error(e); toast(`No se pudo añadir ${f.name}`); }
      if (it) { placed.push(it.id); c = { x: it.x + it.w + b.unit(40) + it.w / 2, y: c.y }; }
    }
  } finally { busy(); }
  if (placed.length) b.select(placed);
}

async function addVideo(b, file, at) {
  const id = await putBlob(file);
  const url = await blobURL(id);
  const dims = await new Promise((res) => {
    const v = document.createElement('video');
    v.preload = 'metadata';
    v.onloadedmetadata = () => res({ w: v.videoWidth || 1280, h: v.videoHeight || 720, d: v.duration });
    v.onerror = () => res({ w: 1280, h: 720 });
    v.src = url;
  });
  const max = b.unit(480), k = Math.min(1, max / Math.max(dims.w, dims.h));
  return b.place({ id: uid(), type: 'video', blob: id, w: dims.w * k, h: dims.h * k, rot: 0, name: file.name, duration: dims.d }, at);
}

async function addAudio(b, blob, name, at) {
  const id = await putBlob(blob);
  const url = await blobURL(id);
  const duration = await new Promise((res) => { const a = new Audio(); a.preload = 'metadata'; a.onloadedmetadata = () => res(isFinite(a.duration) ? a.duration : 0); a.onerror = () => res(0); a.src = url; });
  return b.place({ id: uid(), type: 'audio', blob: id, name: name || 'Audio', duration, w: b.unit(280), h: b.unit(72), rot: 0 }, at);
}

async function addFile(b, file, at) {
  const id = await putBlob(file);
  let preview = null, pages = null, ratio = 1.3;
  if (file.type === 'application/pdf' || /\.pdf$/i.test(file.name)) {
    try {
      const pdf = await loadPdf(file);
      pages = pdf.numPages;
      const page = await pdf.getPage(1);
      const vp0 = page.getViewport({ scale: 1 });
      const scale = 480 / vp0.width;
      const c = await renderPage(page, scale);
      ratio = c.height / c.width;
      preview = await putBlob(await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.85)));
      await blobURL(preview);
    } catch (e) { console.warn('pdf', e); }
  }
  const w = b.unit(preview ? 220 : 280);
  const hh = preview ? w * Math.min(ratio, 1.6) + b.unit(58) : b.unit(72);
  return b.place({ id: uid(), type: 'file', blob: id, name: file.name, mime: file.type || mimeFromName(file.name), size: file.size, preview, pages, w, h: hh, rot: 0 }, at);
}

function mimeFromName(n) {
  const ext = (n || '').split('.').pop().toLowerCase();
  return { pdf: 'application/pdf', txt: 'text/plain', doc: 'application/msword', docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', pptx: 'application/vnd.openxmlformats-officedocument.presentationml.presentation', zip: 'application/zip' }[ext] || 'application/octet-stream';
}

// PDF -------------------------------------------------------------------------------
let pdfjs;
async function loadPdf(blob) {
  if (!pdfjs) {
    pdfjs = await import('../vendor/pdfjs/pdf.min.mjs');
    pdfjs.GlobalWorkerOptions.workerSrc = new URL('../vendor/pdfjs/pdf.worker.min.mjs', import.meta.url).href;
  }
  const data = new Uint8Array(await blob.arrayBuffer());
  return pdfjs.getDocument({ data, isEvalSupported: false }).promise;
}

async function renderPage(page, scale) {
  const vp = page.getViewport({ scale });
  const c = document.createElement('canvas');
  c.width = Math.ceil(vp.width); c.height = Math.ceil(vp.height);
  const ctx = c.getContext('2d');
  ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height);
  // intent 'print': no depende de requestAnimationFrame (sirve también en segundo plano).
  await page.render({ canvasContext: ctx, viewport: vp, intent: 'print' }).promise;
  return c;
}

async function openPdf(b, it) {
  const blob = await getBlob(it.blob);
  if (!blob) return toast('No se encuentra el archivo');
  const pdf = await loadPdf(blob);
  const pagesEl = h('div.viewer-pages');
  const close = () => ov.remove();
  const ov = h('div.viewer', {},
    h('div.viewer-bar', {},
      h('button.btn.icon', { html: icon('x', 22), title: 'Cerrar', onclick: close }),
      h('b.viewer-title', { text: it.name }),
      h('button.btn', { html: `${icon('images', 18)} Insertar páginas`, onclick: async () => { close(); await insertPdfPages(b, pdf, it); } }),
      h('button.btn.icon', { html: icon('share', 20), title: 'Compartir', onclick: () => shareBlob(it.name, blob) })),
    pagesEl);
  document.getElementById('overlay').append(ov);
  ov.dataset.back = '1';
  ov.addEventListener('back', close);
  const io = new IntersectionObserver(async (entries) => {
    for (const e of entries) {
      if (!e.isIntersecting || e.target.dataset.done) continue;
      e.target.dataset.done = 1;
      const page = await pdf.getPage(+e.target.dataset.n);
      const scale = Math.min(2.2, (e.target.clientWidth * devicePixelRatio) / page.getViewport({ scale: 1 }).width);
      const c = await renderPage(page, scale);
      c.style.width = '100%';
      e.target.innerHTML = '';
      e.target.append(c);
    }
  }, { root: pagesEl, rootMargin: '600px' });
  for (let n = 1; n <= pdf.numPages; n++) {
    const page = await pdf.getPage(n);
    const v = page.getViewport({ scale: 1 });
    const ph = h('div.viewer-page', { 'data-n': n, style: { aspectRatio: `${v.width} / ${v.height}` } });
    pagesEl.append(ph);
    io.observe(ph);
  }
}

async function insertPdfPages(b, pdf, it) {
  const n = Math.min(pdf.numPages, 30);
  if (pdf.numPages > 30) toast('Se insertan las 30 primeras páginas');
  const busy = toastBusy(`Insertando ${n} páginas…`);
  const ids = [];
  try {
    const startX = it.x + it.w + b.unit(60);
    let x = startX, y = it.y;
    const pw = b.unit(420);
    for (let i = 1; i <= n; i++) {
      const page = await pdf.getPage(i);
      const v = page.getViewport({ scale: 1 });
      const c = await renderPage(page, 1400 / v.width);
      const blob = await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.88));
      const id = await putBlob(blob);
      await blobURL(id);
      const ph = pw * (c.height / c.width);
      const img = { id: uid(), type: 'image', blob: id, x, y, w: pw, h: ph, rot: 0, name: `${it.name} · pág. ${i}`, border: 1, borderColor: '#D1D1D6' };
      store.add(img);
      ids.push(img.id);
      x += pw + b.unit(30);
      if (i % 5 === 0) { x = startX; y += ph + b.unit(30); }
    }
  } finally { busy(); }
  b.select(ids);
}

export async function openItem(b, it) {
  if (it.type === 'link') return openExternal(it.url);
  if (it.type !== 'file') return;
  if (it.mime === 'application/pdf' || /\.pdf$/i.test(it.name)) return openPdf(b, it).catch(() => toast('No se pudo abrir el PDF'));
  if (/^text\//.test(it.mime)) {
    const blob = await getBlob(it.blob);
    const text = await blob.text();
    const ov = h('div.viewer', {}, h('div.viewer-bar', {}, h('button.btn.icon', { html: icon('x', 22), onclick: () => ov.remove() }), h('b.viewer-title', { text: it.name })), h('pre.viewer-text', { text: text.slice(0, 200000) }));
    ov.addEventListener('back', () => ov.remove());
    document.getElementById('overlay').append(ov);
    return;
  }
  shareItemFile(it);
}

export async function shareItemFile(it) {
  const blob = await getBlob(it.blob);
  if (!blob) return toast('No se encuentra el archivo');
  const ext = blob.type.split('/')[1]?.replace('jpeg', 'jpg') || 'bin';
  const name = it.type === 'image' ? `${(it.name || 'imagen').replace(/\.[^.]+$/, '')}.${ext}` : it.name;
  try { await shareBlob(name, blob); } catch (e) { toast('No se pudo compartir'); console.error(e); }
}

export async function viewImage(it) {
  const url = await blobURL(it.blob);
  const img = h('img', { src: url, alt: '' });
  const ov = h('div.viewer.dark', {},
    h('div.viewer-bar', {}, h('button.btn.icon', { html: icon('x', 22), onclick: () => ov.remove() }), h('b.viewer-title', { text: it.name || 'Imagen' }), h('button.btn.icon', { html: icon('share', 20), onclick: () => shareItemFile(it) })),
    h('div.viewer-img', {}, img));
  ov.addEventListener('back', () => ov.remove());
  document.getElementById('overlay').append(ov);
}

// Grabar audio ------------------------------------------------------------------------
export async function recordAudio(b, anchor) {
  let stream;
  try { stream = await navigator.mediaDevices.getUserMedia({ audio: true }); }
  catch { toast('Permite el acceso al micrófono para grabar'); return; }
  const mime = ['audio/webm;codecs=opus', 'audio/mp4', 'audio/webm'].find((m) => window.MediaRecorder?.isTypeSupported?.(m)) || '';
  const rec = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
  const chunks = [];
  rec.ondataavailable = (e) => e.data.size && chunks.push(e.data);
  const t0 = Date.now();
  const timeEl = h('b.rec-time', { text: '0:00' });
  const timer = setInterval(() => { const s = Math.floor((Date.now() - t0) / 1000); timeEl.textContent = `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`; }, 250);
  let cancelled = false;
  const stop = () => { clearInterval(timer); if (rec.state !== 'inactive') rec.stop(); stream.getTracks().forEach((t) => t.stop()); };
  rec.onstop = async () => {
    if (cancelled || !chunks.length) return;
    const blob = new Blob(chunks, { type: rec.mimeType || 'audio/webm' });
    const d = new Date();
    await addAudio(b, blob, `Grabación ${d.toLocaleDateString('es-ES')} ${d.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}`);
  };
  const pop = popover(anchor, h('div.pop-pad.rec', {}, h('div.rec-dot'), timeEl,
    h('button.btn', { text: 'Cancelar', onclick: () => { cancelled = true; stop(); pop.close(); } }),
    h('button.btn.primary', { text: 'Detener', onclick: () => { stop(); pop.close(); } })), { onClose: () => { if (rec.state !== 'inactive') { stop(); } } });
  rec.start(250);
}

// Recortar imagen ---------------------------------------------------------------------
export function cropMode(b, it) {
  if (it.rot) { toast('Endereza la imagen para recortarla (Más › Enderezar)'); return; }
  const prev = store.snapshot();
  const c0 = it.crop || { l: 0, t: 0, r: 0, b: 0 };
  const fw = it.w / (1 - c0.l - c0.r), fh = it.h / (1 - c0.t - c0.b);
  const F = { x: it.x - c0.l * fw, y: it.y - c0.t * fh, w: fw, h: fh };
  let box = { x: it.x, y: it.y, w: it.w, h: it.h };
  const url = (it.blob && document.querySelector(`.item[data-id="${it.id}"] img`)?.src) || '';
  const layer = h('div.crop-layer', { style: { left: `${F.x}px`, top: `${F.y}px`, width: `${F.w}px`, height: `${F.h}px` } });
  const ghost = h('img.crop-ghost', { src: url, alt: '' });
  const rect = h('div.crop-rect');
  for (const k of ['nw', 'n', 'ne', 'e', 'se', 's', 'sw', 'w']) rect.append(h('div.crop-hd.hd-' + k, { 'data-k': k }));
  layer.append(ghost, rect);
  b.world.append(layer);
  b.clearSel();
  b.root.classList.add('cropping');
  const place = () => Object.assign(rect.style, { left: `${box.x - F.x}px`, top: `${box.y - F.y}px`, width: `${box.w}px`, height: `${box.h}px` });
  const apply = () => {
    const crop = { l: (box.x - F.x) / F.w, t: (box.y - F.y) / F.h, r: (F.x + F.w - box.x - box.w) / F.w, b: (F.y + F.h - box.y - box.h) / F.h };
    store.set(store.items.map((x) => (x.id === it.id ? { ...x, ...box, crop } : x)), { silent: true });
    place();
  };
  place();
  let drag = null;
  layer.addEventListener('pointerdown', (e) => {
    e.stopPropagation(); e.preventDefault();
    try { layer.setPointerCapture(e.pointerId); } catch { /* puntero no capturable */ }
    const w = b.vp.toWorld(e.clientX, e.clientY);
    drag = { k: e.target.dataset.k || (e.target === rect ? 'move' : null), w0: w, box0: { ...box } };
  });
  layer.addEventListener('pointermove', (e) => {
    if (!drag?.k) return;
    const w = b.vp.toWorld(e.clientX, e.clientY);
    const dx = w.x - drag.w0.x, dy = w.y - drag.w0.y, o = drag.box0, m = 20 / b.vp.z;
    let { x, y, w: bw, h: bh } = o;
    if (drag.k === 'move') { x = clamp(o.x + dx, F.x, F.x + F.w - o.w); y = clamp(o.y + dy, F.y, F.y + F.h - o.h); }
    else {
      if (drag.k.includes('w')) { x = clamp(o.x + dx, F.x, o.x + o.w - m); bw = o.x + o.w - x; }
      if (drag.k.includes('e')) bw = clamp(o.w + dx, m, F.x + F.w - o.x);
      if (drag.k.includes('n')) { y = clamp(o.y + dy, F.y, o.y + o.h - m); bh = o.y + o.h - y; }
      if (drag.k.includes('s')) bh = clamp(o.h + dy, m, F.y + F.h - o.y);
    }
    box = { x, y, w: bw, h: bh };
    apply();
  });
  layer.addEventListener('pointerup', () => { drag = null; });
  const finish = (ok) => {
    layer.remove();
    bar.remove();
    b.root.classList.remove('cropping');
    if (ok) store.record(prev); else store.set(prev.items);
    b.select([it.id]);
  };
  const bar = h('div.crop-bar', {},
    h('button.btn', { text: 'Cancelar', onclick: () => finish(false) }),
    h('button.btn', { text: 'Restablecer', onclick: () => { box = { ...F }; apply(); } }),
    h('button.btn.primary', { text: 'Listo', onclick: () => finish(true) }));
  b.root.append(bar);
}

// Menús de la barra superior ---------------------------------------------------------------
export function mediaMenu(b, anchor) {
  menu(anchor, [
    { label: 'Fotos o vídeos', icon: 'images', act: () => insertPhotos(b) },
    { label: 'Hacer foto', icon: 'camera', act: () => insertCamera(b) },
    { label: 'Escanear documento', icon: 'scan-line', act: () => insertCamera(b, true) },
  ]);
}

export function attachMenu(b, anchor) {
  menu(anchor, [
    { label: 'Insertar archivo (PDF, documentos…)', icon: 'file-up', act: () => insertFiles(b) },
    { label: 'Enlace', icon: 'link', act: () => addLink(b) },
    { label: 'Grabar audio', icon: 'mic', act: () => recordAudio(b, anchor) },
    { sep: true },
    { label: 'Línea', icon: 'minus', act: () => addLine(b, 'line') },
    { label: 'Flecha', icon: 'move-right', act: () => addLine(b, 'arrow') },
    { label: 'Curva', icon: 'spline', act: () => addLine(b, 'curve') },
  ]);
}

function toastBusy(msg) {
  const el = h('div.toast.busy.in', { html: `<span class="spin"></span>${msg}` });
  document.getElementById('overlay').append(el);
  return () => el.remove();
}

export { fmtSize, settings };
