// Pantalla de inicio: galería de tableros.
import * as db from './db.js';
import { h, icon, fmtDate, esc, pickFiles } from './util.js';
import { menu, prompt, confirm, toast } from './ui.js';
import { settings } from './settings.js';
import { backupAll, importBoardJSON, boardToJSON } from './export.js';
import { shareBlob } from './native.js';
import { library, createFolder, createTag, editEntry, moveToFolder, editTags, tagDots, folderOf, tagOf } from './library.js';

const SECTIONS = [
  { id: 'all', name: 'Todos los tableros', icon: 'layout-grid' },
  { id: 'recent', name: 'Recientes', icon: 'clock' },
  { id: 'fav', name: 'Favoritos', icon: 'star' },
  { id: 'trash', name: 'Eliminados recientemente', icon: 'trash-2' },
];
const TRASH_DAYS = 30;

export class Home {
  constructor(app) {
    this.app = app;
    this.el = document.getElementById('home');
    this.section = 'all';
    this.query = '';
    this.metas = [];
    this.build();
  }

  build() {
    const side = h('aside.side');
    const search = h('input.search', { type: 'search', placeholder: 'Buscar', oninput: (e) => { this.query = e.target.value.trim().toLowerCase(); this.renderGrid(); } });
    this.navEl = h('nav.side-nav');
    side.append(h('h1.side-title', { text: 'Lienzo' }), h('div.search-wrap', {}, h('span', { html: icon('search', 17) }), search), this.navEl,
      h('div.side-foot', {},
        h('button.side-link', { html: `${icon('upload', 18)}<span>Importar tablero</span>`, onclick: () => this.importFile() }),
        h('button.side-link', { html: `${icon('download', 18)}<span>Copia de seguridad</span>`, onclick: () => this.backup() }),
        h('button.side-link', { html: `${icon('settings', 18)}<span>Ajustes</span>`, onclick: (e) => this.app.settingsPanel(e.currentTarget) })));
    this.titleEl = h('h2.main-title');
    this.countEl = h('span.main-count');
    const tools = h('div.main-tools', {},
      h('button.tb-btn.side-toggle', { title: 'Secciones', html: icon('list', 22), onclick: () => this.el.classList.toggle('side-open') }),
      h('div.spacer'),
      h('button.tb-btn', { title: 'Ordenar', html: icon('arrow-down', 21), onclick: (e) => this.sortMenu(e.currentTarget) }),
      this.viewBtn = h('button.tb-btn', { title: 'Vista', onclick: () => { settings.homeView = settings.homeView === 'grid' ? 'list' : 'grid'; this.render(); } }),
      h('button.tb-btn.accent', { title: 'Nuevo tablero', html: icon('square-pen', 24), onclick: () => this.app.newBoard() }));
    this.gridEl = h('div.board-grid');
    const main = h('main.main', {}, tools, h('div.main-head', {}, this.titleEl, this.countEl), this.gridEl);
    side.addEventListener('click', (e) => { if (e.target.closest('.side-item')) this.el.classList.remove('side-open'); });
    this.el.append(side, h('div.side-scrim', { onclick: () => this.el.classList.remove('side-open') }), main);
  }

  async refresh() {
    this.lib = await library();
    this.metas = await db.listMeta();
    // Si la carpeta o etiqueta abierta ya no existe, vuelve a «Todos».
    if (this.section.startsWith('f:') && !folderOf(this.lib, this.section.slice(2))) this.section = 'all';
    if (this.section.startsWith('t:') && !tagOf(this.lib, this.section.slice(2))) this.section = 'all';
    // Purga la papelera pasados 30 días.
    const limit = Date.now() - TRASH_DAYS * 864e5;
    for (const m of this.metas.filter((x) => x.deletedAt && x.deletedAt < limit)) await db.deleteBoard(m.id);
    this.metas = this.metas.filter((x) => !(x.deletedAt && x.deletedAt < limit));
    this.render();
  }

  list() {
    let l = this.metas.filter((m) => (this.section === 'trash' ? m.deletedAt : !m.deletedAt));
    if (this.section === 'fav') l = l.filter((m) => m.favorite);
    if (this.section === 'recent') l = l.filter((m) => m.updated > Date.now() - 30 * 864e5);
    if (this.section.startsWith('f:')) l = l.filter((m) => m.folder === this.section.slice(2));
    if (this.section.startsWith('t:')) l = l.filter((m) => (m.tags || []).includes(this.section.slice(2)));
    if (this.query) {
      // Busca por título, carpeta y etiquetas.
      const names = (m) => [m.title, folderOf(this.lib, m.folder)?.name, ...(m.tags || []).map((t) => tagOf(this.lib, t)?.name)].filter(Boolean).join(' ').toLowerCase();
      l = l.filter((m) => names(m).includes(this.query));
    }
    const sort = settings.sort;
    l.sort((a, b) => (sort === 'name' ? a.title.localeCompare(b.title, 'es') : sort === 'created' ? b.created - a.created : b.updated - a.updated));
    if (this.section === 'recent') l = l.slice(0, 30);
    return l;
  }

  render() {
    this.navEl.innerHTML = '';
    const live = this.metas.filter((m) => !m.deletedAt);
    const item = (id, ic, name, n, extra = {}) => h('button.side-item' + (id === this.section ? '.on' : ''), { onclick: () => { this.section = id; this.render(); }, ...extra },
      h('span', { html: ic }), h('span.lbl', { text: name }), n != null ? h('span.cnt', { text: n || '' }) : null);
    for (const s of SECTIONS.filter((x) => x.id !== 'trash')) {
      const n = s.id === 'recent' ? null : live.filter((m) => s.id !== 'fav' || m.favorite).length;
      this.navEl.append(item(s.id, icon(s.icon, 20), s.name, n));
    }
    // Carpetas
    this.navEl.append(h('div.side-head', {}, h('span', { text: 'Carpetas' }), h('button.side-add', { title: 'Nueva carpeta', html: icon('plus', 18), onclick: async () => { const f = await createFolder(); if (f) { this.section = 'f:' + f.id; this.render(); } } })));
    for (const f of this.lib.folders) {
      const el = item('f:' + f.id, `<span class="lib-ic" style="color:${f.color}">${icon('folder', 20, 'fill="currentColor" fill-opacity=".18"')}</span>`, f.name, live.filter((m) => m.folder === f.id).length);
      this.bindEntryMenu(el, 'folder', f);
      this.navEl.append(el);
    }
    // Etiquetas
    this.navEl.append(h('div.side-head', {}, h('span', { text: 'Etiquetas' }), h('button.side-add', { title: 'Nueva etiqueta', html: icon('plus', 18), onclick: async () => { const t = await createTag(); if (t) { this.section = 't:' + t.id; this.render(); } } })));
    for (const t of this.lib.tags) {
      const el = item('t:' + t.id, `<span class="tag-dot big" style="background:${t.color}"></span>`, t.name, live.filter((m) => (m.tags || []).includes(t.id)).length);
      this.bindEntryMenu(el, 'tag', t);
      this.navEl.append(el);
    }
    const trash = SECTIONS.find((x) => x.id === 'trash');
    this.navEl.append(h('div.side-gap'), item('trash', icon(trash.icon, 20), trash.name, this.metas.filter((m) => m.deletedAt).length));
    this.viewBtn.innerHTML = icon(settings.homeView === 'grid' ? 'list' : 'layout-grid', 21);
    this.renderGrid();
  }

  /** Mantener pulsada (o clic derecho) una carpeta o etiqueta: renombrar, color o eliminar. */
  bindEntryMenu(el, kind, entry) {
    let timer, long = false;
    const open = () => editEntry(kind, entry, el, () => this.refresh());
    el.addEventListener('pointerdown', () => { long = false; timer = setTimeout(() => { long = true; navigator.vibrate?.(10); open(); }, 520); });
    for (const ev of ['pointerup', 'pointercancel', 'pointerleave']) el.addEventListener(ev, () => clearTimeout(timer));
    el.addEventListener('click', (e) => { if (long) { e.stopImmediatePropagation(); e.preventDefault(); } }, true);
    el.addEventListener('contextmenu', (e) => { e.preventDefault(); if (!long) open(); });
  }

  sectionInfo() {
    if (this.section.startsWith('f:')) { const f = folderOf(this.lib, this.section.slice(2)); return { name: f?.name || 'Carpeta', folder: f }; }
    if (this.section.startsWith('t:')) { const t = tagOf(this.lib, this.section.slice(2)); return { name: t?.name || 'Etiqueta', tag: t }; }
    return { name: SECTIONS.find((s) => s.id === this.section).name };
  }

  /** Los tableros nuevos nacen en la carpeta o etiqueta que tengas abierta. */
  newBoardDefaults() {
    const info = this.sectionInfo();
    return { folder: info.folder?.id || null, tags: info.tag ? [info.tag.id] : [], favorite: this.section === 'fav' };
  }

  renderGrid() {
    const sec = this.sectionInfo();
    this.titleEl.textContent = sec.name;
    const list = this.list();
    this.countEl.textContent = list.length === 1 ? '1 tablero' : `${list.length} tableros`;
    const g = this.gridEl;
    g.className = 'board-grid ' + settings.homeView;
    g.innerHTML = '';
    if (!list.length) {
      g.append(h('div.empty', {},
        h('div.empty-ic', { html: icon(this.section === 'trash' ? 'trash-2' : 'square-pen', 46) }),
        h('b', { text: this.section === 'trash' ? 'La papelera está vacía' : this.query ? 'Sin resultados' : sec.folder ? 'Esta carpeta está vacía' : sec.tag ? 'Ningún tablero con esta etiqueta' : 'Aún no hay tableros' }),
        h('p', { text: this.section === 'trash' ? `Los tableros eliminados se guardan aquí ${TRASH_DAYS} días.` : sec.folder || sec.tag ? 'Crea un tablero aquí o, en la galería, mantén pulsado uno y elige «Mover a carpeta» o «Etiquetas».' : 'Crea un tablero para dibujar, pegar fotos, escribir notas y organizar ideas sin límites.' }),
        this.section !== 'trash' && !this.query ? h('button.btn.primary', { html: `${icon('plus', 18)} Nuevo tablero`, onclick: () => this.app.newBoard() }) : null));
      return;
    }
    if (this.section === 'trash') g.append(h('p.trash-note', { text: `Los tableros se eliminan definitivamente ${TRASH_DAYS} días después.` }));
    for (const m of list) g.append(this.card(m));
  }

  card(m) {
    const thumb = h('div.thumb', {}, m.thumb ? h('img', { src: m.thumb, alt: '', draggable: 'false' }) : h('div.thumb-empty'));
    if (m.favorite) thumb.append(h('span.fav-badge', { html: icon('star', 14, 'fill="currentColor"') }));
    const days = m.deletedAt ? Math.max(0, TRASH_DAYS - Math.floor((Date.now() - m.deletedAt) / 864e5)) : null;
    const card = h('div.board-card', { tabindex: 0 }, thumb,
      h('div.card-meta', {}, h('div.card-text', {}, h('b', { html: esc(m.title) }), h('small', { text: days != null ? `${days} días` : [fmtDate(m.updated), this.section.startsWith('f:') ? null : folderOf(this.lib, m.folder)?.name].filter(Boolean).join(' · ') }), tagDots(this.lib, m)),
        h('button.card-more', { html: icon('ellipsis', 18), title: 'Opciones', onclick: (e) => { e.stopPropagation(); this.cardMenu(m, e.currentTarget); } })));
    let timer, long = false;
    card.addEventListener('pointerdown', (e) => {
      if (e.target.closest('.card-more')) return;
      long = false;
      timer = setTimeout(() => { long = true; navigator.vibrate?.(10); this.cardMenu(m, card); }, 520);
    });
    const cancel = () => clearTimeout(timer);
    card.addEventListener('pointerup', cancel); card.addEventListener('pointercancel', cancel); card.addEventListener('pointerleave', cancel);
    card.addEventListener('contextmenu', (e) => { e.preventDefault(); if (!long) this.cardMenu(m, card); });
    card.addEventListener('click', (e) => { if (long || e.target.closest('.card-more')) return; if (m.deletedAt) this.cardMenu(m, card); else this.app.openBoard(m.id); });
    return card;
  }

  cardMenu(m, anchor) {
    if (m.deletedAt) {
      menu(anchor, [
        { label: 'Recuperar', icon: 'archive-restore', act: async () => { m.deletedAt = null; await db.putMeta(m); this.refresh(); toast('Tablero recuperado'); } },
        { label: 'Eliminar definitivamente', icon: 'trash-2', danger: true, act: async () => { if (await confirm('¿Eliminar definitivamente?', `«${m.title}» se borrará para siempre.`, { ok: 'Eliminar', danger: true })) { await db.deleteBoard(m.id); this.refresh(); } } },
      ]);
      return;
    }
    menu(anchor, [
      { label: 'Abrir', icon: 'eye', act: () => this.app.openBoard(m.id) },
      { label: 'Renombrar', icon: 'pencil', act: async () => { const n = await prompt('Nombre del tablero', m.title); if (n) { m.title = n; await db.putMeta(m); this.render(); } } },
      { label: m.favorite ? 'Quitar de favoritos' : 'Añadir a favoritos', icon: 'star', act: async () => { m.favorite = !m.favorite; await db.putMeta(m); this.render(); } },
      { label: 'Mover a carpeta', icon: 'folder', act: () => moveToFolder(m, anchor, () => this.refresh()) },
      { label: 'Etiquetas', icon: 'sparkles', act: () => editTags(m, anchor, () => this.refresh()) },
      { label: 'Duplicar', icon: 'copy', act: () => this.app.duplicateBoard(m.id) },
      { label: 'Compartir copia (.lienzo)', icon: 'share', act: async () => { const data = await boardToJSON(m, await db.getContent(m.id)); await shareBlob(`${m.title}.lienzo`, new Blob([JSON.stringify(data)], { type: 'application/json' })); } },
      { sep: true },
      { label: 'Eliminar', icon: 'trash-2', danger: true, act: () => this.app.trashBoard(m.id) },
    ]);
  }

  sortMenu(anchor) {
    const set = (v) => { settings.sort = v; this.renderGrid(); };
    menu(anchor, [
      { label: 'Fecha de modificación', checked: settings.sort === 'updated', act: () => set('updated') },
      { label: 'Fecha de creación', checked: settings.sort === 'created', act: () => set('created') },
      { label: 'Nombre', checked: settings.sort === 'name', act: () => set('name') },
    ]);
  }

  async importFile() {
    const [file] = await pickFiles({ accept: '.lienzo,.json,application/json,application/octet-stream' });
    if (!file) return;
    try {
      const data = JSON.parse(await file.text());
      if (data.app === 'lienzo-backup') {
        for (const bd of data.boards) await importBoardJSON(bd);
        toast(`${data.boards.length} tableros restaurados`);
      } else if (data.app === 'lienzo') {
        await importBoardJSON(data);
        toast('Tablero importado');
      } else throw new Error('formato');
      this.refresh();
    } catch (e) { console.error(e); toast('Ese archivo no es una copia de Lienzo'); }
  }

  async backup() {
    const metas = this.metas.filter((m) => !m.deletedAt);
    if (!metas.length) { toast('No hay tableros que guardar'); return; }
    const busy = h('div.toast.busy.in', { html: '<span class="spin"></span>Creando copia…' });
    document.getElementById('overlay').append(busy);
    try {
      const blob = await backupAll(metas);
      const d = new Date();
      await shareBlob(`Lienzo copia ${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}.lienzo`, blob);
    } catch (e) { console.error(e); toast('No se pudo crear la copia'); }
    finally { busy.remove(); }
  }
}
