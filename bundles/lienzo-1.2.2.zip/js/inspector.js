// Barra contextual (inspector) que aparece sobre la selección.
import { store } from './store.js';
import { h, icon, clamp } from './util.js';
import { popover, menu, colorPicker, swatchBtn, segmented, slider, toast, prompt, closeAllPopovers } from './ui.js';
import { FONTS, NOTE_COLORS } from './render.js';
import { SHAPES, SHAPE_CATS } from './shapes.js';
import * as G from './geom.js';
import * as insert from './insert.js';

const btn = (ic, title, onclick, cls = '') => h('button.ctx-btn' + (cls ? '.' + cls : ''), { title, 'aria-label': title, html: icon(ic, 20), onclick });
const sep = () => h('div.ctx-sep');

export function buildContextBar(b, items) {
  const ids = items.map((i) => i.id);
  const one = items.length === 1 ? items[0] : null;
  const out = [];
  const upd = (patch, opts) => { store.update(ids, patch, opts); };

  if (items.some((i) => i.locked)) {
    out.push(h('button.ctx-btn.wide', { html: `${icon('lock-open', 18)}<span>Desbloquear</span>`, onclick: () => b.toggleLock() }));
    return out;
  }

  if (b.editing) {
    const it = store.get(b.editing.id);
    out.push(btn('type', 'Estilo de texto', (e) => textPopover(b, e.currentTarget, [it])));
    for (const [k, ic] of [['bold', 'bold'], ['italic', 'italic'], ['underline', 'underline']]) {
      out.push(btn(ic, k, (e) => { const v = !store.get(it.id)[k]; e.currentTarget.classList.toggle('on', v); store.update(it.id, { [k]: v }); b.editing?.target.focus(); }, it[k] ? 'on' : ''));
    }
    out.push(sep(), h('button.ctx-btn.wide.primary', { html: `${icon('check', 18)}<span>OK</span>`, onclick: () => b.stopEditing() }));
    return out;
  }

  if (one) {
    switch (one.type) {
      case 'note':
        out.push(swatchBtn(one.color || NOTE_COLORS[0], (e) => notePopover(b, e.currentTarget, ids), 'Color de la nota'));
        out.push(btn('type', 'Texto', (e) => textPopover(b, e.currentTarget, items)));
        break;
      case 'shape':
        out.push(swatchBtn(one.fill || 'none', (e) => colorPicker(e.currentTarget, { value: one.fill || 'none', allowNone: true, title: 'Relleno', onChange: (c) => liveColor(ids, { fill: c }) }), 'Relleno'));
        out.push(strokeBtn(b, items));
        out.push(btn('type', 'Texto', (e) => textPopover(b, e.currentTarget, items)));
        out.push(btn('shapes', 'Cambiar forma', (e) => shapePicker(e.currentTarget, (s) => upd({ shape: s.id, path: undefined }))));
        break;
      case 'text':
        out.push(btn('type', 'Texto', (e) => textPopover(b, e.currentTarget, items)));
        out.push(swatchBtn(one.tcolor || '#000000', (e) => colorPicker(e.currentTarget, { value: one.tcolor || '#000000', title: 'Color del texto', onChange: (c) => liveColor(ids, { tcolor: c }) }), 'Color del texto'));
        out.push(swatchBtn(one.fill || 'none', (e) => colorPicker(e.currentTarget, { value: one.fill || 'none', allowNone: true, title: 'Fondo', onChange: (c) => liveColor(ids, { fill: c }) }), 'Fondo'));
        break;
      case 'ink':
        out.push(swatchBtn(one.color, (e) => colorPicker(e.currentTarget, { value: one.color, title: 'Color del trazo', onChange: (c) => liveColor(ids, { color: c }) }), 'Color'));
        out.push(btn('pen-line', 'Opacidad', (e) => popover(e.currentTarget, h('div.pop-pad', {}, slider({ label: 'Opacidad', min: 10, max: 100, value: Math.round((one.opacity ?? 1) * 100), fmt: (v) => `${v} %`, onInput: (v) => store.update(ids, { opacity: v / 100 }, { record: false }), onChange: () => commitLive() })), { keep: true })));
        break;
      case 'line':
        out.push(swatchBtn(one.color || '#000000', (e) => colorPicker(e.currentTarget, { value: one.color || '#000000', title: 'Color de la línea', onChange: (c) => liveColor(ids, { color: c }) }), 'Color'));
        out.push(btn('spline', 'Estilo de línea', (e) => linePopover(b, e.currentTarget, one)));
        out.push(btn('arrow-left-right', 'Flechas', (e) => arrowPopover(e.currentTarget, one)));
        break;
      case 'image':
        out.push(btn('crop', 'Recortar', () => insert.cropMode(b, one)));
        out.push(btn('circle', 'Máscara', (e) => menu(e.currentTarget, [
          { label: 'Sin máscara', checked: !one.mask || one.mask === 'none', act: () => upd({ mask: 'none' }) },
          { label: 'Esquinas redondeadas', checked: one.mask === 'rounded', act: () => upd({ mask: 'rounded' }) },
          { label: 'Círculo', checked: one.mask === 'circle', act: () => upd({ mask: 'circle' }) },
        ], { keep: true })));
        out.push(btn('square', 'Borde', (e) => popover(e.currentTarget, h('div.pop-pad', {},
          slider({ label: 'Borde', min: 0, max: 20, value: one.border || 0, fmt: (v) => `${v} pt`, onInput: (v) => store.update(ids, { border: v }, { record: false }), onChange: () => commitLive() }),
          h('button.btn.full', { text: 'Color del borde', onclick: (ev) => colorPicker(ev.currentTarget, { value: one.borderColor || '#000000', onChange: (c) => liveColor(ids, { borderColor: c }) }) })), { keep: true })));
        out.push(btn('maximize-2', 'Ver', () => insert.viewImage(one)));
        break;
      case 'video': case 'audio':
        out.push(btn('play', 'Reproducir', () => b.playMedia(one.id)));
        break;
      case 'file':
        out.push(h('button.ctx-btn.wide', { html: `${icon('eye', 18)}<span>Abrir</span>`, onclick: () => insert.openItem(b, one) }));
        out.push(btn('share', 'Compartir', () => insert.shareItemFile(one)));
        break;
      case 'link':
        out.push(h('button.ctx-btn.wide', { html: `${icon('external-link', 18)}<span>Abrir</span>`, onclick: () => insert.openItem(b, one) }));
        out.push(btn('pencil', 'Editar enlace', async () => {
          const url = await prompt('Editar enlace', one.url, { placeholder: 'https://…' });
          if (url) upd({ url: insert.normalizeUrl(url) });
          const title = await prompt('Título del enlace', one.title || '', { placeholder: 'Opcional' });
          if (title != null) upd({ title });
        }));
        break;
      case 'table':
        out.push(btn('rows-3', 'Añadir fila', () => tableOp(one, 'addRow')));
        out.push(btn('columns-3', 'Añadir columna', () => tableOp(one, 'addCol')));
        out.push(btn('table', 'Tabla', (e) => tablePopover(b, e.currentTarget, one)));
        out.push(btn('type', 'Texto', (e) => textPopover(b, e.currentTarget, items)));
        break;
      default: break;
    }
  } else {
    out.push(btn('align-center', 'Alinear', (e) => alignPopover(b, e.currentTarget)));
    const colorable = items.filter((i) => ['note', 'shape', 'ink', 'line', 'text'].includes(i.type));
    if (colorable.length) out.push(swatchBtn(colorable[0].color || colorable[0].fill || colorable[0].stroke || '#000000', (e) => colorPicker(e.currentTarget, { value: '#007AFF', title: 'Color', onChange: (c) => multiColor(colorable, c) }), 'Color'));
    const grouped = items.every((i) => i.group && i.group === items[0].group);
    out.push(btn(grouped ? 'ungroup' : 'group', grouped ? 'Desagrupar' : 'Agrupar', () => b.toggleGroup(), grouped ? 'on' : ''));
  }
  out.push(sep(), btn('ellipsis', 'Más', (e) => moreMenu(b, e.currentTarget, items)));
  return out;
}

// Cambios en vivo durante popovers: se registra un solo paso de deshacer al cerrar.
let livePrev = null;
function liveColor(ids, patch) {
  if (!livePrev) livePrev = store.snapshot();
  store.update(ids, patch, { record: false });
  clearTimeout(liveColor.t);
  liveColor.t = setTimeout(commitLive, 700);
}
function commitLive() { if (livePrev) { store.record(livePrev); livePrev = null; } }

function multiColor(items, c) {
  if (!livePrev) livePrev = store.snapshot();
  const ids = new Map(items.map((i) => [i.id, i]));
  store.set(store.items.map((it) => {
    if (!ids.has(it.id)) return it;
    if (it.type === 'note' || it.type === 'line' || it.type === 'ink') return { ...it, color: c };
    if (it.type === 'shape') return { ...it, fill: c };
    if (it.type === 'text') return { ...it, tcolor: c };
    return it;
  }));
  clearTimeout(liveColor.t);
  liveColor.t = setTimeout(commitLive, 700);
}

function notePopover(b, anchor, ids) {
  const grid = h('div.note-colors');
  for (const c of NOTE_COLORS) grid.append(h('button.sw.note', { style: { background: c }, onclick: () => { store.update(ids, { color: c }); try { localStorage.setItem('lienzo.noteColor', c); } catch { /* */ } closeAllPopovers(); } }));
  grid.append(h('button.sw.note.more', { html: icon('pipette', 18), title: 'Más colores', onclick: (e) => colorPicker(e.currentTarget, { value: store.get(ids[0]).color, title: 'Color de la nota', onChange: (c) => liveColor(ids, { color: c }) }) }));
  popover(anchor, h('div.pop-pad', {}, h('div.pop-title', { text: 'Color de la nota' }), grid));
}

function strokeBtn(b, items) {
  const one = items[0];
  const ids = items.map((i) => i.id);
  const bt = h('button.ctx-btn.stroke-btn', { title: 'Borde', onclick: (e) => {
    const body = h('div.pop-pad');
    body.append(
      h('div.pop-title', { text: 'Borde' }),
      segmented([{ value: 'solid', label: 'Continuo' }, { value: 'dash', label: 'Discontinuo' }, { value: 'dot', label: 'Punteado' }, { value: 'none', label: 'Ninguno' }],
        one.stroke === 'none' ? 'none' : one.dash || 'solid', (v) => store.update(ids, v === 'none' ? { stroke: 'none' } : { dash: v === 'solid' ? undefined : v, stroke: store.get(ids[0]).stroke === 'none' ? '#000000' : store.get(ids[0]).stroke })),
      slider({ label: 'Grosor', min: 0.5, max: 24, step: 0.5, value: one.sw ?? 2, fmt: (v) => `${v} pt`, onInput: (v) => liveColor(ids, { sw: v }), onChange: () => commitLive() }),
      h('button.btn.full', { html: `<span class="swatch-dot" style="background:${one.stroke && one.stroke !== 'none' ? one.stroke : 'var(--none-bg)'}"></span> Color del borde`, onclick: (ev) => colorPicker(ev.currentTarget, { value: one.stroke || '#000000', allowNone: true, title: 'Borde', onChange: (c) => liveColor(ids, { stroke: c }) }) }),
    );
    popover(e.currentTarget, body, { keep: true });
  } });
  bt.innerHTML = `<span class="stroke-ring" style="border-color:${one.stroke && one.stroke !== 'none' ? one.stroke : 'var(--fg3)'}"></span>`;
  return bt;
}

function textPopover(b, anchor, items) {
  const ids = items.map((i) => i.id);
  const it = store.get(ids[0]);
  const body = h('div.pop-pad.text-pop');
  const fonts = h('div.font-list');
  for (const [k, f] of Object.entries(FONTS)) {
    fonts.append(h('button.font-opt' + ((it.font || 'sans') === k ? '.on' : ''), { style: { fontFamily: f.css }, text: f.name, onclick: (e) => { fonts.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === e.currentTarget)); store.update(ids, { font: k }); } }));
  }
  const isNote = it.type === 'note';
  const defSize = it.type === 'shape' ? 20 : it.type === 'table' ? 16 : 24;
  let size = it.fsize && it.fsize !== 'auto' ? it.fsize : defSize;
  const sizeOut = h('span.size-val', { text: isNote && (!it.fsize || it.fsize === 'auto') ? 'Auto' : `${Math.round(size)} pt` });
  const setSize = (s) => { size = clamp(Math.round(s), 6, 300); sizeOut.textContent = `${size} pt`; store.update(ids, { fsize: size }); };
  const sizes = h('div.size-row', {},
    h('button.btn.icon', { html: icon('minus', 18), onclick: () => setSize(size > 30 ? size - 4 : size - 1) }), sizeOut,
    h('button.btn.icon', { html: icon('plus', 18), onclick: () => setSize(size >= 30 ? size + 4 : size + 1) }),
    isNote ? h('button.btn.small', { text: 'Auto', onclick: () => { store.update(ids, { fsize: 'auto' }); sizeOut.textContent = 'Auto'; } }) : null);
  const styles = h('div.seg.multi');
  for (const [k, ic] of [['bold', 'bold'], ['italic', 'italic'], ['underline', 'underline'], ['strike', 'strikethrough']]) {
    styles.append(h('button' + (it[k] ? '.on' : ''), { html: icon(ic, 18), title: k, onclick: (e) => { const v = !store.get(ids[0])[k]; e.currentTarget.classList.toggle('on', v); store.update(ids, { [k]: v }); } }));
  }
  const align = segmented([{ value: 'left', icon: 'align-left', label: 'Izquierda' }, { value: 'center', icon: 'align-center', label: 'Centro' }, { value: 'right', icon: 'align-right', label: 'Derecha' }],
    it.align || (it.type === 'text' || it.type === 'table' ? 'left' : 'center'), (v) => store.update(ids, { align: v }));
  const color = h('button.btn.full', { html: `<span class="swatch-dot" style="background:${it.tcolor || 'var(--fg)'}"></span> Color del texto`, onclick: (e) => colorPicker(e.currentTarget, { value: it.tcolor || '#000000', title: 'Color del texto', onChange: (c) => liveColor(ids, { tcolor: c }) }) });
  body.append(h('div.pop-title', { text: 'Texto' }), fonts, sizes, h('div.row-2', {}, styles, align), color);
  popover(anchor, body, { keep: true });
}

function linePopover(b, anchor, one) {
  const ids = [one.id];
  popover(anchor, h('div.pop-pad', {},
    h('div.pop-title', { text: 'Línea' }),
    segmented([{ value: 'straight', label: 'Recta' }, { value: 'curved', label: 'Curva' }, { value: 'elbow', label: 'Codo' }], one.style || 'curved', (v) => store.update(ids, { style: v })),
    segmented([{ value: 'solid', label: 'Continua' }, { value: 'dash', label: 'Discontinua' }, { value: 'dot', label: 'Punteada' }], one.dash || 'solid', (v) => store.update(ids, { dash: v === 'solid' ? undefined : v })),
    slider({ label: 'Grosor', min: 0.5, max: 24, step: 0.5, value: one.width || 2, fmt: (v) => `${v} pt`, onInput: (v) => liveColor(ids, { width: v }), onChange: () => commitLive() })), { keep: true });
}

function arrowPopover(anchor, one) {
  const ids = [one.id];
  const opts = [{ value: '', label: 'Nada' }, { value: 'arrow', label: 'Flecha' }, { value: 'dot', label: 'Punto' }];
  popover(anchor, h('div.pop-pad', {},
    h('div.pop-title', { text: 'Inicio' }), segmented(opts, one.arrowA || '', (v) => store.update(ids, { arrowA: v || undefined })),
    h('div.pop-title', { text: 'Final' }), segmented(opts, one.arrowB || '', (v) => store.update(ids, { arrowB: v || undefined })),
    h('button.btn.full', { html: `${icon('arrow-left-right', 18)} Invertir dirección`, onclick: () => { const l = store.get(one.id); store.update(ids, { a: l.b, b: l.a, arrowA: l.arrowB, arrowB: l.arrowA }); } })), { keep: true });
}

function alignPopover(b, anchor) {
  const grid = h('div.align-grid');
  for (const [k, l] of [['left', 'Izquierda'], ['hcenter', 'Centro H.'], ['right', 'Derecha'], ['top', 'Arriba'], ['vcenter', 'Centro V.'], ['bottom', 'Abajo'], ['distH', 'Distribuir H.'], ['distV', 'Distribuir V.']]) {
    grid.append(h('button.btn', { text: l, onclick: () => b.align(k) }));
  }
  popover(anchor, h('div.pop-pad', {}, h('div.pop-title', { text: 'Alinear y distribuir' }), grid), { keep: true });
}

function tableOp(t, op, idx) {
  const it = store.get(t.id);
  let { cells, colW, rowH } = it;
  cells = cells.map((r) => [...r]);
  colW = [...colW]; rowH = [...rowH];
  let w = it.w, hh = it.h;
  const avgW = it.w / colW.length, avgH = it.h / rowH.length;
  const tw = colW.reduce((a, c) => a + c, 0), th = rowH.reduce((a, c) => a + c, 0);
  if (op === 'addRow') { cells.splice(idx ?? cells.length, 0, colW.map(() => '')); rowH.splice(idx ?? rowH.length, 0, th / rowH.length); hh += avgH; }
  if (op === 'addCol') { cells.forEach((r) => r.splice(idx ?? r.length, 0, '')); colW.splice(idx ?? colW.length, 0, tw / colW.length); w += avgW; }
  if (op === 'delRow' && rowH.length > 1) { const i = idx ?? rowH.length - 1; cells.splice(i, 1); hh -= (rowH[i] / th) * it.h; rowH.splice(i, 1); }
  if (op === 'delCol' && colW.length > 1) { const i = idx ?? colW.length - 1; cells.forEach((r) => r.splice(i, 1)); w -= (colW[i] / tw) * it.w; colW.splice(i, 1); }
  store.update(t.id, { cells, colW, rowH, w, h: hh });
}

function tablePopover(b, anchor, one) {
  const it = store.get(one.id);
  popover(anchor, h('div.pop-pad', {},
    h('div.pop-title', { text: `Tabla · ${it.rowH.length} × ${it.colW.length}` }),
    h('div.align-grid', {},
      h('button.btn', { text: '+ Fila', onclick: () => tableOp(one, 'addRow') }), h('button.btn', { text: '− Fila', onclick: () => tableOp(one, 'delRow') }),
      h('button.btn', { text: '+ Columna', onclick: () => tableOp(one, 'addCol') }), h('button.btn', { text: '− Columna', onclick: () => tableOp(one, 'delCol') })),
    h('label.check-row', {}, h('span', { text: 'Fila de encabezado' }), (() => { const c = h('input', { type: 'checkbox' }); c.checked = !!it.header; c.onchange = () => store.update(one.id, { header: c.checked }); return c; })()),
    h('button.btn.full', { text: 'Color de las celdas', onclick: (e) => colorPicker(e.currentTarget, { value: it.fill || 'none', allowNone: true, onChange: (c) => liveColor([one.id], { fill: c === 'none' ? undefined : c }) }) }),
    h('button.btn.full', { text: 'Color de las líneas', onclick: (e) => colorPicker(e.currentTarget, { value: it.stroke || '#C7C7CC', onChange: (c) => liveColor([one.id], { stroke: c }) }) })), { keep: true });
}

export function shapePicker(anchor, onPick, { stickers = true } = {}) {
  const body = h('div.shape-pick');
  const search = h('input.search', { placeholder: 'Buscar formas', type: 'search' });
  const tabs = h('div.shape-tabs');
  const grid = h('div.shape-grid');
  const cats = [...SHAPE_CATS, ...(stickers ? ['Emoji'] : [])];
  let cat = (() => { try { return localStorage.getItem('lienzo.shapeCat') || 'Básicas'; } catch { return 'Básicas'; } })();
  const draw = () => {
    grid.innerHTML = '';
    grid.classList.toggle('emoji', cat === 'Emoji' && !search.value);
    const q = search.value.trim().toLowerCase();
    if (cat === 'Emoji' && !q) {
      for (const [group, list] of Object.entries(insert.EMOJI_GROUPS())) {
        grid.append(h('div.grid-head', { text: group }));
        for (const e of list) grid.append(h('button.emo-btn', { text: e, onclick: () => { closeAllPopovers(); onPick({ emoji: e }); } }));
      }
      return;
    }
    const list = q ? SHAPES.filter((s) => s.name.toLowerCase().includes(q)) : SHAPES.filter((s) => s.cat === cat);
    for (const s of list) {
      grid.append(h('button.shape-btn', { title: s.name, onclick: () => { closeAllPopovers(); onPick(s); }, html: `<svg viewBox="-4 -4 108 108"><path d="${s.d}" fill-rule="evenodd"/>${s.deco ? `<path d="${s.deco}" class="deco"/>` : ''}</svg>` }));
    }
    if (!list.length) grid.append(h('p.empty-note', { text: 'No hay formas con ese nombre' }));
  };
  for (const c of cats) tabs.append(h('button' + (c === cat ? '.on' : ''), { text: c, onclick: (e) => { cat = c; try { localStorage.setItem('lienzo.shapeCat', c); } catch { /* */ } tabs.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === e.currentTarget)); search.value = ''; draw(); } }));
  search.addEventListener('input', draw);
  body.append(search, tabs, grid);
  draw();
  return popover(anchor, body, { className: 'shapes-pop' });
}

function moreMenu(b, anchor, items) {
  const one = items.length === 1 ? items[0] : null;
  const grouped = items.length > 1 && items.every((i) => i.group && i.group === items[0].group);
  const style = (it) => ({ color: it.color, fill: it.fill, stroke: it.stroke, sw: it.sw, dash: it.dash, font: it.font, fsize: it.fsize, bold: it.bold, italic: it.italic, underline: it.underline, align: it.align, tcolor: it.tcolor, width: it.width, opacity: it.opacity });
  const flip = (axis) => store.update(items.filter((i) => i.type !== 'line').map((i) => i.id), (it) => ({ [axis]: !it[axis] }));
  menu(anchor, [
    { row: [
      { label: 'Cortar', icon: 'scissors', act: () => b.cut() },
      { label: 'Copiar', icon: 'copy', act: () => b.copy() },
      { label: 'Duplicar', icon: 'layers-2', act: () => b.duplicate() },
      { label: 'Eliminar', icon: 'trash-2', danger: true, act: () => b.deleteSel() },
    ] },
    { label: 'Traer al frente', icon: 'bring-to-front', act: () => store.reorder(items.map((i) => i.id), 'front') },
    { label: 'Traer hacia delante', icon: 'arrow-up', act: () => store.reorder(items.map((i) => i.id), 'forward') },
    { label: 'Enviar hacia atrás', icon: 'arrow-down', act: () => store.reorder(items.map((i) => i.id), 'backward') },
    { label: 'Enviar al fondo', icon: 'send-to-back', act: () => store.reorder(items.map((i) => i.id), 'back') },
    { sep: true },
    one?.type !== 'line' ? { label: 'Voltear horizontalmente', icon: 'flip-horizontal-2', act: () => flip('flipX') } : null,
    one?.type !== 'line' ? { label: 'Voltear verticalmente', icon: 'flip-vertical-2', act: () => flip('flipY') } : null,
    one?.type !== 'line' ? { label: 'Girar 90°', icon: 'rotate-cw', act: () => store.update(items.filter((i) => i.type !== 'line').map((i) => i.id), (it) => ({ rot: (((it.rot || 0) + 90) % 360) })) } : null,
    one?.rot ? { label: 'Enderezar', icon: 'square', act: () => store.update([one.id], { rot: 0 }) } : null,
    items.length > 1 ? { label: grouped ? 'Desagrupar' : 'Agrupar', icon: grouped ? 'ungroup' : 'group', act: () => b.toggleGroup() } : null,
    { label: 'Bloquear', icon: 'lock', act: () => b.toggleLock() },
    { sep: true },
    one ? { label: 'Copiar estilo', icon: 'pipette', act: () => { b.app.styleClip = style(one); toast('Estilo copiado', 1000); } } : null,
    b.app.styleClip ? { label: 'Pegar estilo', icon: 'sparkles', act: () => { const st = Object.fromEntries(Object.entries(b.app.styleClip).filter(([, v]) => v !== undefined)); store.update(items.map((i) => i.id), (it) => applyStyle(it, st)); } } : null,
    one?.type === 'image' ? { label: 'Guardar o compartir imagen', icon: 'share', act: () => insert.shareItemFile(one) } : null,
    one?.type === 'image' ? { label: 'Quitar recorte', icon: 'crop', act: () => store.update([one.id], { crop: undefined, ...uncropSize(one) }) } : null,
    { label: 'Ajustar vista a la selección', icon: 'maximize', act: () => b.vp.fit(G.unionBox(items.map((i) => G.aabb(i, b.map))), { maxZ: 2 }) },
  ], { keep: true });
}

function applyStyle(it, st) {
  const allowed = {
    note: ['color', 'font', 'fsize', 'bold', 'italic', 'underline', 'align', 'tcolor'],
    shape: ['fill', 'stroke', 'sw', 'dash', 'font', 'fsize', 'bold', 'italic', 'underline', 'align', 'tcolor'],
    text: ['font', 'fsize', 'bold', 'italic', 'underline', 'align', 'tcolor', 'fill'],
    ink: ['color', 'opacity'], line: ['color', 'width', 'dash'], table: ['font', 'fsize', 'tcolor', 'fill', 'stroke'],
  }[it.type] || [];
  const p = {};
  for (const k of allowed) if (k in st) p[k] = st[k];
  return p;
}

function uncropSize(it) {
  const c = it.crop;
  if (!c) return {};
  const fw = it.w / (1 - c.l - c.r), fh = it.h / (1 - c.t - c.b);
  return { x: it.x - c.l * fw, y: it.y - c.t * fh, w: fw, h: fh };
}
