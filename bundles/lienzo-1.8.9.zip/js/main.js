// Arranque de la app y navegación entre la galería y el editor.
import { Home } from './home.js';
import { Board } from './board.js';
import * as db from './db.js';
import { uid, h, icon } from './util.js';
import { settings } from './settings.js';
import { onBackButton, exitApp, onAppPause } from './native.js';
import { closeTopPopover, closeAllPopovers, toast, popover, segmented } from './ui.js';
import * as insert from './insert.js';
import * as panels from './panels.js';
import { shapePicker } from './inspector.js';
import { store } from './store.js';
import { newNotebookContent, newNotebookDialog, pagesPanel } from './notebook.js';

import { VERSION } from './version.js';
import { pressureCalibration } from './pressure.js';
import { initUpdater, check as checkUpdates } from './updater.js';

class App {
  constructor() {
    this.current = 'home';
    this.presenting = null;
    this.styleClip = null;
    this.applyTheme();
    this.home = new Home(this);
    this.board = new Board(this);
    this.bindToolbar();
    this.bindDropAndPaste();
    onBackButton(() => this.back());
    onAppPause(() => { if (this.current === 'board') this.board.persist(); });
    matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => this.applyTheme());
    db.requestPersistence();
    this.showHome();
    initUpdater();
  }

  clipboard() {
    if (this._clip) return this._clip;
    try { return JSON.parse(localStorage.getItem('lienzo.clip') || 'null'); } catch { return null; }
  }
  setClipboard(c) { this._clip = c; try { localStorage.setItem('lienzo.clip', JSON.stringify(c)); } catch { /* demasiado grande: queda en memoria */ } }

  show(screen) {
    this.current = screen;
    document.getElementById('home').classList.toggle('active', screen === 'home');
    document.getElementById('board').classList.toggle('active', screen === 'board');
  }

  async showHome() { this.show('home'); await this.home.refresh(); }

  async openBoard(id) {
    const meta = await db.getMeta(id);
    if (!meta) { toast('No se encuentra el tablero'); return; }
    const content = await db.getContent(id);
    this.show('board');
    await this.board.open(meta, content || { items: [] });
  }

  async closeBoard() {
    await this.board.close();
    await this.showHome();
  }

  /** kind: 'board' (lienzo infinito) o 'notebook' (cuaderno: primero se elige el papel). */
  async newBoard(kind = 'board') {
    let content = { items: [], scenes: [], bg: 'dots', view: null };
    if (kind === 'notebook') {
      const opts = await newNotebookDialog();
      if (!opts) return;
      content = newNotebookContent(opts);
    }
    const now = Date.now();
    const meta = { id: uid(), title: kind === 'notebook' ? 'Cuaderno sin título' : 'Sin título', kind, created: now, updated: now, favorite: false, thumb: null, folder: null, tags: [], ...(this.current === 'home' ? this.home.newBoardDefaults() : {}) };
    await db.saveBoard(meta, content);
    await this.openBoard(meta.id);
  }

  async duplicateBoard(id, open = false) {
    if (this.current === 'board' && store.meta?.id === id) await this.board.persist();
    const meta = await db.getMeta(id), content = await db.getContent(id);
    const now = Date.now();
    const copy = { ...meta, id: uid(), title: `${meta.title} (copia)`, created: now, updated: now };
    await db.saveBoard(copy, { ...content, id: copy.id });
    toast('Tablero duplicado');
    if (open) { await this.board.close(); await this.openBoard(copy.id); } else this.home.refresh();
  }

  async trashBoard(id) {
    if (this.current === 'board' && store.meta?.id === id) { await this.board.close(); }
    const meta = await db.getMeta(id);
    meta.deletedAt = Date.now();
    await db.putMeta(meta);
    toast('Movido a «Eliminados recientemente»');
    await this.showHome();
  }

  back() {
    const viewers = document.querySelectorAll('#overlay .viewer');
    if (viewers.length) { viewers[viewers.length - 1].dispatchEvent(new Event('back')); return; }
    if (closeTopPopover()) return;
    if (this.current === 'board') {
      if (document.querySelector('.crop-bar')) { document.querySelector('.crop-bar .btn').click(); return; }
      if (this.board.back()) return;
      this.closeBoard();
      return;
    }
    if (this.home.el.classList.contains('side-open')) { this.home.el.classList.remove('side-open'); return; }
    exitApp();
  }

  applyTheme() {
    const t = settings.theme;
    if (t === 'system') delete document.documentElement.dataset.theme; else document.documentElement.dataset.theme = t;
    const dark = t === 'dark' || (t === 'system' && matchMedia('(prefers-color-scheme: dark)').matches);
    document.querySelector('meta[name="theme-color"]').content = dark ? '#1C1C1E' : '#F2F2F7';
    if (this.board && store.meta) { this.board.r.sync(store.items, true); this.board.onTheme(); }
  }

  settingsPanel(anchor) {
    const row = (label, ctrl) => h('div.set-row', {}, h('span', { text: label }), ctrl);
    const toggle = (key, after) => { const c = h('input.switch', { type: 'checkbox' }); c.checked = !!settings[key]; c.onchange = () => { settings[key] = c.checked; after?.(); }; return c; };
    popover(anchor, h('div.pop-pad.settings', {},
      h('div.pop-title', { text: 'Ajustes' }),
      row('Apariencia', segmented([{ value: 'system', label: 'Sistema' }, { value: 'light', label: 'Claro' }, { value: 'dark', label: 'Oscuro' }], settings.theme, (v) => { settings.theme = v; this.applyTheme(); })),
      row('Dibujar con el dedo', segmented([{ value: 'auto', label: 'Auto' }, { value: 'on', label: 'Sí' }, { value: 'off', label: 'No' }], settings.fingerDraw, (v) => { settings.fingerDraw = v; })),
      h('p.pop-note', { text: 'Auto: el dedo dibuja hasta que uses el S Pen; desde entonces el S Pen dibuja y el dedo mueve el lienzo.' }),
      row('Reconocer formas', toggle('autoShape')),
      row('Guías de alineación', toggle('snap')),
      row('Presión del lápiz', segmented([{ value: 'soft', label: 'Suave' }, { value: 'normal', label: 'Normal' }, { value: 'strong', label: 'Marcada' }, { value: 'max', label: 'Máxima' }], settings.pressureBoost ?? 'strong', (v) => { settings.pressureBoost = v; })),
      h('p.pop-note', { text: 'Cuánto engorda el trazo al apretar y cuánto adelgaza al rozar. «Marcada» es lo más parecido a Freeform.' }),
      h('button.btn.full', { text: settings.pressureCal ? 'Calibrar la presión del S Pen (calibrada)' : 'Calibrar la presión del S Pen', onclick: () => { closeAllPopovers(); pressureCalibration(); } }),
      h('button.btn.full', { text: 'Probar el S Pen y su botón', onclick: () => this.penTest() }),
      h('button.btn.full', { html: `Buscar actualizaciones <small style="margin-left:auto;color:var(--fg3)">v${VERSION}</small>`, onclick: () => { closeAllPopovers(); checkUpdates({ manual: true }); } }),
      h('p.pop-note', { html: `Gestos: dos dedos para mover y hacer zoom · toca dos veces con dos dedos para deshacer y dos veces con tres para rehacer · S Pen: mantén el botón mientras escribes para borrar, o púlsalo sin tocar la pantalla para cambiar entre lápiz y goma.<br><br>Pizarra ${VERSION} · Todo se guarda solo en esta tablet. Haz copias de seguridad desde la galería.` })), { className: 'settings-pop' });
  }

  /** Pantalla de diagnóstico: muestra lo que envía el S Pen (útil si el botón no responde). */
  penTest() {
    closeAllPopovers();
    const log = h('pre.pen-log');
    const lines = [];
    const add = (s) => { lines.unshift(`${new Date().toLocaleTimeString('es-ES')}  ${s}`); lines.length = Math.min(lines.length, 40); log.textContent = lines.join('\n'); };
    const area = h('div.pen-area', { text: 'Escribe aquí con el S Pen. Prueba también a pulsar el botón lateral en el aire y mientras tocas la pantalla.' });
    let lastMove = 0, lastKey = '';
    const fmt = (e) => `${e.type.replace('pointer', '')} · ${e.pointerType} · botón ${e.button} · botones ${e.buttons} · presión ${(e.pressure ?? 0).toFixed(2)}`;
    for (const t of ['pointerdown', 'pointerup', 'pointermove', 'pointercancel']) {
      area.addEventListener(t, (e) => {
        e.preventDefault();
        const key = `${e.pointerType}${e.buttons}${e.pressure > 0}`;
        if (t === 'pointermove' && key === lastKey && performance.now() - lastMove < 400) return;
        lastMove = performance.now(); lastKey = key;
        add(fmt(e));
      });
    }
    area.addEventListener('contextmenu', (e) => { e.preventDefault(); add('menú contextual'); });
    const onKey = (e) => add(`tecla ${e.key} (${e.code || e.keyCode})`);
    window.addEventListener('keydown', onKey);
    window.__spenDiag = (a, b) => add(`${a}: ${b}`);
    const close = () => { window.removeEventListener('keydown', onKey); window.__spenDiag = null; ov.remove(); };
    const ov = h('div.viewer', {},
      h('div.viewer-bar', {}, h('button.btn.icon', { html: icon('x', 22), onclick: close }), h('b.viewer-title', { text: 'Probar el S Pen' }),
        h('button.btn', { text: 'Copiar registro', onclick: () => navigator.clipboard?.writeText(lines.join('\n')).then(() => toast('Copiado')).catch(() => toast('No se pudo copiar')) })),
      h('div.pen-test', {}, area, log));
    ov.addEventListener('back', close);
    document.getElementById('overlay').append(ov);
    add(window.Capacitor?.isNativePlatform?.() ? 'App Android: el botón también se lee desde el sistema' : 'Navegador: solo eventos web');
  }

  bindToolbar() {
    const b = this.board;
    const on = (id, fn) => document.getElementById(id).addEventListener('click', (e) => { closeAllPopovers(); fn(e.currentTarget); });
    on('b-back', () => this.closeBoard());
    on('b-title', (el) => panels.titleMenu(b, el));
    on('t-note', () => insert.addNote(b));
    on('t-shape', (el) => shapePicker(el, (s) => insert.addShape(b, s)));
    on('t-text', () => insert.addText(b));
    on('t-draw', () => b.setMode(b.mode === 'draw' ? 'select' : 'draw'));
    on('t-media', (el) => insert.mediaMenu(b, el));
    on('t-attach', (el) => insert.attachMenu(b, el));
    on('t-table', (el) => insert.tablePicker(b, el));
    on('t-undo', () => b.undo());
    on('t-redo', () => b.redo());
    on('t-share', (el) => panels.shareMenu(b, el));
    on('t-more', (el) => panels.moreMenu(b, el));
    on('zoom-pill', (el) => panels.zoomMenu(b, el));
    on('page-pill', (el) => pagesPanel(b, el));
    on('multi-done', () => b.setMulti(false));
  }

  bindDropAndPaste() {
    const vp = document.getElementById('viewport');
    vp.addEventListener('dragover', (e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; });
    vp.addEventListener('drop', async (e) => {
      e.preventDefault();
      if (this.current !== 'board') return;
      const at = this.board.vp.toWorld(e.clientX, e.clientY);
      const files = [...(e.dataTransfer.files || [])];
      if (files.length) return insert.insertFileList(this.board, files, at);
      const url = e.dataTransfer.getData('text/uri-list');
      const text = e.dataTransfer.getData('text/plain');
      if (url && /^https?:/.test(url)) this.board.place({ id: uid(), type: 'link', url, title: '', w: this.board.unit(300), h: this.board.unit(76), rot: 0 }, at);
      else if (text) this.board.place({ id: uid(), type: 'text', text, w: this.board.unit(320), h: 40, rot: 0, fsize: 24 }, at);
    });
    document.addEventListener('paste', (e) => {
      if (this.current !== 'board' || this.board.editing || /INPUT|TEXTAREA/.test(document.activeElement?.tagName)) return;
      const files = [...(e.clipboardData?.files || [])];
      if (files.length) { e.preventDefault(); insert.insertFileList(this.board, files); return; }
      if (this.clipboard()) { e.preventDefault(); this.board.paste(); return; }
      const text = e.clipboardData?.getData('text/plain');
      if (text) {
        e.preventDefault();
        if (/^https?:\/\/\S+$/.test(text.trim())) this.board.place({ id: uid(), type: 'link', url: text.trim(), title: '', w: this.board.unit(300), h: this.board.unit(76), rot: 0 });
        else this.board.place({ id: uid(), type: 'text', text, w: this.board.unit(320), h: 40, rot: 0, fsize: 24 });
      }
    });
  }
}

window.addEventListener('error', (e) => console.error('Error', e.error || e.message));
window.lienzo = new App();
