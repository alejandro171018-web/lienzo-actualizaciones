// Claude en la pizarra (solo en Studio, la app de escritorio): panel de chat y herramientas que Claude usa sobre el tablero.
// El proceso de Studio ejecuta Claude y llama aquí (window.studio.onBoardCall) para leer o cambiar el tablero abierto.
import { h, icon, uid } from './util.js';
import { store } from './store.js';
import { NOTE_COLORS } from './render.js';
import * as G from './geom.js';
import { makeInk, TOOLS as INK } from './ink.js';
import { writeText, drawShape } from './handwrite.js';
import { renderToCanvas, contentBox } from './export.js';
import { startPresent } from './panels.js';
import * as NB from './notebook.js';

const S = window.studio;
const app = () => window.lienzo;
const board = () => app().board;
const isOpen = () => app().current === 'board' && !!store.meta;

// Herramientas del tablero -------------------------------------------------------------------
const COLORS = { amarillo: 0, naranja: 1, rosa: 2, morado: 3, lila: 3, azul: 4, verde: 5, gris: 6 };
const color = (c) => (c && /^#[0-9a-f]{6}$/i.test(c) ? c : NOTE_COLORS[COLORS[(c || '').toLowerCase()] ?? 0]);
const TYPES = { note: 'nota', text: 'texto', shape: 'forma', emoji: 'emoji', link: 'enlace', image: 'imagen', table: 'tabla', frame: 'marco', ink: 'trazo' };
const r0 = (n) => Math.round(n);

function describe(it) {
  const d = { id: it.id, tipo: TYPES[it.type] || it.type, x: r0(it.x), y: r0(it.y), ancho: r0(it.w), alto: r0(it.h) };
  if (it.text) d.texto = String(it.text).slice(0, 600);
  if (it.type === 'note') d.color = Object.keys(COLORS).find((k) => NOTE_COLORS[COLORS[k]] === it.color) || it.color;
  if (it.url) d.url = it.url;
  if (it.title) d.titulo = it.title;
  if (it.name) d.archivo = it.name;
  if (it.cells) d.celdas = it.cells;
  if (it.check) d.casilla = it.done ? 'hecha' : 'pendiente';
  if (it.type === 'audio') d.transcripcion = it.transcript == null ? '(aún pasándose a texto)' : String(it.transcript).slice(0, 8000);
  return d;
}

function readBoard() {
  if (!isOpen()) return { error: 'No hay ningún tablero abierto. Pide al usuario que abra uno o crea uno con crear_tablero.' };
  const b = board();
  const items = [], lines = [], groups = new Map(), loose = [];
  for (const it of store.items) {
    if (it.type === 'line') {
      if (it.a?.id && it.b?.id) lines.push({ id: it.id, desde: it.a.id, hasta: it.b.id });
    } else if (it.type === 'ink' && it.group) {
      const g = groups.get(it.group) || { grupo: it.group, trazos: 0, cajas: [], label: it.label };
      g.trazos++; g.cajas.push(it); groups.set(it.group, g);
    } else if (it.type === 'ink') loose.push(G.aabb(it, board().map));
    else items.push(describe(it));
  }
  // Los trazos agrupados (lo que Claude escribe o dibuja, o lo que agrupa el usuario) se describen como un solo dibujo.
  const dibujos = [...groups.values()].map(({ grupo, trazos, cajas, label }) => {
    const b = G.unionBox(cajas.map((i) => G.aabb(i, board().map)));
    return { grupo, trazos, x: r0(b.x), y: r0(b.y), ancho: r0(b.w), alto: r0(b.h), ...(label ? { contenido: label } : {}) };
  });
  const hw = Object.values(store.hw || {}).map((e) => (typeof e === 'string' ? e : e?.t)).filter((t) => t && t.trim());
  const v = b.vp.visibleBox();
  return {
    titulo: store.meta.title,
    elementos: items,
    conexiones: lines,
    ...(dibujos.length ? { dibujos } : {}),
    ...(loose.length ? { escrito_a_mano: { zonas: inkZones(loose), aviso: 'Son trazos del usuario (letra o dibujos): léelos con ver_tablero (ids no hacen falta; usa que="todo" o "visible").' } } : {}),
    ...(hw.length ? { texto_escrito_a_mano: hw.join('\n').slice(0, 4000) } : {}),
    seleccionados: [...b.sel],
    ...(NB.isNotebook() ? { cuaderno: { paginas: store.pages.length, pagina_actual: NB.currentPage(b) + 1, tamano_pagina: { ancho: NB.pageSize().w, alto: NB.pageSize().h }, zonas_de_pagina: store.pages.slice(0, 40).map((_, i) => { const r = NB.pageRect(i); return { pagina: i + 1, x: r.x, y: r.y, ancho: r.w, alto: r.h }; }), aviso: 'Es un CUADERNO: todo tiene que ir dentro de las páginas (fuera no se ve). Si no das x/y se coloca solo en la página actual o la siguiente con hueco. Para LEER lo escrito, usa ver_tablero con pagina (de 2 en 2), sin abrir ni mover nada.' } } : {}),
    zona_visible: { x: r0(v.x), y: r0(v.y), ancho: r0(v.w), alto: r0(v.h) },
  };
}

/** Agrupa los trazos sueltos en zonas (lo que está a menos de ~80 px se considera lo mismo). */
function inkZones(boxes) {
  const zones = [];
  for (const b of boxes) {
    let z = { x: b.x, y: b.y, w: b.w, h: b.h, n: 1 };
    for (let i = zones.length - 1; i >= 0; i--) {
      const o = zones[i];
      if (z.x < o.x + o.w + 80 && z.x + z.w + 80 > o.x && z.y < o.y + o.h + 80 && z.y + z.h + 80 > o.y) {
        const x = Math.min(z.x, o.x), y = Math.min(z.y, o.y);
        z = { x, y, w: Math.max(z.x + z.w, o.x + o.w) - x, h: Math.max(z.y + z.h, o.y + o.h) - y, n: z.n + o.n };
        zones.splice(i, 1);
      }
    }
    zones.push(z);
  }
  return zones.slice(0, 40).map((z) => ({ x: r0(z.x), y: r0(z.y), ancho: r0(z.w), alto: r0(z.h), trazos: z.n }));
}

const overlaps = (a, list, gap = 30) => list.some((o) => a.x < o.x + o.w + gap && a.x + a.w + gap > o.x && a.y < o.y + o.h + gap && a.y + a.h + gap > o.y);

function createNotes({ notas }) {
  if (!isOpen()) return readBoard();
  const b = board(), map = b.map;
  const taken = store.items.filter((i) => i.type !== 'line').map((i) => G.aabb(i, map));
  const content = G.unionBox(taken);
  const refs = new Map();
  const made = [];
  let cursor = null;   // siguiente hueco libre para las notas sin posición
  for (const n of notas) {
    const isText = n.tipo === 'texto';
    const w = n.ancho || (isText ? 360 : 220), hh = n.alto || (isText ? 60 : 220);
    let x = n.x, y = n.y;
    if (NB.isNotebook()) ({ x, y } = x == null || y == null ? freeSpot(w, hh, n.cerca_de && (store.get(n.cerca_de) ? n.cerca_de : refs.get(n.cerca_de)), made.map((m) => ({ x: m.x, y: m.y, w: m.w, h: m.h }))) : keepInPage(x, y, w, hh, n.cerca_de, made.map((m) => ({ x: m.x, y: m.y, w: m.w, h: m.h }))));
    else if (x == null || y == null) {
      const near = n.cerca_de && (store.get(n.cerca_de) || made.find((m) => m.id === refs.get(n.cerca_de)));
      if (near) { x = near.x + near.w + 60; y = near.y; } else {
        if (!cursor) { const v = b.vp.visibleBox(); cursor = content ? { x: content.x + content.w + 120, y: content.y } : { x: v.x + v.w / 2 - w / 2, y: v.y + v.h / 3 }; }
        x = cursor.x; y = cursor.y;
      }
      let tries = 0;
      while (overlaps({ x, y, w, h: hh }, taken) && tries++ < 200) y += 60;
      if (!near) cursor = { x, y: y + hh + 60 };
    }
    const it = isText
      ? { id: uid(), type: 'text', x, y, w, h: hh, rot: 0, text: n.texto, fsize: 24 }
      : { id: uid(), type: 'note', x, y, w, h: hh, rot: 0, color: color(n.color), text: n.texto, fsize: 'auto' };
    made.push(it);
    taken.push({ x, y, w, h: hh });
    if (n.ref) refs.set(n.ref, it.id);
  }
  store.add(made);
  b.markFresh(made.map((m) => m.id));
  lastRefs = refs;
  return { creados: made.map((m) => ({ id: m.id, ref: [...refs].find(([, v]) => v === m.id)?.[0], x: r0(m.x), y: r0(m.y), ancho: m.w, alto: m.h })) };
}

let lastRefs = new Map();
const resolve = (k) => (store.get(k) ? k : lastRefs.get(k));

function connect({ conexiones }) {
  if (!isOpen()) return readBoard();
  const lines = [], fallos = [];
  for (const c of conexiones) {
    const a = resolve(c.desde), z = resolve(c.hasta);
    if (!a || !z) { fallos.push(`${c.desde} → ${c.hasta}`); continue; }
    lines.push({ id: uid(), type: 'line', a: { id: a }, b: { id: z }, style: 'curved', color: '#000000', width: 2, arrowB: c.flecha === false ? undefined : 'arrow' });
  }
  if (lines.length) store.add(lines);
  return { conectados: lines.length, ...(fallos.length ? { no_encontrados: fallos } : {}) };
}

function edit({ cambios }) {
  if (!isOpen()) return readBoard();
  const patch = new Map();
  for (const c of cambios) {
    const id = resolve(c.id);
    if (!id) continue;
    const p = {};
    if (c.texto != null) p.text = c.texto;
    if (c.color) p.color = color(c.color);
    if (c.x != null) p.x = c.x;
    if (c.y != null) p.y = c.y;
    if (c.ancho) p.w = c.ancho;
    if (c.alto) p.h = c.alto;
    patch.set(id, p);
  }
  store.mutate((items) => items.map((it) => (patch.has(it.id) ? { ...it, ...patch.get(it.id) } : it)));
  return { editados: patch.size };
}

// Lápices: escribir y dibujar a mano -------------------------------------------------------------
const PENS = { pluma: 'pen', boligrafo: 'monoline', monolinea: 'monoline', pincel: 'fountain', estilografica: 'fountain', rotulador: 'marker', lapiz: 'pencil', cera: 'crayon', acuarela: 'watercolor' };
// Pluma, Bolígrafo y Pincel escriben con el motor nuevo (como en GoodNotes), igual que cuando escribe el usuario.
const tipFor = (tool) => (['pen', 'monoline', 'fountain'].includes(tool) ? 'pf' : undefined);
const INK_COLORS = { negro: '#000000', gris: '#8E8E93', rojo: '#E5352B', naranja: '#F28C28', amarillo: '#F7C600', verde: '#2FA84F', azul: '#1F6FE5', morado: '#8E44C9', rosa: '#E8508A', marron: '#8B5A2B' };
const plain = (s) => (s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
const pen = (name) => PENS[plain(name)] || 'pen';
const inkColor = (c) => (c && /^#[0-9a-f]{6}$/i.test(c) ? c : INK_COLORS[plain(c)] || '#000000');

/** Cuaderno: primer hueco de w×h dentro de una página (empezando por la del elemento cercano o la actual). */
function pageSpot(w, hh, near, taken) {
  const b = board(), M = 40;
  const nearIt = near && store.get(resolve(near));
  const first = nearIt ? Math.max(0, NB.pageOf(nearIt, b.map)) : NB.currentPage(b);
  const order = [...Array(store.pages.length).keys()].map((k) => (first + k) % store.pages.length);
  for (const i of order) {
    const pg = NB.pageRect(i);
    const ww = Math.min(w, pg.w - M * 2);
    for (let y = pg.y + M; y + hh <= pg.y + pg.h - M; y += 20) {
      for (let x = pg.x + M; x + ww <= pg.x + pg.w - M; x += 20) {
        if (!overlaps({ x, y, w: ww, h: hh }, taken, 16)) return { x, y };
      }
    }
  }
  // No cabe en ninguna: página nueva al final.
  NB.addPage(b);
  const pg = NB.pageRect(store.pages.length - 1);
  return { x: pg.x + M, y: pg.y + M };
}

/** En un cuaderno, lo que quede fuera de las páginas se recoloca dentro (si no, no se podría ver). */
function keepInPage(x, y, w, hh, near, extra) {
  if (!NB.isNotebook() || x == null || y == null) return { x, y };
  const inside = store.pages.some((_, i) => { const pg = NB.pageRect(i); return x >= pg.x && y >= pg.y && x + Math.min(w, pg.w) <= pg.x + pg.w && y + hh <= pg.y + pg.h; });
  return inside ? { x, y } : freeSpot(w, hh, near, extra);
}

/** Hueco libre para algo de w×h: junto a otro elemento, a la derecha de lo que hay o en el centro de la vista. */
function freeSpot(w, hh, near, extra = []) {
  const b = board(), map = b.map;
  const taken = [...store.items.filter((i) => i.type !== 'line').map((i) => G.aabb(i, map)), ...extra];
  if (NB.isNotebook()) return pageSpot(w, hh, near, taken);
  let x, y;
  const n = near && store.get(resolve(near));
  if (n) { const a = G.aabb(n, map); x = a.x + a.w + 60; y = a.y; } else {
    const content = G.unionBox(taken), v = b.vp.visibleBox();
    if (content) { x = content.x + content.w + 120; y = content.y; } else { x = v.x + v.w / 2 - w / 2; y = v.y + v.h / 3; }
  }
  let tries = 0;
  while (overlaps({ x, y, w, h: hh }, taken) && tries++ < 200) y += 60;
  return { x, y };
}

function addInk(strokes, { lapiz, color, grosor, label }) {
  const tool = pen(lapiz);
  const size = grosor || INK[tool].sizes[1];
  const group = uid();
  // label: qué es (lo guarda el propio trazo para que Claude lo reconozca al leer el tablero).
  const items = strokes.filter((s) => s.length).map((s) => ({ ...makeInk(s, { tool, color: inkColor(color), size, opacity: 1, tip: tipFor(tool) }, uid()), group, label }));
  if (!items.length) return null;
  store.add(items);
  const box = G.unionBox(items.map((i) => G.aabb(i, board().map)));
  return { grupo: group, trazos: items.length, x: r0(box.x), y: r0(box.y), ancho: r0(box.w), alto: r0(box.h) };
}

function handwrite({ texto, x, y, tamano, ancho, letra, lapiz, color, grosor, cerca_de }) {
  if (!isOpen()) return readBoard();
  const size = tamano || 36;
  let { strokes, box } = writeText(texto, { x: 0, y: 0, size, font: letra, width: ancho || Infinity });
  if (x == null || y == null) ({ x, y } = freeSpot(box.w, box.h, cerca_de)); else ({ x, y } = keepInPage(x, y, box.w, box.h, cerca_de));
  strokes = strokes.map((s) => s.map((p) => ({ x: p.x + x, y: p.y + y, p: p.p })));
  return addInk(strokes, { lapiz, color, grosor: grosor || Math.max(1.5, size / 14), label: `texto escrito a mano: «${texto.slice(0, 120)}»` }) || { error: 'No había nada que escribir.' };
}

function draw({ trazos, x, y, ancho, alto, descripcion, cerca_de }) {
  if (!isOpen()) return readBoard();
  // Los trazos vienen en un lienzo de 0 a 100 y se escalan a ancho×alto en (x, y).
  const w = ancho || 300, hh = alto || w;
  if (x == null || y == null) ({ x, y } = freeSpot(w, hh, cerca_de)); else ({ x, y } = keepInPage(x, y, w, hh, cerca_de));
  const sx = w / 100, sy = hh / 100;
  const P = (px, py) => [x + px * sx, y + py * sy];
  const groups = new Map();   // mismo lápiz, color y grosor -> un grupo de trazos
  for (const t of trazos) {
    const world = {};
    if (t.puntos) world.puntos = t.puntos.map(([a, b]) => P(a, b));
    if (t.circulo) { const [cx, cy, rr] = t.circulo; world.elipse = [...P(cx, cy), rr * sx, rr * sy]; }
    if (t.elipse) { const [cx, cy, rx, ry] = t.elipse; world.elipse = [...P(cx, cy), rx * sx, ry * sy]; }
    if (t.rectangulo) { const [a, b, c, d] = t.rectangulo; world.rectangulo = [...P(a, b), c * sx, d * sy]; }
    if (t.linea) { const [a, b, c, d] = t.linea; world.linea = [...P(a, b), ...P(c, d)]; }
    const s = drawShape(world, { curve: t.recto !== true, scale: Math.max(0.5, Math.min(3, w / 300)) });
    const key = `${t.lapiz || ''}|${t.color || ''}|${t.grosor || ''}`;
    if (!groups.has(key)) groups.set(key, { opts: t, strokes: [] });
    groups.get(key).strokes.push(s);
  }
  // Todos los trazos del dibujo van en un único grupo para moverlo de una vez.
  const group = uid(), label = descripcion ? `dibujo: ${descripcion}` : 'dibujo';
  const items = [];
  for (const { opts, strokes } of groups.values()) {
    const tool = pen(opts.lapiz);
    const size = opts.grosor || INK[tool].sizes[1];
    for (const s of strokes) if (s.length) items.push({ ...makeInk(s, { tool, color: inkColor(opts.color), size, opacity: 1, tip: tipFor(tool) }, uid()), group, label });
  }
  if (!items.length) return { error: 'El dibujo no tenía trazos.' };
  store.add(items);
  return { grupo: group, trazos: items.length, x: r0(x), y: r0(y), ancho: r0(w), alto: r0(hh) };
}

/**
 * Imagen de una zona del tablero para que Claude vea lo dibujado (formas, esquemas, letra a mano).
 * que: 'seleccion' | 'visible' | 'todo', o ids concretos. Devuelve JPEG en base64 y cómo pasar de píxeles a coordenadas.
 */
async function look({ que, ids, pagina, zona } = {}) {
  if (!isOpen()) return readBoard();
  const b = board(), map = b.map;
  let box;
  const pick = ids?.length ? ids.flatMap((i) => (store.get(resolve(i)) ? [store.get(resolve(i))] : store.items.filter((it) => it.group === i)))
    : (que === 'seleccion' || (!que && b.sel.size)) ? b.selItems() : null;
  // Páginas del cuaderno (hasta 2 a la vez): para leer lo escrito sin mover la vista del usuario.
  const pages = NB.isNotebook() && pagina != null ? [].concat(pagina).map(Number).filter((n) => n >= 1 && n <= store.pages.length).slice(0, 2) : [];
  if (pages.length) box = G.unionBox(pages.map((n) => NB.pageRect(n - 1)));
  else if (zona?.length === 4) box = { x: zona[0], y: zona[1], w: zona[2], h: zona[3] };
  else if (pick?.length) box = G.unionBox(pick.map((i) => G.aabb(i, map)));
  else if (que === 'visible') box = b.vp.visibleBox();
  else box = contentBox(store.items);
  if (!box) return { error: 'El tablero está vacío.' };
  const pad = Math.max(20, Math.max(box.w, box.h) * 0.04);
  // Hasta 1200 px de lado (1600 para páginas: la letra a mano se lee mejor); cuesta pocos tokens.
  const scale = Math.min(2, (pages.length ? 1600 : 1200) / (Math.max(box.w, box.h) + pad * 2));
  const its = store.items.filter((it) => G.boxesIntersect(G.aabb(it, map), { x: box.x - pad, y: box.y - pad, w: box.w + pad * 2, h: box.h + pad * 2 }));
  const c = await renderToCanvas(its, box, scale, { pad, bg: '#FFFFFF' });
  return {
    imagen: c.toDataURL('image/jpeg', 0.85).split(',')[1],
    zona: { x: r0(box.x - pad), y: r0(box.y - pad), ancho: r0(box.w + pad * 2), alto: r0(box.h + pad * 2) },
    escala: Math.round(scale * 1000) / 1000,
    nota: 'Coordenadas del lienzo = zona.x + píxel_x / escala, zona.y + píxel_y / escala.',
  };
}

/** Presentar en la pizarra: cada escena es una zona del tablero (de unos elementos o un rectángulo), en orden. */
function scenes({ escenas, presentar }) {
  if (!isOpen()) return readBoard();
  const b = board(), r = b.vp.rect();
  const ratio = r.width / r.height;
  const out = [];
  for (const [i, e] of escenas.entries()) {
    let box = null;
    if (e.ids?.length) {
      const its = e.ids.flatMap((id) => (store.get(resolve(id)) ? [store.get(resolve(id))] : store.items.filter((it) => it.group === id)));
      box = G.unionBox(its.map((it) => G.aabb(it, b.map)));
    } else if (e.ancho && e.alto) box = { x: e.x, y: e.y, w: e.ancho, h: e.alto };
    if (!box) continue;
    // Margen y misma forma que la pantalla, para que la escena se vea entera al presentar.
    const pad = Math.max(box.w, box.h) * 0.08 + 30;
    let w = box.w + pad * 2, hh = box.h + pad * 2;
    if (w / hh > ratio) hh = w / ratio; else w = hh * ratio;
    out.push({ id: uid(), name: e.nombre || `Escena ${i + 1}`, cx: box.x + box.w / 2, cy: box.y + box.h / 2, z: Math.min(2, r.width / w), w, h: hh });
  }
  if (!out.length) return { error: 'Ninguna escena tenía elementos o zona válida.' };
  store.setScenes(out);
  if (presentar) setTimeout(() => startPresent(b), 300);
  return { escenas: out.length, ...(presentar ? { presentando: true } : { aviso: 'Para presentar: botón ••• › Escenas › Presentar.' }) };
}

async function openOther({ id, ids, zona }) {
  if (store.meta?.id !== id) {
    const meta = await (await import('./db.js')).getMeta(id);
    if (!meta) return { error: 'Ese tablero aún no está en este dispositivo (espera unos segundos a que se sincronice).' };
    if (app().current === 'board') await app().closeBoard();
    await app().openBoard(id);
  }
  const b = board();
  let box = null;
  if (ids?.length) box = G.unionBox(ids.map((i) => store.get(i)).filter(Boolean).map((i) => G.aabb(i, b.map)));
  else if (zona) box = { x: zona[0], y: zona[1], w: zona[2], h: zona[3] };
  if (box) { b.vp.fit(box, { maxZ: 1.2, insets: { top: 70, bottom: 40, left: 0, right: 0 } }); setTimeout(() => b.flashBox(box), 450); }
  return { abierto: store.meta.title };
}

/** Plan: título y pasos con casilla (textos con check), agrupados para moverlos de una vez. */
function plan({ titulo, pasos, calendario, x, y, cerca_de }) {
  if (!isOpen()) return readBoard();
  const W = NB.isNotebook() ? Math.min(600, NB.pageSize().w - 80 - (calendario ? 260 : 0)) : 600;
  // Alto real de cada texto (cuántas líneas ocupa con su letra), para que nada se monte.
  const mc = document.createElement('canvas').getContext('2d');
  const heightOf = (text, size, bold, width) => {
    mc.font = `${bold ? 700 : 400} ${size}px Inter, system-ui, sans-serif`;
    let lines = 1, line = '';
    for (const w of String(text).split(/\s+/)) { const t = line ? `${line} ${w}` : w; if (mc.measureText(t).width > width && line) { lines++; line = w; } else line = t; }
    return Math.ceil(lines * size * 1.25 + 12);
  };
  const estH = heightOf(titulo, 34, true, W) + pasos.reduce((a, p) => a + heightOf(p.texto, 22, false, W - 40) + 14, 0) + 60;
  if (x == null || y == null) ({ x, y } = freeSpot(W + (calendario ? 260 : 0), estH, cerca_de)); else ({ x, y } = keepInPage(x, y, W + (calendario ? 260 : 0), estH, cerca_de));
  const group = uid(), items = [];
  let cy = y;
  const th = heightOf(titulo, 34, true, W - 12);
  items.push({ id: uid(), type: 'text', x, y: cy, w: W, h: th, rot: 0, text: titulo, fsize: 34, bold: true, group }); cy += th + 18;
  let last = null;
  for (const p of pasos) {
    if (p.grupo && p.grupo !== last) { cy += last ? 10 : 0; items.push({ id: uid(), type: 'text', x, y: cy, w: W, h: 36, rot: 0, text: p.grupo, fsize: 22, bold: true, tcolor: '#8E8E93', group }); cy += 42; last = p.grupo; }
    const f = /^\d{4}-\d{2}-\d{2}$/.test(p.fecha || '') ? p.fecha : null;
    const label = f ? `${p.texto} · ${new Date(`${f}T12:00`).toLocaleDateString('es-ES', { day: 'numeric', month: 'short' })}` : p.texto;
    const hh = heightOf(label, 22, false, W - 44);
    items.push({ id: uid(), type: 'text', x, y: cy, w: W, h: hh, rot: 0, text: label, fsize: 22, check: true, done: false, group });
    if (calendario && f) {
      const d0 = f.replaceAll('-', ''), d1 = new Date(Date.parse(`${f}T12:00Z`) + 864e5).toISOString().slice(0, 10).replaceAll('-', '');
      const url = `https://calendar.google.com/calendar/render?action=TEMPLATE&text=${encodeURIComponent(p.texto)}&dates=${d0}/${d1}&details=${encodeURIComponent(`Del plan «${titulo}» (Pizarra)`)}`;
      items.push({ id: uid(), type: 'link', url, title: 'Añadir al calendario', x: x + W + 20, y: cy + hh / 2 - 26, w: 240, h: 52, rot: 0, group });
    }
    cy += Math.max(hh, calendario && f ? 58 : 0) + 10;
  }
  store.add(items);
  board().markFresh(items.map((i) => i.id));
  return { grupo: group, pasos: pasos.length, x: r0(x), y: r0(y) };
}
/** Pone en el tablero un archivo creado en el PC (vídeo o PDF de una presentación): así llega también a la tablet. */
async function placeFile({ archivo_id, nombre, mime }) {
  if (!isOpen()) return readBoard();
  let blob = await (await import('./db.js')).getBlob(archivo_id);
  if (!blob) blob = await (await import('./remote.js')).fetchBlob(archivo_id);
  if (!blob) return { error: 'No he podido traer el archivo del PC.' };
  const b = board();
  const spot = freeSpot(360, 280);
  const { insertFileList } = await import('./insert.js');
  await insertFileList(b, [new File([blob], nombre, { type: mime || blob.type })], { x: spot.x + 180, y: spot.y + 140 });
  const it = store.get([...b.sel][0]);
  if (it && NB.isNotebook()) {
    const maxW = NB.pageSize().w - 80, k = Math.min(1, maxW / it.w, (NB.pageSize().h - 80) / it.h);
    const w = it.w * k, hh = it.h * k;
    const pos = freeSpot(w, hh, null, []);
    store.update(it.id, { x: pos.x, y: pos.y, w, h: hh });
  }
  return { ok: true, nombre };
}

function remove({ ids }) {
  if (!isOpen()) return readBoard();
  // Un id de grupo borra todos sus trazos.
  ids = ids.flatMap((i) => (store.get(i) || lastRefs.has(i) ? [i] : store.items.filter((it) => it.group === i).map((it) => it.id)));
  const real = ids.map(resolve).filter(Boolean);
  store.remove(real);
  return { borrados: real.length };
}

async function newBoard({ titulo }) {
  if (app().current === 'board') await app().closeBoard();
  await app().newBoard('board');
  store.meta.title = titulo;
  document.querySelector('#b-title span').textContent = titulo;
  await board().persist();
  createdBoard = store.meta.id;
  return { id: store.meta.id, titulo };
}

function focus({ ids } = {}) {
  if (!isOpen()) return readBoard();
  const b = board();
  const list = (ids?.length ? ids.map((i) => store.get(resolve(i))) : store.items).filter(Boolean);
  const box = G.unionBox(list.map((i) => G.aabb(i, b.map)));
  if (box) b.vp.fit(box, { maxZ: 1, insets: { top: 70, bottom: 40, left: 0, right: 0 } });
  return { ok: true };
}

const TOOLS = { leer_tablero: readBoard, crear_notas: createNotes, conectar: connect, editar: edit, borrar: remove, crear_tablero: newBoard, enfocar: focus, escribir_a_mano: handwrite, dibujar: draw, ver_tablero: look, preparar_escenas: scenes, abrir_tablero: openOther, crear_plan: plan, colocar_archivo: placeFile };
S.onBoardCall((name, args) => TOOLS[name]?.(args || {}) ?? { error: `Herramienta desconocida: ${name}` });
window.__clTest = (name, args) => TOOLS[name](args);   // para las pruebas automáticas

// Panel de chat --------------------------------------------------------------------------------
let createdBoard = null;
let busy = false;
let curKey = null;

const keyNow = () => (isOpen() ? store.meta.id : 'galeria');
const logKey = (k) => `studio.chat.${k}`;
const loadLog = (k) => { try { return JSON.parse(localStorage.getItem(logKey(k)) || '[]'); } catch { return []; } };
const saveLog = (k, log) => { try { localStorage.setItem(logKey(k), JSON.stringify(log.slice(-120))); } catch { /* sin espacio: no pasa nada */ } };

const msgs = h('div.cl-msgs');
const input = h('textarea.cl-input', { rows: 1, placeholder: 'Pídele algo a Claude…' });
const sendBtn = h('button.cl-send', { title: 'Enviar', html: icon('arrow-up', 20) });
// Micrófono: tocas, hablas y vuelves a tocar. El PC lo pasa a texto y se envía a Claude.
const micBtn = h('button.cl-mic', { title: 'Hablar', 'aria-label': 'Hablar', html: icon('mic', 20) });
let rec = null;
async function toggleMic() {
  if (busy && !rec) return;
  if (rec) { rec.stop(); return; }
  let stream;
  try { stream = await navigator.mediaDevices.getUserMedia({ audio: true }); } catch { input.placeholder = 'Permite el micrófono para hablar'; return; }
  const mime = ['audio/webm;codecs=opus', 'audio/mp4', 'audio/webm'].find((m) => window.MediaRecorder?.isTypeSupported?.(m)) || '';
  const r = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
  const chunks = [], t0 = Date.now();
  r.ondataavailable = (e) => e.data.size && chunks.push(e.data);
  const timer = setInterval(() => { const s = Math.floor((Date.now() - t0) / 1000); input.placeholder = `Escuchando… ${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}  (toca el micro para terminar)`; }, 250);
  r.onstop = async () => {
    clearInterval(timer); stream.getTracks().forEach((t) => t.stop()); rec = null;
    panel.classList.remove('rec');
    if (!chunks.length || Date.now() - t0 < 500) { input.placeholder = 'Pídele algo a Claude…'; return; }
    panel.classList.add('dictating'); input.placeholder = 'Pasando a texto…';
    const blob = new Blob(chunks, { type: r.mimeType || 'audio/webm' });
    const b64 = await new Promise((res) => { const fr = new FileReader(); fr.onload = () => res(String(fr.result).split(',')[1]); fr.readAsDataURL(blob); });
    const out = await S.dictate(b64, blob.type);
    panel.classList.remove('dictating'); input.placeholder = 'Pídele algo a Claude…';
    const text = (out?.texto || '').trim();
    if (!text || text === '(sin voz)') { input.placeholder = out?.error || 'No te he oído bien, prueba otra vez'; return; }
    input.value = (input.value ? input.value + ' ' : '') + text;
    autosize();
    send();
  };
  rec = r;
  S.warm?.();   // el PC va cargando el modelo de voz mientras hablas
  panel.classList.add('rec');
  r.start(250);
}
micBtn.onclick = toggleMic;
if (!S.dictate || !navigator.mediaDevices?.getUserMedia) micBtn.hidden = true;
const selInfo = h('div.cl-sel');
const where = h('span.cl-where');
const panel = h('aside.cl-panel', {},
  h('header.cl-head', {},
    h('div.cl-title', {}, h('b', { html: `${icon('sparkles', 18)} Claude` }), where),
    S.remote ? null : h('button.cl-ic', { title: 'Conectar la tablet', html: icon('layers-2', 19), onclick: (e) => { const t = e.currentTarget; import('./remote.js').then((r) => r.pairPanel(t)); } }),
    h('button.cl-ic', { title: 'Empezar conversación nueva', html: icon('square-pen', 19), onclick: () => newChat() }),
    h('button.cl-ic', { title: 'Cerrar', html: icon('x', 20), onclick: () => toggle(false) })),
  msgs,
  h('div.cl-foot', {}, selInfo, h('div.cl-box', {}, input, micBtn, sendBtn)));
const fab = h('button.cl-fab', { title: 'Claude (Ctrl+J)', html: icon('sparkles', 24), onclick: () => toggle(true) });
document.body.append(panel, fab);
// Botón de la paleta de lápices: abre el chat (si el PC no responde en la tablet, lo atiende ask.js).
window.__claudeOpen = (anchor) => { if (S.remote && !window.__studioOnline) window.__askOpen?.(anchor); else toggle(true); };
document.querySelectorAll('.pk-claude').forEach((b) => { b.hidden = false; });
// Tablet sin PC: este botón se esconde y queda el de "Preguntar a la app de Claude" (ask.js).
if (S.remote) setInterval(() => { fab.hidden = !window.__studioOnline; }, 700);

let log = [];
function render() {
  msgs.innerHTML = '';
  if (!log.length) msgs.append(h('div.cl-empty', { html: isOpen()
    ? `<b>Claude ve este tablero.</b><br>Pídele que resuma, ordene o desarrolle tus ideas, o selecciona notas y pregúntale por ellas.`
    : `<b>Empieza un tablero con Claude.</b><br>Por ejemplo: «Crea un tablero con un resumen de <i>Hábitos atómicos</i> por capítulos».` }));
  for (const m of log) msgs.append(bubble(m));
  // Claude pregunta antes de algo grande: botones para contestar sin escribir.
  const lastMsg = log[log.length - 1];
  if (!busy && lastMsg?.role === 'bot' && /\?\s*$/.test(lastMsg.text || '')) {
    msgs.append(h('div.cl-quick', {}, ...['Sí, adelante', 'Cámbialo un poco'].map((t, i) => h('button.cl-qbtn', { text: t, onclick: () => { if (i) { input.focus(); input.value = ''; input.placeholder = '¿Qué cambio?'; } else { input.value = t; send(); } } }))));
  }
  msgs.scrollTop = msgs.scrollHeight;
}

const esc = (s) => s.replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const md = (s) => esc(s).replace(/\*\*(.+?)\*\*/g, '<b>$1</b>').replace(/`([^`]+)`/g, '<code>$1</code>').replace(/^[-*] /gm, '• ').replace(/\n/g, '<br>');
const TOOL_LABEL = {
  leer_tablero: () => 'Ha leído el tablero', enfocar: () => 'Ha movido la vista',
  crear_notas: (i) => `Ha creado ${i.notas?.length || ''} ${i.notas?.length === 1 ? 'nota' : 'notas'}`,
  conectar: (i) => `Ha conectado ${i.conexiones?.length || ''} ${i.conexiones?.length === 1 ? 'idea' : 'ideas'}`,
  editar: (i) => `Ha editado ${i.cambios?.length || ''} ${i.cambios?.length === 1 ? 'elemento' : 'elementos'}`,
  borrar: (i) => `Ha borrado ${i.ids?.length || ''} ${i.ids?.length === 1 ? 'elemento' : 'elementos'}`,
  crear_tablero: (i) => `Ha creado el tablero «${i.titulo}»`,
  escribir_a_mano: () => 'Ha escrito a mano',
  dibujar: (i) => (i.descripcion ? `Ha dibujado ${i.descripcion}` : 'Ha dibujado'),
  ver_tablero: () => 'Ha mirado el tablero', texto_de_voz: () => 'Ha escuchado una nota de voz', preparar_escenas: (i) => `Ha preparado ${i.escenas?.length || ''} escenas`, buscar_en_tableros: (i) => `Ha buscado «${i.consulta}» en tus tableros`, abrir_tablero: () => 'Ha abierto el tablero', crear_plan: (i) => `Ha creado el plan «${i.titulo}»`, crear_diapositivas: (i) => `Ha creado la presentación «${i.titulo}»`, crear_video: (i) => `Ha creado el vídeo «${i.titulo}»`,
  biblioteca: () => 'Ha mirado tu biblioteca', libro_info: (i) => `Ha abierto «${i.libro}»`, buscar_en_libro: (i) => `Ha buscado «${i.consulta}» en el libro`, leer_paginas: (i) => `Ha leído las páginas ${i.desde}${i.hasta && i.hasta !== i.desde ? `-${i.hasta}` : ''}`, guardar_formato: (i) => `Ha guardado el formato «${i.nombre}»`, usar_formato: (i) => `Ha mirado el formato «${i.nombre}»`,
  WebSearch: () => 'Ha buscado en internet', WebFetch: () => 'Ha leído una página web', Read: () => 'Ha leído un archivo',
};

function bubble(m) {
  if (m.role === 'user') return h('div.cl-msg.user', { text: m.text });
  if (m.role === 'tool') return h('div.cl-tool', { html: `${icon('check', 14)} ${esc(m.text)}` });
  if (m.role === 'steps') {
    const acts = m.items.filter((t) => t.startsWith('Ha '));
    // Trabajando: solo el último paso. Al acabar: una línea que se despliega con todos.
    if (m.live) return acts.length ? h('div.cl-tool.live', { text: `${acts[acts.length - 1]}…` }) : h('div');
    const d = h('details.cl-steps', {}, h('summary', { html: `${icon('check', 14)} ${acts.length} ${acts.length === 1 ? 'paso' : 'pasos'}` }));
    for (const t of m.items) d.append(h(t.startsWith('Ha ') ? 'div.cl-step' : 'div.cl-step.narr', { text: t }));
    return d;
  }
  if (m.role === 'login') return loginCard();
  if (m.role === 'error') return h('div.cl-msg.error', { text: m.text });
  return h('div.cl-msg.bot', { html: md(m.text || '') + (m.live ? '<span class="cl-dots"><i></i><i></i><i></i></span>' : '') });
}

function loginCard() {
  return h('div.cl-login', {},
    h('p', { html: '<b>Conecta Studio con tu cuenta de Claude.</b><br>Se abrirá una ventana: elige iniciar sesión con tu suscripción (Pro o Max) y acepta en el navegador. Solo hace falta una vez.' }),
    h('button.btn.primary', { text: 'Conectar con Claude', onclick: () => S.login() }),
    h('button.btn', { text: 'Ya he iniciado sesión', onclick: async () => { if ((await S.auth()).loggedIn) { log = log.filter((m) => m.role !== 'login'); saveLog(curKey, log); render(); } } }));
}

function last() { return log[log.length - 1]; }

S.onEvent((ev) => {
  if (ev.key !== runKey) return;
  const target = runLog;
  const tail = target[target.length - 1];
  // Cada petición deja dos mensajes: los pasos (plegados) y la respuesta final. Lo que Claude dice entre pasos va a los pasos.
  const steps = target.findLast((m) => m.role === 'steps' && m.live);
  if (ev.type === 'text') { if (tail?.role === 'bot' && tail.live) tail.text += ev.text; }
  else if (ev.type === 'tool') {
    if (tail?.role === 'bot' && tail.live && tail.text.trim()) { steps?.items.push(tail.text.trim()); tail.text = ''; }
    steps?.items.push((TOOL_LABEL[ev.name] || (() => `Ha usado ${ev.name}`))(ev.input || {}));
  } else if (ev.type === 'done') {
    if (steps) { delete steps.live; if (!steps.items.length) target.splice(target.indexOf(steps), 1); }
    for (let i = target.length - 1; i >= 0; i--) if (target[i].role === 'bot' && target[i].live) { if (!target[i].text.trim()) target.splice(i, 1); else delete target[i].live; }
    if (!ev.ok && ev.error) target.push(ev.error === 'login' || /not logged in|log in|\/login/i.test(ev.error) ? { role: 'login' } : { role: 'error', text: `No ha salido bien: ${ev.error}` });
    finish();
    return;
  }
  if (curKey === runKey) render();
});

let runKey = null, runLog = null;

async function send() {
  const text = input.value.trim();
  if (!text || busy) return;
  input.value = ''; autosize();
  curKey = keyNow();
  runKey = curKey; runLog = log; createdBoard = null;
  log.push({ role: 'user', text });
  log.push({ role: 'steps', items: [], live: true });
  log.push({ role: 'bot', text: '', live: true });
  saveLog(curKey, log);
  setBusy(true);
  render();
  const n = isOpen() ? board().sel.size : 0;
  await S.send(runKey, n ? `${text}\n\n(Tengo ${n} ${n === 1 ? 'elemento seleccionado' : 'elementos seleccionados'} en el tablero.)` : text);
}

async function finish() {
  saveLog(runKey, runLog);
  // Claude ha creado un tablero: la conversación sigue en ese tablero.
  if (createdBoard && createdBoard !== runKey) {
    await S.alias?.(runKey, createdBoard);
    saveLog(createdBoard, runLog);
    saveLog(runKey, []);
  } else if (keyNow() !== runKey) {
    // Claude te ha llevado a otro tablero: la última pregunta y su respuesta también se ven allí.
    const from = runLog.map((m) => m.role).lastIndexOf('user');
    saveLog(keyNow(), [...loadLog(keyNow()), ...runLog.slice(Math.max(0, from))]);
  }
  setBusy(false);
  sync(true);
}

function setBusy(v) {
  busy = v;
  sendBtn.innerHTML = icon(v ? 'circle-stop' : 'arrow-up', 20);
  sendBtn.title = v ? 'Parar' : 'Enviar';
  panel.classList.toggle('busy', v);
}

function newChat() {
  if (busy) return;
  S.forget(keyNow());
  log = []; saveLog(keyNow(), log); render();
}

function autosize() {
  input.style.height = 'auto';
  input.style.height = `${Math.min(input.scrollHeight, 180)}px`;
  input.style.overflowY = input.scrollHeight > 180 ? 'auto' : 'hidden';
}

/** Cambia de conversación al cambiar de tablero y actualiza el aviso de selección. */
function sync(force = false) {
  const k = keyNow();
  // Mientras Claude trabaja, el panel se queda en su conversación aunque cambie de tablero.
  if (busy && !force) { if (curKey !== runKey) { curKey = runKey; log = runLog; render(); } }
  else if (force || k !== curKey) {
    curKey = k;
    log = busy && k === runKey ? runLog : loadLog(k);
    where.textContent = isOpen() ? store.meta.title : 'Tableros';
    render();
  }
  const n = isOpen() ? board().sel.size : 0;
  selInfo.textContent = n ? `${n} ${n === 1 ? 'elemento seleccionado' : 'elementos seleccionados'}: Claude los tendrá en cuenta` : '';
  selInfo.hidden = !n;
}

function toggle(open = !document.body.classList.contains('claude-open')) {
  document.body.classList.toggle('claude-open', open);
  window.dispatchEvent(new Event('resize'));
  if (open) {
    sync(true);
    input.focus();
    S.auth().then((a) => { if (!a.loggedIn && last()?.role !== 'login') { log.push({ role: 'login' }); render(); } });
  }
}

sendBtn.onclick = () => (busy ? S.stop() : send());
input.addEventListener('keydown', (e) => { if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); send(); } });
input.addEventListener('input', autosize);
window.addEventListener('keydown', (e) => { if (e.ctrlKey && e.key.toLowerCase() === 'j') { e.preventDefault(); toggle(); } });
store.on(() => { if (document.body.classList.contains('claude-open')) sync(); });
setInterval(() => { if (document.body.classList.contains('claude-open')) sync(); }, 700);
