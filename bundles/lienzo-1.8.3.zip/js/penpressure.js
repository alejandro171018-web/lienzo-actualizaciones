// Presión del S Pen.
//
// El S Pen manda la presión de 0 a 1, pero cada tablet (y cada mano) la usa a su manera: en muchas Samsung,
// escribir normal ya da casi 1, así que todos los trazos salían igual de gordos y apretar no cambiaba nada.
// Aquí se aprende sola cuál es TU rango real (lo que más se repite al escribir) y se reparte entre el trazo
// fino y el gordo: escribir normal queda en el medio, rozar adelgaza y apretar engorda de verdad.
// La calibración manual (Ajustes) sigue mandando si la has hecho.
import { settings } from './settings.js';

const BINS = 50;          // histograma de 0 a 1 en pasos de 0,02
const MIN_SPAN = 0.22;    // aunque escribas siempre igual, no se exagera el temblor de la mano
let cache = null;

/** Lo aprendido { med, half, min, max } (presión típica y su margen) o null si aún no hay datos suficientes. */
export function autoRange() {
  if (cache !== null) return cache || null;
  const h = settings.pressureHist;
  cache = false;
  if (!Array.isArray(h) || h.length !== BINS) return null;
  const total = h.reduce((a, b) => a + b, 0);
  if (total < 120) return null;   // unos pocos trazos antes de fiarse
  const at = (q) => {
    let acc = 0;
    for (let i = 0; i < BINS; i++) { acc += h[i]; if (acc >= q * total) return (i + 0.5) / BINS; }
    return 1;
  };
  const lo = at(0.1), hi = at(0.9), med = at(0.5);
  cache = { med, half: Math.max(MIN_SPAN / 2, (hi - lo) / 2), min: lo, max: hi };
  return cache;
}

/** Se llama al terminar cada trazo con el S Pen, con la presión tal como llegó (sin el principio ni el final). */
export function learnPressure(raw) {
  if (!raw || raw.length < 8) return;
  const k = Math.floor(raw.length * 0.15);
  const mid = raw.slice(k, raw.length - k);
  let h = settings.pressureHist;
  if (!Array.isArray(h) || h.length !== BINS) h = new Array(BINS).fill(0);
  // Lo antiguo pesa cada vez menos: si cambias de forma de escribir, se adapta.
  const decay = 0.985;
  h = h.map((v) => Math.round(v * decay * 100) / 100);
  // Cada trazo cuenta lo mismo, sea largo o corto (hasta 40 muestras).
  const step = Math.max(1, Math.floor(mid.length / 40));
  for (let i = 0; i < mid.length; i += step) {
    const p = mid[i];
    if (!(p > 0)) continue;
    h[Math.min(BINS - 1, Math.floor(Math.min(1, p) * BINS))] += 1;
  }
  settings.pressureHist = h;
  cache = null;
}

export function resetLearnedPressure() { settings.pressureHist = null; cache = null; }

/**
 * Presión lista para dibujar (0–1): tu rango real repartido entre fino y gordo, con la sensibilidad de cada lápiz.
 * Con sensibilidad 0 el lápiz no cambia de grosor.
 */
export function penPressure(raw, tool) {
  const cal = settings.pressureCal, auto = cal ? null : autoRange();
  let n;
  if (cal) n = (raw - cal.min) / Math.max(0.05, cal.max - cal.min);
  // Automático: tu presión de siempre queda en la franja media (0,3–0,7), así el temblor normal de la mano no
  // cambia mucho el grosor; rozar baja de ahí y apretar más de lo normal sube hasta el máximo.
  else if (auto) {
    // Por arriba se mira cuánto margen queda hasta 1: si el lápiz ya va casi al máximo (muchas Samsung),
    // apretar del todo tiene que llegar igualmente al trazo gordo.
    const up = Math.max(0.04, Math.min(auto.half * 2.25, 1 - auto.med));
    n = raw < auto.med ? 0.5 - (0.2 * (auto.med - raw)) / auto.half : 0.5 + (0.45 * (raw - auto.med)) / up;
  }
  else n = raw;
  n = Math.min(1, Math.max(0, n));
  const sens = (settings.tools[tool]?.sens ?? 60) / 60;   // 0 = sin presión, 60 = normal, 100 = muy sensible
  return Math.min(1, Math.max(0.03, 0.5 + (n - 0.5) * sens));
}
