// Estado del tablero abierto. Los elementos son objetos inmutables: cada cambio crea un objeto nuevo,
// así el historial (deshacer/rehacer) solo guarda referencias y el renderizador sabe qué ha cambiado.
import { uid } from './util.js';
import { endPoint } from './geom.js';

const MAX_HISTORY = 200;

class Store {
  constructor() {
    this.meta = null;
    this.items = [];
    this.scenes = [];
    this.bg = 'dots';
    this.kind = 'board';  // 'board' (lienzo infinito) | 'notebook' (cuaderno con páginas)
    this.paper = null;    // cuaderno: { orient, color, tpl }
    this.pages = null;    // cuaderno: [{ id, tpl }]
    this.view = { x: 0, y: 0, z: 1 };
    this.past = [];
    this.future = [];
    this.listeners = new Set();
  }

  load(meta, content) {
    this.meta = meta;
    this.items = content?.items || [];
    this.scenes = content?.scenes || [];
    this.bg = content?.bg || 'dots';
    this.kind = content?.kind || 'board';
    this.paper = content?.paper || null;
    this.pages = content?.pages || null;
    this.hw = content?.hw || {};   // texto leído de lo escrito a mano (para buscar)
    this.view = meta?.view || content?.view || null;   // la ficha tiene la última posición (se guarda sola al moverte)
    this.past = [];
    this.future = [];
    this.emit({ reset: true });
  }

  on(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); }
  emit(info = {}) { for (const fn of this.listeners) fn(info); }

  get(id) { return this.items.find((i) => i.id === id); }
  index(id) { return this.items.findIndex((i) => i.id === id); }

  snapshot() { return { items: this.items, scenes: this.scenes, bg: this.bg, pages: this.pages, paper: this.paper }; }

  /** Cambia los elementos sin tocar el historial (p. ej. durante un arrastre). */
  set(items, info = {}) { this.items = items; this.emit(info); }

  /** Registra en el historial el estado anterior a un cambio ya aplicado. */
  record(prev) {
    if (prev.items === this.items && prev.scenes === this.scenes && prev.bg === this.bg && prev.pages === this.pages && prev.paper === this.paper) return;
    this.past.push(prev);
    if (this.past.length > MAX_HISTORY) this.past.shift();
    this.future = [];
    this.emit({ history: true });
  }

  /** Aplica un cambio y lo deja en el historial. fn(items) -> nuevos items */
  mutate(fn, info = {}) {
    const prev = this.snapshot();
    const next = fn(this.items);
    if (next && next !== this.items) { this.items = next; this.emit(info); }
    this.record(prev);
  }

  add(newItems, info) {
    const arr = Array.isArray(newItems) ? newItems : [newItems];
    this.mutate((items) => [...items, ...arr], info);
    return arr;
  }

  update(ids, patch, { record = true } = {}) {
    const set = new Set(Array.isArray(ids) ? ids : [ids]);
    const fn = (items) => items.map((it) => (set.has(it.id) ? { ...it, ...(typeof patch === 'function' ? patch(it) : patch) } : it));
    if (record) this.mutate(fn); else this.set(fn(this.items));
  }

  remove(ids) {
    const set = new Set(ids);
    // Conectores que pierden un extremo: se quedan sueltos en su posición actual.
    this.mutate((items) => {
      const map = new Map(items.map((i) => [i.id, i]));
      return items.filter((i) => !set.has(i.id)).map((it) => {
        if (it.type !== 'line') return it;
        let n = it;
        for (const end of ['a', 'b']) {
          const e = it[end];
          if (e?.id && set.has(e.id)) { const p = endPoint(it, end, map); n = { ...n, [end]: { x: p.x, y: p.y } }; }
        }
        return n;
      });
    });
  }

  reorder(ids, where) {
    const set = new Set(ids);
    this.mutate((items) => {
      const moving = items.filter((i) => set.has(i.id));
      const rest = items.filter((i) => !set.has(i.id));
      if (where === 'front') return [...rest, ...moving];
      if (where === 'back') return [...moving, ...rest];
      const arr = [...items];
      if (where === 'forward') {
        for (let i = arr.length - 2; i >= 0; i--) if (set.has(arr[i].id) && !set.has(arr[i + 1].id)) [arr[i], arr[i + 1]] = [arr[i + 1], arr[i]];
      } else {
        for (let i = 1; i < arr.length; i++) if (set.has(arr[i].id) && !set.has(arr[i - 1].id)) [arr[i], arr[i - 1]] = [arr[i - 1], arr[i]];
      }
      return arr;
    });
  }

  setScenes(scenes) { const prev = this.snapshot(); this.scenes = scenes; this.record(prev); this.emit({ scenes: true }); }
  /** Cambia las páginas del cuaderno (y a la vez los elementos, p. ej. al borrar o mover una página) en un solo paso. */
  setPages(pages, items = this.items, paper = this.paper) {
    const prev = this.snapshot();
    this.pages = pages; this.items = items; this.paper = paper;
    this.emit({ pages: true });
    this.record(prev);
  }

  setBg(bg) { const prev = this.snapshot(); this.bg = bg; this.record(prev); this.emit({ bg: true }); }

  canUndo() { return this.past.length > 0; }
  canRedo() { return this.future.length > 0; }
  undo() { this.travel(this.past, this.future); }
  redo() { this.travel(this.future, this.past); }
  travel(from, to) {
    const s = from.pop();
    if (!s) return;
    to.push(this.snapshot());
    this.items = s.items; this.scenes = s.scenes; this.bg = s.bg;
    if (s.pages !== undefined) { this.pages = s.pages; this.paper = s.paper; }
    this.emit({ history: true, travel: true, bg: true, scenes: true, pages: true });
  }

  content() { return { items: this.items, scenes: this.scenes, bg: this.bg, view: this.view, kind: this.kind, paper: this.paper, pages: this.pages, hw: this.hw }; }
}

export const store = new Store();

/** Copia profunda de elementos con ids nuevos (duplicar/pegar), manteniendo conectores entre ellos. */
export function cloneItems(items, dx = 0, dy = 0, map = new Map(store.items.map((i) => [i.id, i]))) {
  const ids = new Map(items.map((i) => [i.id, uid()]));
  const groups = new Map();
  return items.map((it) => {
    const c = structuredClone(it);
    c.id = ids.get(it.id);
    if (c.group) { if (!groups.has(c.group)) groups.set(c.group, uid()); c.group = groups.get(c.group); }
    if (c.type === 'line') {
      for (const end of ['a', 'b']) {
        const e = c[end];
        if (e?.id && ids.has(e.id)) c[end] = { ...e, id: ids.get(e.id) };
        else if (e?.id) { const p = endPoint(it, end, map); c[end] = { x: p.x + dx, y: p.y + dy }; }
        else c[end] = { x: e.x + dx, y: e.y + dy };
      }
    } else { c.x += dx; c.y += dy; }
    c.locked = false;
    return c;
  });
}
