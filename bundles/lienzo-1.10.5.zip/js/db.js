// Almacenamiento local con IndexedDB: metadatos de tableros, contenido y archivos (blobs).
import { uid } from './util.js';

const DB_NAME = 'lienzo';
let dbp;

function open() {
  if (dbp) return dbp;
  dbp = new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      db.createObjectStore('meta', { keyPath: 'id' });
      db.createObjectStore('content', { keyPath: 'id' });
      db.createObjectStore('blobs', { keyPath: 'id' });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
  return dbp;
}

async function tx(store, mode, fn) {
  const db = await open();
  return new Promise((resolve, reject) => {
    const t = db.transaction(store, mode);
    let result;
    const stores = Array.isArray(store) ? store.map((s) => t.objectStore(s)) : t.objectStore(store);
    Promise.resolve(fn(stores)).then((r) => { result = r; });
    t.oncomplete = () => resolve(result);
    t.onerror = () => reject(t.error);
    t.onabort = () => reject(t.error);
  });
}

const reqP = (r) => new Promise((res, rej) => { r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });

const LIB_ID = '__biblioteca__';
export async function listMeta() { return (await tx('meta', 'readonly', (s) => reqP(s.getAll()))).filter((m) => m.id !== LIB_ID); }

/** Carpetas y etiquetas (un registro especial dentro del almacén de metadatos). */
export async function getLibrary() {
  const r = await tx('meta', 'readonly', (s) => reqP(s.get(LIB_ID)));
  return { folders: r?.folders || [], tags: r?.tags || [] };
}
export async function putLibrary(lib) { return tx('meta', 'readwrite', (s) => { s.put({ id: LIB_ID, folders: lib.folders, tags: lib.tags }); }); }
export async function getMeta(id) { return tx('meta', 'readonly', (s) => reqP(s.get(id))); }
export async function putMeta(meta) { return tx('meta', 'readwrite', (s) => { s.put(meta); }); }
export async function getContent(id) { return tx('content', 'readonly', (s) => reqP(s.get(id))); }

export async function saveBoard(meta, content) {
  return tx(['meta', 'content'], 'readwrite', ([m, c]) => { m.put(meta); c.put({ id: meta.id, ...content }); });
}

export async function deleteBoard(id) {
  const content = await getContent(id);
  await tx(['meta', 'content'], 'readwrite', ([m, c]) => { m.delete(id); c.delete(id); });
  await gcBlobs(content);
}

// Archivos -----------------------------------------------------------------
const urlCache = new Map();

export async function putBlob(blob, id = uid()) {
  await tx('blobs', 'readwrite', (s) => { s.put({ id, blob, type: blob.type }); });
  return id;
}
export async function getBlob(id) {
  const r = await tx('blobs', 'readonly', (s) => reqP(s.get(id)));
  return r?.blob || null;
}
/** URL de objeto en caché para mostrar un archivo guardado. */
export async function blobURL(id) {
  if (urlCache.has(id)) return urlCache.get(id);
  const b = await getBlob(id);
  if (!b) return null;
  const u = URL.createObjectURL(b);
  urlCache.set(id, u);
  return u;
}
export const cachedURL = (id) => urlCache.get(id) || null;

/** Al cambiar de tablero se sueltan las fotos y archivos del anterior (si no, la memoria crece con cada tablero abierto). */
export function releaseBlobURLs(keep) {
  for (const [id, u] of urlCache) if (!keep.has(id)) { URL.revokeObjectURL(u); urlCache.delete(id); }
}

/** Borra archivos que ya no usa ningún tablero (tras eliminar uno definitivamente). */
async function gcBlobs(removedContent) {
  if (!removedContent) return;
  const ids = new Set(blobIdsOf(removedContent.items || []));
  if (!ids.size) return;
  // Se recorren los tableros de uno en uno (no todos a la vez en memoria: con muchos tableros grandes podría cerrar la app).
  await tx('content', 'readonly', (s) => new Promise((done) => {
    const req = s.openCursor();
    req.onsuccess = () => {
      const c = req.result;
      if (!c || !ids.size) { done(); return; }
      for (const b of blobIdsOf(c.value.items || [])) ids.delete(b);
      c.continue();
    };
    req.onerror = () => { ids.clear(); done(); };   // ante la duda, no se borra nada
  }));
  await tx('blobs', 'readwrite', (s) => { for (const id of ids) s.delete(id); });
}

export function blobIdsOf(items) {
  const out = [];
  for (const it of items) { if (it.blob) out.push(it.blob); if (it.preview) out.push(it.preview); }
  return out;
}

export async function requestPersistence() {
  try { if (navigator.storage?.persist && !(await navigator.storage.persisted())) await navigator.storage.persist(); } catch { /* opcional */ }
}
