// Conexión con Studio, la app del PC: sincroniza los tableros y, en la tablet, deja hablar con Claude a través del PC.
// En Studio (escritorio) window.studio ya existe; en la tablet se crea aquí otro igual que habla con el PC por la red.
import * as sync from './sync.js';
import { h, icon, uid } from './util.js';
import { popover, toast, closeAllPopovers } from './ui.js';
import { isNative } from './native.js';

const CONN_KEY = 'studio.conexion';
const conn = () => { try { return JSON.parse(localStorage.getItem(CONN_KEY) || 'null'); } catch { return null; } };

/** Petición HTTP al PC. En la app Android va por el sistema (CapacitorHttp): así se puede hablar con el PC por http. */
function transport(base, token) {
  const Http = window.Capacitor?.Plugins?.CapacitorHttp;
  return {
    async req(method, path, body, timeout = 15000) {
      const headers = { 'x-studio': token, 'content-type': 'application/json' };
      if (isNative && Http) {
        const r = await Http.request({ url: base + path, method, headers, data: body ?? undefined, connectTimeout: 5000, readTimeout: timeout, responseType: 'json' });
        return { status: r.status, data: typeof r.data === 'string' && r.data ? JSON.parse(r.data) : r.data };
      }
      const ctl = new AbortController();
      const t = setTimeout(() => ctl.abort(), timeout);
      try {
        const r = await fetch(base + path, { method, headers, body: body == null ? undefined : JSON.stringify(body), signal: ctl.signal });
        return { status: r.status, data: await r.json().catch(() => null) };
      } finally { clearTimeout(t); }
    },
  };
}

/** window.studio por la red (tablet): mismos métodos que en el PC. */
function remoteStudio(T) {
  const client = localStorage.getItem('studio.cliente') || (() => { const c = `tablet-${uid()}`; localStorage.setItem('studio.cliente', c); return c; })();
  const q = (p) => `/api/claude/${p}?cliente=${client}`;
  let onEvent = () => {}, onCall = async () => ({});
  // Escucha continua: eventos del chat y herramientas que Claude quiere usar en esta pizarra.
  (async function poll() {
    let wait = 4000;
    for (;;) {
      if (document.visibilityState !== 'visible') { await new Promise((res) => setTimeout(res, 3000)); continue; }   // app en segundo plano: en pausa
      try {
        const r = await T.req('GET', q('eventos'), null, 30000);
        if (r.status === 200) {
          for (const ev of r.data || []) {
            if (ev.kind === 'board') onCall(ev.name, ev.args).catch((e) => ({ error: String(e?.message || e) })).then((result) => T.req('POST', q('resultado'), { id: ev.id, result }, 60000));
            else onEvent(ev);
          }
          wait = 4000;
          continue;
        }
      } catch { /* el PC no responde: se reintenta */ }
      await new Promise((res) => setTimeout(res, wait));
      wait = Math.min(60000, wait * 2);
    }
  })();
  return {
    remote: true,
    send: async (key, text) => {
      try { await T.req('POST', q('enviar'), { key, text }); } catch { onEvent({ key, type: 'done', ok: false, error: 'No encuentro Studio en el PC. ¿Está encendido y abierto?' }); }
    },
    stop: () => T.req('POST', q('parar'), {}).catch(() => {}),
    forget: (key) => T.req('POST', q('olvidar'), { key }).catch(() => {}),
    alias: (from, to) => T.req('POST', q('alias'), { from, to }).catch(() => {}),
    auth: async () => { try { return (await T.req('GET', q('cuenta'))).data || { loggedIn: false }; } catch { return { loggedIn: true }; } },
    login: () => toast('Inicia sesión desde Studio, en el PC'),
    warm: () => T.req('POST', q('calentar'), {}).catch(() => {}),
    dictate: async (data, type) => { try { return (await T.req('POST', q('voz'), { data, type }, 120000)).data || { error: 'Sin respuesta del PC' }; } catch { return { error: 'No encuentro el PC' }; } },
    onEvent: (fn) => { onEvent = fn; },
    onBoardCall: (fn) => { onCall = async (n, a) => fn(n, a); },
  };
}

let currentT = null;
/** Trae un archivo del PC (para colocar en el tablero lo que Claude ha creado allí). */
export async function fetchBlob(id) {
  if (!currentT) return null;
  try {
    const r = await currentT.req('GET', `/api/archivo/${id}`, null, 120000);
    if (r.status !== 200) return null;
    const bin = atob(r.data.data), arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    return new Blob([arr], { type: r.data.type || '' });
  } catch { return null; }
}

/** Arranca la conexión si la hay. Devuelve true si hay Claude disponible (PC o tablet conectada). */
export async function setupStudio() {
  if (window.studio) {
    const cfg = await window.studio.config();
    currentT = transport(cfg.server, cfg.token);
    sync.start(currentT, 3000, true);
    return true;
  }
  const c = conn();
  if (!c) return false;
  const T = transport(`http://${c.host}`, c.codigo);
  currentT = T;
  sync.start(T, 4000);
  window.studio = remoteStudio(T);
  // ¿Responde el PC? (lo usan los botones de Claude para elegir entre el chat y la app de Claude)
  window.__studioOnline = true;
  // Si el router le cambia la dirección al PC, la tablet lo busca sola en el wifi y se reconecta con el mismo código.
  let misses = 0, searching = false, lastSearch = 0;
  sync.onStatus(async (st) => {
    window.__studioOnline = st.ok;
    misses = st.ok ? 0 : misses + 1;
    if (st.ok || misses < 3 || searching || Date.now() - lastSearch < 120000 || /código/i.test(st.error)) return;
    searching = true; lastSearch = Date.now();
    try {
      const found = await findPC();
      if (found && found !== c.host) {
        const r = await transport(`http://${found}`, c.codigo).req('GET', '/api/tableros', null, 5000).catch(() => null);
        if (r?.status === 200) { localStorage.setItem(CONN_KEY, JSON.stringify({ host: found, codigo: c.codigo })); toast('He encontrado el PC en otra dirección: reconectando…'); setTimeout(() => location.reload(), 1200); }
      }
    } finally { searching = false; }
  });
  return true;
}

// Pantallas ---------------------------------------------------------------------------------------
const ago = (t) => { const s = Math.round((Date.now() - t) / 1000); return s < 10 ? 'ahora mismo' : s < 60 ? `hace ${s} s` : `hace ${Math.round(s / 60)} min`; };
const statusText = () => (sync.status.ok ? `Sincronizado ${ago(sync.status.last)}` : sync.status.error ? `Sin conexión: ${sync.status.error}` : 'Conectando…');

/** En el PC: cómo conectar la tablet (dirección y código). */
export async function pairPanel(anchor) {
  const cfg = await window.studio.config();
  const st = h('p.pop-note', { text: statusText() });
  popover(anchor, h('div.pop-pad.settings', {},
    h('div.pop-title', { text: 'Conectar la tablet' }),
    h('p.pop-note', { html: 'En la tablet, abre Pizarra › Ajustes › <b>Conectar con el PC</b> y escribe:' }),
    h('div.pair-row', {}, h('span', { text: 'Dirección' }), h('b', { text: cfg.direcciones.map((d) => `${d}:${cfg.puerto}`).join('  ·  ') || 'sin red' })),
    h('div.pair-row', {}, h('span', { text: 'Código' }), h('b.pair-code', { text: cfg.token })),
    h('p.pop-note', { text: 'La tablet y el PC tienen que estar en el mismo wifi. La primera vez, Windows puede preguntar si deja a Studio usar la red: elige «Redes privadas» y Permitir.' }),
    st), { className: 'settings-pop' });
  sync.onStatus(() => { st.textContent = statusText(); });
}

/** ¿Hay un Studio en esta dirección? (respuesta rápida, para buscar el PC en el wifi) */
async function probe(host) {
  const Http = window.Capacitor?.Plugins?.CapacitorHttp;
  try {
    if (isNative && Http) {
      const r = await Http.request({ url: `http://${host}/api/hola`, method: 'GET', connectTimeout: 900, readTimeout: 900, responseType: 'json' });
      const d = typeof r.data === 'string' ? JSON.parse(r.data || '{}') : r.data;
      return r.status === 200 && d?.app === 'Studio';
    }
    const ctl = new AbortController(); const t = setTimeout(() => ctl.abort(), 900);
    const r = await fetch(`http://${host}/api/hola`, { signal: ctl.signal }).finally(() => clearTimeout(t));
    return r.ok && (await r.json()).app === 'Studio';
  } catch { return false; }
}

/** Busca Studio en las redes de casa más habituales (192.168.1.x, 192.168.0.x…), de 48 en 48. */
async function findPC(onProgress) {
  const nets = ['192.168.1', '192.168.0', '192.168.100', '192.168.18', '10.0.0', '192.168.2'];
  for (const net of nets) {
    onProgress?.(net);
    const hosts = Array.from({ length: 254 }, (_, i) => `${net}.${i + 1}:5181`);
    for (let i = 0; i < hosts.length; i += 48) {
      const batch = hosts.slice(i, i + 48);
      const ok = await Promise.all(batch.map(probe));
      const k = ok.indexOf(true);
      if (k >= 0) return batch[k];
    }
  }
  return null;
}

/**
 * En la tablet: dirección del PC y código. Es una ventana fija arriba (el teclado no la tapa) que no se cierra al
 * tocar fuera ni al bajar el teclado con «atrás»: solo con Conectar o Cancelar.
 */
export function connectDialog() {
  document.querySelector('.connect-sheet')?.remove();
  closeAllPopovers();
  const c = conn() || {};
  const host = h('input.field', { placeholder: 'Dirección del PC (p. ej. 192.168.1.20)', value: c.host || '', inputmode: 'url', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false' });
  const code = h('input.field.code', { placeholder: 'Código de 6 cifras', value: c.codigo || '', inputmode: 'numeric', autocomplete: 'off', maxlength: 6 });
  const msg = h('p.pop-note', { text: c.host ? statusText() : 'Abre Studio en el PC: botón ✦ › icono de capas. Ahí ves la dirección y el código.' });
  let busy = false;
  const close = () => { sheet.remove(); };
  const find = h('button.btn.full', { html: `${icon('search', 18)} Buscar mi PC en el wifi`, onclick: async () => {
    if (busy) return; busy = true;
    find.disabled = true;
    const hit = await findPC((net) => { msg.textContent = `Buscando en ${net}.x…`; });
    find.disabled = false; busy = false;
    if (hit) { host.value = hit; msg.textContent = 'PC encontrado. Escribe el código y toca Conectar.'; code.focus(); }
    else msg.textContent = 'No lo encuentro. Comprueba que Studio esté abierto y que estéis en el mismo wifi, o escribe la dirección.';
  } });
  const save = h('button.btn.primary.full', { text: 'Conectar', onclick: async () => {
    const hv = host.value.trim().replace(/^https?:\/\//, '').replace(/\/$/, ''), cv = code.value.trim();
    if (!hv) { msg.textContent = 'Falta la dirección del PC (o toca «Buscar mi PC»).'; return; }
    if (!/^\d{6}$/.test(cv)) { msg.textContent = 'El código son 6 cifras.'; code.focus(); return; }
    document.activeElement?.blur();
    const full = /:\d+$/.test(hv) ? hv : `${hv}:5181`;
    msg.textContent = 'Probando…';
    try {
      const r = await transport(`http://${full}`, cv).req('GET', '/api/tableros', null, 6000);
      if (r.status === 401) { msg.textContent = 'El código no es correcto.'; return; }
      if (r.status !== 200) throw new Error(`HTTP ${r.status}`);
    } catch { msg.textContent = 'No encuentro el PC. Comprueba la dirección, que Studio esté abierto y que estéis en el mismo wifi.'; return; }
    if (c.host !== full || c.codigo !== cv) sync.resetState();
    localStorage.setItem(CONN_KEY, JSON.stringify({ host: full, codigo: cv }));
    close();
    toast('Conectada con el PC. Reiniciando…');
    setTimeout(() => location.reload(), 900);
  } });
  const off = c.host ? h('button.btn.full', { text: 'Desconectar', onclick: () => { localStorage.removeItem(CONN_KEY); sync.stop(); close(); toast('Desconectada del PC'); setTimeout(() => location.reload(), 900); } }) : null;
  const sheet = h('div.viewer.connect-sheet', {},
    h('div.connect-card', {},
      h('div.connect-head', {}, h('b', { text: 'Conectar con el PC (Studio)' }), h('button.btn', { text: 'Cancelar', onclick: close })),
      find, host, code, save, off, msg));
  // «Atrás» de Android: si el teclado está abierto solo lo baja; si no, cierra.
  sheet.addEventListener('back', () => { if (sheet.contains(document.activeElement) && document.activeElement.tagName === 'INPUT') document.activeElement.blur(); else close(); });
  document.getElementById('overlay').append(sheet);
}

export const pairIcon = () => icon('layers-2', 19);
