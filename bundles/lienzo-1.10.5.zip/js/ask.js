// Preguntar a Claude sin el PC: manda una imagen del tablero (o de lo seleccionado) y tu pregunta a la app de Claude
// de la tablet. Usa tu suscripción, sin coste extra. La respuesta la copias en Claude y la pegas aquí.
import { h, icon } from './util.js';
import { popover, toast, closeAllPopovers, segmented } from './ui.js';
import { store } from './store.js';
import { exportPNG } from './export.js';
import { shareBlob } from './native.js';
import * as G from './geom.js';

const app = () => window.lienzo;
const IDEAS = ['Resúmeme esto', 'Hazme un mapa mental con estas ideas', 'Explícame lo que he escrito', 'Ordena estas notas en una lista', 'Dame ideas para seguir'];

const fab = h('button.cl-fab', { title: 'Preguntar a Claude', html: icon('sparkles', 24), onclick: () => open() });
fab.hidden = true;
document.body.append(fab);
// Solo dentro de un tablero.
setInterval(() => {
  const pcOk = window.studio?.remote && window.__studioOnline;   // con el PC disponible manda el chat completo
  fab.hidden = pcOk || app().current !== 'board' || document.body.classList.contains('presenting');
}, 700);

let what = 'auto';
window.__askOpen = (anchor) => open(anchor);
if (!window.__claudeOpen) window.__claudeOpen = (anchor) => open(anchor);
document.querySelectorAll('.pk-claude').forEach((b) => { b.hidden = false; });

function open(anchor = fab) {
  const b = app().board;
  const hasSel = b.sel.size > 0;
  const q = h('textarea.ask-input', { rows: 3, placeholder: '¿Qué le pido a Claude?' });
  const chips = h('div.ask-chips', {}, ...IDEAS.map((t) => h('button.ask-chip', { text: t, onclick: () => { q.value = t; q.focus(); } })));
  const seg = segmented([{ value: 'auto', label: hasSel ? 'Lo seleccionado' : 'Lo que se ve' }, { value: 'todo', label: 'Todo el tablero' }], what, (v) => { what = v; });
  const go = h('button.btn.primary.full', { html: `${icon('sparkles', 18)} Abrir en Claude`, onclick: async () => {
    const text = q.value.trim();
    if (!text) { q.focus(); return; }
    go.disabled = true;
    try {
      const png = await image(what);
      if (!png) { toast('El tablero está vacío'); return; }
      const msg = `${text}\n\n(Te paso una imagen de mi pizarra: ${store.meta.title}.)`;
      try { await navigator.clipboard?.writeText(msg); } catch { /* no pasa nada */ }
      closeAllPopovers();
      await shareBlob(`${store.meta.title || 'Pizarra'}.png`, png, 'Preguntar a Claude', msg);
    } catch (err) {
      toast('No se pudo preparar la imagen');
      console.warn('preguntar', err);
    } finally { go.disabled = false; }
  } });
  popover(anchor && document.body.contains(anchor) && anchor.offsetParent ? anchor : fab, h('div.pop-pad.settings.ask', {},
    h('div.pop-title', { html: `${icon('sparkles', 17)} Preguntar a Claude` }),
    q, chips, seg, go,
    h('p.pop-note', { html: 'Se abrirá la app de Claude con una imagen de tu pizarra y tu pregunta (elige <b>Claude</b> en la lista). Para traer su respuesta, cópiala en Claude y pégala aquí: mantén pulsado el lienzo › <b>Pegar</b>.' })), { className: 'settings-pop' });
  setTimeout(() => q.focus(), 50);
}

/** Imagen de lo seleccionado, de lo que se ve o de todo el tablero. */
function image(kind) {
  const b = app().board;
  if (kind === 'todo') return exportPNG(store.items);
  if (b.sel.size) return exportPNG(store.items, G.unionBox(b.selItems().map((i) => G.aabb(i, b.map))));
  return exportPNG(store.items, b.vp.visibleBox());
}
