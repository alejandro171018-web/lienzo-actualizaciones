// PDF vectorial: un "canvas" que en vez de pintar píxeles escribe instrucciones de PDF. Los trazos, formas, flechas
// y textos salen como vectores y letras de verdad (nítidos a cualquier zoom); las fotos van a su resolución original.
// Se usa con el mismo código de dibujo de export.js (drawItem), que solo necesita la parte del canvas que hay aquí.

const f = (n) => { if (!Number.isFinite(n) || Math.abs(n) < 1e-6) return '0'; return String(Math.round(n * 1000) / 1000); };
const enc = new TextEncoder();
const bytes = (x) => (typeof x === 'string' ? enc.encode(x) : x);

async function deflate(data) {
  const s = new Blob([data]).stream().pipeThrough(new CompressionStream('deflate'));
  return new Uint8Array(await new Response(s).arrayBuffer());
}

// Colores ----------------------------------------------------------------------------------------
const NAMED = { white: '#FFFFFF', black: '#000000', transparent: 'rgba(0,0,0,0)' };
function parseColor(c) {
  c = NAMED[c] || String(c || '#000').trim();
  let m;
  if ((m = /^#([0-9a-f]{3,8})$/i.exec(c))) {
    let x = m[1];
    if (x.length <= 4) x = [...x].map((ch) => ch + ch).join('');
    const n = (i) => parseInt(x.slice(i, i + 2), 16) / 255;
    return { r: n(0), g: n(2), b: n(4), a: x.length === 8 ? n(6) : 1 };
  }
  if ((m = /^rgba?\(([^)]+)\)$/i.exec(c))) {
    const p = m[1].split(/[\s,/]+/).filter(Boolean).map(parseFloat);
    return { r: p[0] / 255, g: p[1] / 255, b: p[2] / 255, a: p[3] ?? 1 };
  }
  return { r: 0, g: 0, b: 0, a: 1 };
}

// Texto: Windows-1252 (cubre el español: tildes, ñ, ¿, ¡, comillas, €, rayas…) -----------------------
const CP1252 = { 0x20AC: 0x80, 0x201A: 0x82, 0x0192: 0x83, 0x201E: 0x84, 0x2026: 0x85, 0x2020: 0x86, 0x2021: 0x87, 0x02C6: 0x88, 0x2030: 0x89, 0x0160: 0x8A, 0x2039: 0x8B, 0x0152: 0x8C, 0x017D: 0x8E, 0x2018: 0x91, 0x2019: 0x92, 0x201C: 0x93, 0x201D: 0x94, 0x2022: 0x95, 0x2013: 0x96, 0x2014: 0x97, 0x02DC: 0x98, 0x2122: 0x99, 0x0161: 0x9A, 0x203A: 0x9B, 0x0153: 0x9C, 0x017E: 0x9E, 0x0178: 0x9F };
const toCode = (ch) => { const u = ch.codePointAt(0); if ((u >= 0x20 && u <= 0x7E) || (u >= 0xA0 && u <= 0xFF)) return u; return CP1252[u] ?? null; };
const WIN_CHARS = (() => { const a = []; for (let c = 32; c <= 255; c++) { const ch = c >= 0x80 && c <= 0x9F ? Object.keys(CP1252).find((k) => CP1252[k] === c) : null; a.push(ch ? String.fromCodePoint(+ch) : c >= 0x80 && c <= 0x9F ? null : String.fromCharCode(c)); } return a; })();
const pdfString = (codes) => `(${codes.map((c) => (c === 0x28 || c === 0x29 || c === 0x5C ? `\\${String.fromCharCode(c)}` : c < 32 || c > 126 ? `\\${c.toString(8).padStart(3, '0')}` : String.fromCharCode(c))).join('')})`;

// Tipografías de la app -> archivo .ttf (scripts/pdffonts.mjs) o fuente estándar de PDF.
const FAMILY = [
  [/inter|system-ui|sans-serif/i, 'inter', true], [/caveat|comic/i, 'caveat', true], [/patrick hand/i, 'patrick-hand', false],
  [/kalam/i, 'kalam', true], [/dancing script/i, 'dancing-script', true], [/indie flower/i, 'indie-flower', false],
  [/shadows into light/i, 'shadows-into-light', false],
];
function fontKey(css) {
  const m = /^(italic\s+)?(?:(\d{3}|bold|normal)\s+)?([\d.]+)px\s+(.+)$/i.exec(css.trim()) || [];
  const italic = !!m[1], weight = m[2] === 'bold' ? 700 : Number(m[2]) || 400, size = Number(m[3]) || 16, family = m[4] || 'Inter';
  const first = family.split(',')[0].replace(/["']/g, '').trim();
  if (/emoji/i.test(family)) return { emoji: true, size, family };
  if (/serif/i.test(first) && !/sans/i.test(first) || /georgia|times/i.test(first)) return { std: weight >= 600 ? (italic ? 'Times-BoldItalic' : 'Times-Bold') : (italic ? 'Times-Italic' : 'Times-Roman'), size, family };
  if (/mono/i.test(family)) return { std: weight >= 600 ? 'Courier-Bold' : 'Courier', size, family };
  for (const [re, key, hasBold] of FAMILY) if (re.test(first) || re.test(family)) return { key: `${key}-${hasBold && weight >= 600 ? 700 : 400}`, italic, size, family, weight };
  return { key: weight >= 600 ? 'inter-700' : 'inter-400', italic, size, family, weight };
}

// Caminos de Path2D: mientras se genera el PDF, Path2D también apunta lo que se le pide, para poder pasarlo a PDF.
const RealPath2D = window.Path2D;
class RecPath extends RealPath2D {
  constructor(d) { super(d); this.rec = d instanceof RecPath ? [...d.rec] : typeof d === 'string' ? [{ d, m: null }] : []; }
  addPath(p, m) { super.addPath(p, m); for (const r of p.rec || []) this.rec.push({ d: r.d, m: m ? mul(m, r.m) : r.m }); }
}
const mul = (A, B) => (B ? { a: A.a * B.a + A.c * B.b, b: A.b * B.a + A.d * B.b, c: A.a * B.c + A.c * B.d, d: A.b * B.c + A.d * B.d, e: A.a * B.e + A.c * B.f + A.e, f: A.b * B.e + A.d * B.f + A.f } : { a: A.a, b: A.b, c: A.c, d: A.d, e: A.e, f: A.f });

/** Ejecuta fn con Path2D grabando (lo que se dibuje en un canvas normal mientras tanto sigue funcionando igual). */
export async function withRecordedPaths(fn) {
  window.Path2D = RecPath;
  try { return await fn(); } finally { window.Path2D = RealPath2D; }
}

/** Camino SVG -> operadores de PDF (m, l, c, h). Admite todas las órdenes de SVG, absolutas y relativas. */
function svgToPdf(d, m, out) {
  const tok = String(d).match(/[a-zA-Z]|-?(?:\d+\.?\d*|\.\d+)(?:e[-+]?\d+)?/g) || [];
  let i = 0, cmd = '', x = 0, y = 0, sx = 0, sy = 0, cx = 0, cy = 0, qx = 0, qy = 0, prev = '';
  const T = m ? (px, py) => [m.a * px + m.c * py + m.e, m.b * px + m.d * py + m.f] : (px, py) => [px, py];
  const P = (px, py) => T(px, py).map(f).join(' ');
  const num = () => parseFloat(tok[i++]);
  const curve = (x1, y1, x2, y2, x3, y3) => out.push(`${P(x1, y1)} ${P(x2, y2)} ${P(x3, y3)} c`);
  while (i < tok.length) {
    if (/[a-zA-Z]/.test(tok[i])) cmd = tok[i++];
    const rel = cmd === cmd.toLowerCase(), C = cmd.toUpperCase();
    const ox = rel ? x : 0, oy = rel ? y : 0;
    if (C === 'Z') { out.push('h'); x = sx; y = sy; prev = 'Z'; continue; }
    if (i >= tok.length || /[a-zA-Z]/.test(tok[i])) continue;   // orden sin números: se pasa a la siguiente
    if (C === 'M') { x = ox + num(); y = oy + num(); sx = x; sy = y; out.push(`${P(x, y)} m`); cmd = rel ? 'l' : 'L'; }
    else if (C === 'L') { x = ox + num(); y = oy + num(); out.push(`${P(x, y)} l`); }
    else if (C === 'H') { x = ox + num(); out.push(`${P(x, y)} l`); }
    else if (C === 'V') { y = oy + num(); out.push(`${P(x, y)} l`); }
    else if (C === 'C') { const a = [ox + num(), oy + num(), ox + num(), oy + num(), ox + num(), oy + num()]; curve(...a); cx = a[2]; cy = a[3]; x = a[4]; y = a[5]; }
    else if (C === 'S') { const r1 = /[CS]/.test(prev) ? [2 * x - cx, 2 * y - cy] : [x, y]; const a = [ox + num(), oy + num(), ox + num(), oy + num()]; curve(r1[0], r1[1], a[0], a[1], a[2], a[3]); cx = a[0]; cy = a[1]; x = a[2]; y = a[3]; }
    else if (C === 'Q' || C === 'T') {
      const q = C === 'Q' ? [ox + num(), oy + num()] : /[QT]/.test(prev) ? [2 * x - qx, 2 * y - qy] : [x, y];
      const ex = ox + num(), ey = oy + num();
      curve(x + (2 / 3) * (q[0] - x), y + (2 / 3) * (q[1] - y), ex + (2 / 3) * (q[0] - ex), ey + (2 / 3) * (q[1] - ey), ex, ey);
      qx = q[0]; qy = q[1]; x = ex; y = ey;
    } else if (C === 'A') {
      const rx = num(), ry = num(), rot = num(), large = num(), sweep = num(), ex = ox + num(), ey = oy + num();
      for (const seg of arcToBeziers(x, y, rx, ry, rot, large, sweep, ex, ey)) curve(...seg);
      x = ex; y = ey;
    } else i++;
    prev = C;
  }
}

/** Arco de SVG (forma de extremos) -> curvas de Bézier. */
function arcToBeziers(x1, y1, rx, ry, phiDeg, fa, fs, x2, y2) {
  if (!rx || !ry) return [[x1, y1, x2, y2, x2, y2]];
  rx = Math.abs(rx); ry = Math.abs(ry);
  const phi = (phiDeg * Math.PI) / 180, cos = Math.cos(phi), sin = Math.sin(phi);
  const dx = (x1 - x2) / 2, dy = (y1 - y2) / 2;
  const x1p = cos * dx + sin * dy, y1p = -sin * dx + cos * dy;
  const lam = (x1p * x1p) / (rx * rx) + (y1p * y1p) / (ry * ry);
  if (lam > 1) { rx *= Math.sqrt(lam); ry *= Math.sqrt(lam); }
  const sign = fa === fs ? -1 : 1;
  const num = rx * rx * ry * ry - rx * rx * y1p * y1p - ry * ry * x1p * x1p;
  const co = sign * Math.sqrt(Math.max(0, num / (rx * rx * y1p * y1p + ry * ry * x1p * x1p)));
  const cxp = (co * rx * y1p) / ry, cyp = (-co * ry * x1p) / rx;
  const cx = cos * cxp - sin * cyp + (x1 + x2) / 2, cy = sin * cxp + cos * cyp + (y1 + y2) / 2;
  const ang = (ux, uy, vx, vy) => { const a = Math.atan2(ux * vy - uy * vx, ux * vx + uy * vy); return a; };
  let t1 = ang(1, 0, (x1p - cxp) / rx, (y1p - cyp) / ry);
  let dt = ang((x1p - cxp) / rx, (y1p - cyp) / ry, (-x1p - cxp) / rx, (-y1p - cyp) / ry);
  if (!fs && dt > 0) dt -= 2 * Math.PI; else if (fs && dt < 0) dt += 2 * Math.PI;
  return ellipseBeziers(cx, cy, rx, ry, phi, t1, t1 + dt);
}

function ellipseBeziers(cx, cy, rx, ry, phi, a0, a1) {
  const out = [], n = Math.max(1, Math.ceil(Math.abs(a1 - a0) / (Math.PI / 2))), da = (a1 - a0) / n;
  const k = (4 / 3) * Math.tan(da / 4), cos = Math.cos(phi), sin = Math.sin(phi);
  const pt = (a, dx = 0, dy = 0) => { const ex = rx * Math.cos(a) + dx, ey = ry * Math.sin(a) + dy; return [cx + cos * ex - sin * ey, cy + sin * ex + cos * ey]; };
  for (let s = 0; s < n; s++) {
    const t0 = a0 + s * da, t1 = t0 + da;
    const p1 = pt(t0, -k * rx * Math.sin(t0), k * ry * Math.cos(t0));
    const p2 = pt(t1, k * rx * Math.sin(t1), -k * ry * Math.cos(t1));
    out.push([...p1, ...p2, ...pt(t1)]);
  }
  return out;
}

// Documento --------------------------------------------------------------------------------------
export class PdfDoc {
  constructor() {
    this.objs = [null];          // [id] -> partes (strings o bytes)
    this.pages = [];
    this.fonts = new Map();      // clave -> { name, id }
    this.gstates = new Map();
    this.images = new Map();
    this.scratch = document.createElement('canvas').getContext('2d');
    this.alloc(); this.alloc();  // 1: catálogo, 2: páginas
  }
  alloc() { this.objs.push(null); return this.objs.length - 1; }
  set(id, ...parts) { this.objs[id] = parts; }
  async stream(dict, data, compress = true) {
    const id = this.alloc();
    const raw = bytes(data);
    const body = compress ? await deflate(raw) : raw;
    this.set(id, `<< ${dict}${compress ? ' /Filter /FlateDecode' : ''} /Length ${body.length} >>\nstream\n`, body, '\nendstream');
    return id;
  }

  gstate(ca, CA, bm) {
    const k = `${f(ca)}|${f(CA)}|${bm || ''}`;
    if (!this.gstates.has(k)) { const id = this.alloc(); this.set(id, `<< /Type /ExtGState /ca ${f(ca)} /CA ${f(CA)}${bm ? ` /BM /${bm}` : ''} >>`); this.gstates.set(k, { name: `GS${this.gstates.size}`, id }); }
    return this.gstates.get(k).name;
  }

  /** Tipografía incrustada (o estándar): devuelve su nombre de recurso. */
  font(fk) {
    // Se guarda la promesa: varias letras a la vez con la misma tipografía la incrustan una sola vez.
    const key = fk.std || fk.key;
    if (!this.fontJobs) this.fontJobs = new Map();
    // El nombre se reparte aquí, antes de cargar: si no, dos tipografías cargando a la vez saldrían con el mismo.
    if (!this.fontJobs.has(key)) this.fontJobs.set(key, this.loadFont(fk, key, `F${this.fontJobs.size}`));
    return this.fontJobs.get(key);
  }

  async loadFont(fk, key, name) {
    const id = this.alloc();
    if (fk.std) {
      this.set(id, `<< /Type /Font /Subtype /Type1 /BaseFont /${fk.std} /Encoding /WinAnsiEncoding >>`);
    } else {
      const ttf = new Uint8Array(await (await fetch(`vendor/fonts-pdf/${key}.ttf`)).arrayBuffer());
      const fam = fk.family.split(',')[0].replace(/["']/g, '').trim();
      // Anchos de cada letra medidos con la misma tipografía en el navegador (unidades de 1/1000).
      const weight = key.endsWith('700') ? 700 : 400;
      await document.fonts?.load(`${weight} 100px "${fam}"`).catch(() => {});
      this.scratch.font = `${weight} 1000px "${fam}", sans-serif`;
      const widths = WIN_CHARS.map((ch) => (ch ? Math.round(this.scratch.measureText(ch).width) : 0));
      const file = await this.stream(`/Length1 ${ttf.length}`, ttf);
      const desc = this.alloc();
      const psName = key.replace(/[^A-Za-z0-9]/g, '');
      this.set(desc, `<< /Type /FontDescriptor /FontName /${psName} /Flags 32 /FontBBox [-300 -300 1300 1100] /ItalicAngle 0 /Ascent 950 /Descent -250 /CapHeight 700 /StemV 80 /FontFile2 ${file} 0 R >>`);
      this.set(id, `<< /Type /Font /Subtype /TrueType /BaseFont /${psName} /FirstChar 32 /LastChar 255 /Widths [${widths.join(' ')}] /FontDescriptor ${desc} 0 R /Encoding /WinAnsiEncoding >>`);
    }
    this.fonts.set(key, { name, id });
    return name;
  }

  /** Imagen (de un <img>, <video> o canvas, con recorte): JPEG si es opaca, con transparencia si no. */
  image(src, sx, sy, sw, sh, cacheKey) {
    if (!this.imageJobs) this.imageJobs = new Map();
    if (!cacheKey) return this.loadImage(src, sx, sy, sw, sh);
    if (!this.imageJobs.has(cacheKey)) this.imageJobs.set(cacheKey, this.loadImage(src, sx, sy, sw, sh));
    return this.imageJobs.get(cacheKey);
  }

  async loadImage(src, sx, sy, sw, sh) {
    const k = Math.min(1, 4096 / Math.max(sw, sh));
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(sw * k)); c.height = Math.max(1, Math.round(sh * k));
    const x = c.getContext('2d');
    x.drawImage(src, sx, sy, sw, sh, 0, 0, c.width, c.height);
    const px = x.getImageData(0, 0, c.width, c.height).data;
    let opaque = true;
    for (let i = 3; i < px.length; i += 4) if (px[i] < 255) { opaque = false; break; }
    let id;
    if (opaque) {
      const jpg = new Uint8Array(await (await new Promise((r) => c.toBlob(r, 'image/jpeg', 0.93))).arrayBuffer());
      id = await this.stream(`/Type /XObject /Subtype /Image /Width ${c.width} /Height ${c.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode`, jpg, false);
    } else {
      const n = c.width * c.height, rgb = new Uint8Array(n * 3), a = new Uint8Array(n);
      for (let i = 0; i < n; i++) { rgb[i * 3] = px[i * 4]; rgb[i * 3 + 1] = px[i * 4 + 1]; rgb[i * 3 + 2] = px[i * 4 + 2]; a[i] = px[i * 4 + 3]; }
      const mask = await this.stream(`/Type /XObject /Subtype /Image /Width ${c.width} /Height ${c.height} /ColorSpace /DeviceGray /BitsPerComponent 8`, a);
      id = await this.stream(`/Type /XObject /Subtype /Image /Width ${c.width} /Height ${c.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /SMask ${mask} 0 R`, rgb);
    }
    c.width = c.height = 0;
    const res = { name: `Im${this.imgSeq = (this.imgSeq || 0) + 1}`, id };
    this.images.set(Symbol('img'), res);
    return res;
  }

  /** Página nueva de wPt×hPt puntos. Devuelve un contexto tipo canvas para dibujar en ella. */
  page(wPt, hPt) {
    const ctx = new PdfCtx(this, wPt, hPt);
    this.pages.push(ctx);
    return ctx;
  }

  async build() {
    const kids = [];
    for (const p of this.pages) {
      const content = await this.stream('', p.ops.join('\n'));
      const res = `<< /Font << ${[...this.fonts.values()].map((x) => `/${x.name} ${x.id} 0 R`).join(' ')} >> /XObject << ${[...this.images.values()].map((x) => `/${x.name} ${x.id} 0 R`).join(' ')} >> /ExtGState << ${[...this.gstates.values()].map((x) => `/${x.name} ${x.id} 0 R`).join(' ')} >> >>`;
      const id = this.alloc();
      this.set(id, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${f(p.w)} ${f(p.h)}] /Resources ${res} /Contents ${content} 0 R >>`);
      kids.push(id);
    }
    this.set(1, '<< /Type /Catalog /Pages 2 0 R >>');
    this.set(2, `<< /Type /Pages /Kids [${kids.map((k) => `${k} 0 R`).join(' ')}] /Count ${kids.length} >>`);
    const parts = [bytes('%PDF-1.7\n%\xE2\xE3\xCF\xD3\n')];
    let pos = parts[0].length;
    const offsets = [];
    for (let i = 1; i < this.objs.length; i++) {
      offsets[i] = pos;
      for (const p of [`${i} 0 obj\n`, ...(this.objs[i] || ['null']), '\nendobj\n']) { const b = bytes(p); parts.push(b); pos += b.length; }
    }
    let xref = `xref\n0 ${this.objs.length}\n0000000000 65535 f \n`;
    for (let i = 1; i < this.objs.length; i++) xref += `${String(offsets[i]).padStart(10, '0')} 00000 n \n`;
    parts.push(bytes(`${xref}trailer\n<< /Size ${this.objs.length} /Root 1 0 R >>\nstartxref\n${pos}\n%%EOF`));
    return new Blob(parts, { type: 'application/pdf' });
  }
}

// Contexto tipo canvas ----------------------------------------------------------------------------
class PdfCtx {
  constructor(doc, w, h) {
    this.doc = doc; this.w = w; this.h = h;
    this.ops = [];
    this.st = { fillStyle: '#000', strokeStyle: '#000', lineWidth: 1, lineCap: 'butt', lineJoin: 'miter', dash: [], globalAlpha: 1, gco: 'source-over', font: '10px sans-serif', textAlign: 'left', textBaseline: 'alphabetic' };
    this.stack = [];
    this.path = []; this.cur = null; this.start = null;
    this.pending = [];   // tipografías e imágenes que se cargan de forma asíncrona
    // Coordenadas como en el canvas: y hacia abajo, en puntos.
    this.ops.push(`1 0 0 -1 0 ${f(h)} cm`);
  }
  // Estado
  save() { this.stack.push({ ...this.st, dash: [...this.st.dash] }); this.ops.push('q'); }
  restore() { if (!this.stack.length) return; this.st = this.stack.pop(); this.ops.push('Q'); }
  set fillStyle(v) { this.st.fillStyle = v; } get fillStyle() { return this.st.fillStyle; }
  set strokeStyle(v) { this.st.strokeStyle = v; } get strokeStyle() { return this.st.strokeStyle; }
  set lineWidth(v) { this.st.lineWidth = v; } get lineWidth() { return this.st.lineWidth; }
  set lineCap(v) { this.st.lineCap = v; } set lineJoin(v) { this.st.lineJoin = v; }
  set globalAlpha(v) { this.st.globalAlpha = v; } get globalAlpha() { return this.st.globalAlpha; }
  set globalCompositeOperation(v) { this.st.gco = v; }
  set font(v) { this.st.font = v; } get font() { return this.st.font; }
  set textAlign(v) { this.st.textAlign = v; } set textBaseline(v) { this.st.textBaseline = v; }
  set shadowColor(_) {} set shadowBlur(_) {} set shadowOffsetX(_) {} set shadowOffsetY(_) {} set filter(_) {}
  setLineDash(d) { this.st.dash = [...d]; }
  translate(x, y) { this.ops.push(`1 0 0 1 ${f(x)} ${f(y)} cm`); }
  scale(x, y) { this.ops.push(`${f(x)} 0 0 ${f(y)} 0 0 cm`); }
  rotate(a) { const c = Math.cos(a), s = Math.sin(a); this.ops.push(`${f(c)} ${f(s)} ${f(-s)} ${f(c)} 0 0 cm`); }
  transform(a, b, c, d, e, g) { this.ops.push(`${f(a)} ${f(b)} ${f(c)} ${f(d)} ${f(e)} ${f(g)} cm`); }

  // Caminos
  beginPath() { this.path = []; this.cur = null; }
  moveTo(x, y) { this.path.push(`${f(x)} ${f(y)} m`); this.cur = [x, y]; this.start = [x, y]; }
  lineTo(x, y) { if (!this.cur) return this.moveTo(x, y); this.path.push(`${f(x)} ${f(y)} l`); this.cur = [x, y]; }
  bezierCurveTo(a, b, c, d, x, y) { this.path.push(`${f(a)} ${f(b)} ${f(c)} ${f(d)} ${f(x)} ${f(y)} c`); this.cur = [x, y]; }
  quadraticCurveTo(qx, qy, x, y) { const [x0, y0] = this.cur || [qx, qy]; this.bezierCurveTo(x0 + (2 / 3) * (qx - x0), y0 + (2 / 3) * (qy - y0), x + (2 / 3) * (qx - x), y + (2 / 3) * (qy - y), x, y); }
  closePath() { this.path.push('h'); if (this.start) this.cur = [...this.start]; }
  rect(x, y, w, h) { this.path.push(`${f(x)} ${f(y)} ${f(w)} ${f(h)} re`); this.cur = [x, y]; this.start = [x, y]; }
  arc(x, y, r, a0, a1, ccw = false) { this.ellipse(x, y, r, r, 0, a0, a1, ccw); }
  ellipse(cx, cy, rx, ry, rot, a0, a1, ccw = false) {
    let span = a1 - a0;
    if (!ccw && span < 0) span = (span % (2 * Math.PI)) + 2 * Math.PI;
    if (ccw && span > 0) span = (span % (2 * Math.PI)) - 2 * Math.PI;
    if (Math.abs(a1 - a0) >= 2 * Math.PI - 1e-9) span = ccw ? -2 * Math.PI : 2 * Math.PI;
    const segs = ellipseBeziers(cx, cy, rx, ry, rot, a0, a0 + span);
    const p0 = [cx + rx * Math.cos(a0) * Math.cos(rot) - ry * Math.sin(a0) * Math.sin(rot), cy + rx * Math.cos(a0) * Math.sin(rot) + ry * Math.sin(a0) * Math.cos(rot)];
    if (this.cur) this.lineTo(...p0); else this.moveTo(...p0);
    for (const s of segs) this.bezierCurveTo(...s);
  }
  arcTo(x1, y1, x2, y2, r) {
    const [x0, y0] = this.cur || [x1, y1];
    const v1 = [x0 - x1, y0 - y1], v2 = [x2 - x1, y2 - y1];
    const l1 = Math.hypot(...v1), l2 = Math.hypot(...v2);
    const ang = Math.acos(Math.max(-1, Math.min(1, (v1[0] * v2[0] + v1[1] * v2[1]) / (l1 * l2 || 1))));
    if (!r || !l1 || !l2 || ang < 1e-6 || Math.PI - ang < 1e-6) return this.lineTo(x1, y1);
    const t = r / Math.tan(ang / 2);
    const p1 = [x1 + (v1[0] / l1) * t, y1 + (v1[1] / l1) * t], p2 = [x1 + (v2[0] / l2) * t, y1 + (v2[1] / l2) * t];
    this.lineTo(...p1);
    const k = (4 / 3) * Math.tan((Math.PI - ang) / 4) * r;
    const d1 = [-v1[0] / l1, -v1[1] / l1], d2 = [-v2[0] / l2, -v2[1] / l2];
    this.bezierCurveTo(p1[0] + d1[0] * k, p1[1] + d1[1] * k, p2[0] + d2[0] * k, p2[1] + d2[1] * k, ...p2);
  }
  pathOps(p) {
    if (!p) return this.path;
    const out = [];
    for (const r of p.rec || []) svgToPdf(r.d, r.m, out);
    return out;
  }

  paint(kind, p, rule) {
    const ops = this.pathOps(p);
    if (!ops.length) return;
    const st = this.st, c = parseColor(kind === 'stroke' ? st.strokeStyle : st.fillStyle);
    const a = c.a * st.globalAlpha;
    if (a <= 0) return;
    const out = ['q', `/${this.doc.gstate(a, a, st.gco === 'multiply' ? 'Multiply' : null)} gs`];
    if (kind === 'stroke') {
      out.push(`${f(c.r)} ${f(c.g)} ${f(c.b)} RG`, `${f(st.lineWidth)} w`, `${{ butt: 0, round: 1, square: 2 }[st.lineCap] ?? 0} J`, `${{ miter: 0, round: 1, bevel: 2 }[st.lineJoin] ?? 0} j`);
      out.push(`[${st.dash.map(f).join(' ')}] 0 d`);
    } else out.push(`${f(c.r)} ${f(c.g)} ${f(c.b)} rg`);
    out.push(...ops, kind === 'stroke' ? 'S' : rule === 'evenodd' ? 'f*' : 'f', 'Q');
    this.ops.push(...out);
  }
  fill(p, rule) { if (typeof p === 'string') { rule = p; p = null; } this.paint('fill', p, rule); }
  stroke(p) { this.paint('stroke', p); }
  clip(p, rule) { if (typeof p === 'string') { rule = p; p = null; } const ops = this.pathOps(p); if (ops.length) this.ops.push(...ops, rule === 'evenodd' ? 'W* n' : 'W n'); }
  fillRect(x, y, w, h) { const keep = this.path; this.path = [`${f(x)} ${f(y)} ${f(w)} ${f(h)} re`]; this.paint('fill'); this.path = keep; }
  strokeRect(x, y, w, h) { const keep = this.path; this.path = [`${f(x)} ${f(y)} ${f(w)} ${f(h)} re`]; this.paint('stroke'); this.path = keep; }

  // Texto
  measureText(t) { this.doc.scratch.font = this.st.font; return this.doc.scratch.measureText(t); }
  fillText(text, x, y) {
    const fk = fontKey(this.st.font), st = this.st;
    const m = this.measureText(text);
    const asc = m.fontBoundingBoxAscent ?? fk.size * 0.9, desc = m.fontBoundingBoxDescent ?? fk.size * 0.25;
    const by = st.textBaseline === 'top' ? y + asc : st.textBaseline === 'middle' ? y + (asc - desc) / 2 : st.textBaseline === 'bottom' ? y - desc : y;
    const bx = st.textAlign === 'center' ? x - m.width / 2 : st.textAlign === 'right' || st.textAlign === 'end' ? x - m.width : x;
    const codes = [...text].map(toCode);
    // Emojis y letras fuera del español: como imagen nítida (a 8 veces su tamaño).
    if (fk.emoji || codes.some((c) => c == null)) { this.textImage(text, bx, by - asc, m.width, asc + desc); return; }
    const c = parseColor(st.fillStyle), a = c.a * st.globalAlpha;
    const slot = this.ops.length;
    this.ops.push('');   // se rellena cuando la tipografía está lista
    this.pending.push(this.doc.font(fk).then((name) => {
      this.ops[slot] = ['q', `/${this.doc.gstate(a, a, null)} gs`, `${f(c.r)} ${f(c.g)} ${f(c.b)} rg`, 'BT', `/${name} ${f(fk.size)} Tf`,
        `1 0 ${fk.italic ? '0.2' : '0'} -1 ${f(bx)} ${f(by)} Tm`, `${pdfString(codes)} Tj`, 'ET', 'Q'].join('\n');
    }));
  }
  textImage(text, x, y, w, h) {
    const k = 8, c = document.createElement('canvas');
    c.width = Math.max(1, Math.ceil(w * k)); c.height = Math.max(1, Math.ceil(h * k));
    const t = c.getContext('2d');
    t.scale(k, k); t.font = this.st.font; t.fillStyle = this.st.fillStyle; t.textBaseline = 'top';
    t.fillText(text, 0, 0);
    this.drawImage(c, 0, 0, c.width, c.height, x, y, w, h);
  }

  // Imágenes
  drawImage(src, ...a) {
    let sx = 0, sy = 0, sw = src.naturalWidth || src.videoWidth || src.width, sh = src.naturalHeight || src.videoHeight || src.height, dx, dy, dw = sw, dh = sh;
    if (a.length === 2) [dx, dy] = a; else if (a.length === 4) [dx, dy, dw, dh] = a; else [sx, sy, sw, sh, dx, dy, dw, dh] = a;
    const slot = this.ops.length, alpha = this.st.globalAlpha;
    this.ops.push('');
    const key = src.src ? `${src.src}|${sx}|${sy}|${sw}|${sh}` : null;
    this.pending.push(this.doc.image(src, sx, sy, sw, sh, key).then((img) => {
      this.ops[slot] = ['q', `/${this.doc.gstate(alpha, alpha, null)} gs`, `${f(dw)} 0 0 ${f(-dh)} ${f(dx)} ${f(dy + dh)} cm`, `/${img.name} Do`, 'Q'].join('\n');
    }));
  }

  async flush() { await Promise.all(this.pending); this.pending = []; }
}
