// Escritura y dibujo "a mano" generados (los usa Claude en Studio): convierte texto y figuras en trazos
// con el pulso irregular, la inclinación y la presión de una mano de verdad. Devuelve puntos del mundo [{x,y,p}].
import { HANDFONTS } from './handfonts.js';

// Generador pseudoaleatorio con semilla: el mismo texto sale igual al repetirlo, pero cada letra es distinta.
export function rng(seed = Date.now()) {
  let s = seed >>> 0 || 1;
  const next = () => { s ^= s << 13; s >>>= 0; s ^= s >> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
  const r = (a = 0, b = 1) => a + (b - a) * next();
  r.gauss = (sd = 1) => (next() + next() + next() - 1.5) * sd * 1.15;
  return r;
}

/** Suaviza una polilínea (Catmull-Rom) y la remuestrea a pasos de ~step px. */
function smooth(pts, step) {
  if (pts.length < 3) return densify(pts, step);
  const out = [];
  for (let i = 0; i < pts.length - 1; i++) {
    const p0 = pts[Math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.min(pts.length - 1, i + 2)];
    const n = Math.max(1, Math.ceil(Math.hypot(p2.x - p1.x, p2.y - p1.y) / step));
    for (let s = 0; s < n; s++) {
      const t = s / n, t2 = t * t, t3 = t2 * t;
      const f = (a, b, c, d) => 0.5 * (2 * b + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t2 + (-a + 3 * b - 3 * c + d) * t3);
      out.push({ x: f(p0.x, p1.x, p2.x, p3.x), y: f(p0.y, p1.y, p2.y, p3.y) });
    }
  }
  out.push(pts[pts.length - 1]);
  return out;
}

function densify(pts, step) {
  if (pts.length < 2) return pts;
  const out = [];
  for (let i = 0; i < pts.length - 1; i++) {
    const a = pts[i], b = pts[i + 1], n = Math.max(1, Math.ceil(Math.hypot(b.x - a.x, b.y - a.y) / step));
    for (let s = 0; s < n; s++) out.push({ x: a.x + (b.x - a.x) * (s / n), y: a.y + (b.y - a.y) * (s / n) });
  }
  out.push(pts[pts.length - 1]);
  return out;
}

/** Pulso y presión: un temblor suave (no ruido punto a punto) y presión que sube al empezar y afloja al final. */
function humanize(pts, r, wobble) {
  const n = pts.length;
  let wx = 0, wy = 0;
  const p0 = r(0.55, 0.75);
  return pts.map((p, i) => {
    wx = wx * 0.85 + r.gauss(wobble) * 0.15;
    wy = wy * 0.85 + r.gauss(wobble) * 0.15;
    const t = n > 1 ? i / (n - 1) : 0.5;
    const press = Math.min(1, Math.max(0.15, p0 * (0.55 + 0.45 * Math.sin(Math.PI * Math.min(1, t * 1.1 + 0.05)) ** 0.6) + r.gauss(0.03)));
    return { x: p.x + wx, y: p.y + wy, p: press };
  });
}

export const FONT_NAMES = Object.keys(HANDFONTS);

/**
 * Texto escrito a mano. size = alto de las mayúsculas (px). Devuelve { strokes, box }.
 * width limita el ancho de cada línea (salta de línea entre palabras).
 */
export function writeText(text, { x = 0, y = 0, size = 40, font = 'informal', width = Infinity, seed } = {}) {
  const F = HANDFONTS[font] || HANDFONTS.informal;
  const r = rng(seed ?? hash(text));
  const k = size / (F.cap || 600);
  const space = (F.glyphs[' ']?.[0] || 350) * k;
  const lineH = size * 1.9;
  const glyph = (ch) => F.glyphs[ch] || F.glyphs[ch.normalize('NFD')[0]] || F.glyphs['?'];
  const wordW = (w) => [...w].reduce((s, ch) => s + (glyph(ch)?.[0] || 0) * k, 0);

  // Reparte las palabras en líneas.
  const lines = [];
  for (const para of String(text).split('\n')) {
    let line = [], lw = 0;
    for (const w of para.split(/\s+/).filter(Boolean)) {
      const ww = wordW(w);
      if (line.length && lw + space + ww > width) { lines.push(line); line = []; lw = 0; }
      line.push(w); lw += (line.length > 1 ? space : 0) + ww;
    }
    lines.push(line);
  }

  const strokes = [];
  let maxX = x, maxY = y;
  const slant = r(-0.04, 0.06);   // inclinación general de esta mano
  lines.forEach((words, li) => {
    let cx = x + r.gauss(size * 0.08);
    const base = y + size + li * lineH;
    const drift = r(-0.012, 0.012);   // la línea sube o baja un poco
    words.forEach((w, wi) => {
      if (wi) cx += space * r(0.85, 1.2);
      for (const ch of w) {
        const g = glyph(ch);
        if (!g) continue;
        const [adv, parts] = g;
        const sc = k * r(0.95, 1.05);
        const rot = r.gauss(0.022);
        const by = base + (cx - x) * drift + r.gauss(size * 0.025);
        const cos = Math.cos(rot), sin = Math.sin(rot);
        for (const part of parts) {
          const pts = [];
          for (let i = 0; i < part.length; i += 2) {
            const gx = part[i] * sc, gy = part[i + 1] * sc;
            const sx = gx - gy * slant;
            pts.push({ x: cx + sx * cos - gy * sin, y: by + sx * sin + gy * cos });
          }
          const s = humanize(smooth(pts, Math.max(1.2, size / 18)), r, size * 0.012);
          strokes.push(s);
          for (const p of s) { if (p.x > maxX) maxX = p.x; if (p.y > maxY) maxY = p.y; }
        }
        cx += adv * sc * r(0.97, 1.03);
      }
    });
  });
  return { strokes, box: { x, y, w: maxX - x, h: Math.max(maxY, y + size) - y } };
}

/**
 * Figuras dibujadas a mano. Cada trazo: { puntos: [[x,y],...] } | { circulo: [cx,cy,r] } | { elipse: [cx,cy,rx,ry] }
 * | { rectangulo: [x,y,w,h] } | { linea: [x1,y1,x2,y2] }. Las coordenadas ya vienen en el mundo.
 */
export function drawShape(t, { seed, curve = true, scale = 1 } = {}) {
  const r = rng(seed ?? hash(JSON.stringify(t)));
  let pts;
  if (t.circulo || t.elipse) {
    const [cx, cy, rx, ry = rx] = t.circulo || t.elipse;
    const a0 = r(0, Math.PI * 2), turn = Math.PI * 2 * r(1.03, 1.1);   // se cierra pasándose un poco, como a mano
    const n = Math.max(16, Math.ceil(Math.max(rx, ry) / 3));
    const wob = r(0.02, 0.05);
    pts = [];
    for (let i = 0; i <= n; i++) {
      const a = a0 + (turn * i) / n, f = 1 + wob * Math.sin(a * 2 + a0) + r.gauss(0.006);
      pts.push({ x: cx + Math.cos(a) * rx * f, y: cy + Math.sin(a) * ry * f });
    }
  } else if (t.rectangulo) {
    const [x, y, w, h] = t.rectangulo;
    const j = () => r.gauss(Math.min(w, h) * 0.015);
    pts = [{ x: x + j(), y: y + j() }, { x: x + w + j(), y: y + j() }, { x: x + w + j(), y: y + h + j() }, { x: x + j(), y: y + h + j() }, { x: x + j() + w * 0.04, y: y + j() }];
    curve = false;
  } else if (t.linea) {
    const [x1, y1, x2, y2] = t.linea;
    const len = Math.hypot(x2 - x1, y2 - y1), bow = r.gauss(len * 0.015);
    const nx = -(y2 - y1) / (len || 1), ny = (x2 - x1) / (len || 1);
    pts = [{ x: x1, y: y1 }, { x: (x1 + x2) / 2 + nx * bow, y: (y1 + y2) / 2 + ny * bow }, { x: x2, y: y2 }];
  } else pts = (t.puntos || []).map(([x, y]) => ({ x, y }));
  if (!pts.length) return [];
  const step = Math.max(1.5, 3 * scale);
  return humanize(curve ? smooth(pts, step) : densify(pts, step), r, 0.6 * scale + 0.3);
}

function hash(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
