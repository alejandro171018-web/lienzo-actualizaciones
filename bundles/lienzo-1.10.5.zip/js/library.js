// Carpetas y etiquetas para organizar los tableros.
import * as db from './db.js';
import { h, icon, uid } from './util.js';
import { menu, popover, prompt, confirm, toast, closeAllPopovers } from './ui.js';

export const LIB_COLORS = ['#007AFF', '#34C759', '#FF9500', '#FF3B30', '#AF52DE', '#FFCC00', '#FF2D55', '#00C7BE', '#8E8E93'];

let cache = null;
export async function library() { if (!cache) cache = await db.getLibrary(); return cache; }
async function save() { await db.putLibrary(cache); }
/** La sincronización ha traído carpetas o etiquetas nuevas: se vuelven a leer. */
export function resetLibraryCache() { cache = null; }

export const folderOf = (lib, id) => lib.folders.find((f) => f.id === id);
export const tagOf = (lib, id) => lib.tags.find((t) => t.id === id);

function nextColor(list) {
  const used = new Set(list.map((x) => x.color));
  return LIB_COLORS.find((c) => !used.has(c)) || LIB_COLORS[list.length % LIB_COLORS.length];
}

export async function createFolder() {
  const name = await prompt('Nueva carpeta', '', { placeholder: 'Ej.: Instagram', ok: 'Crear' });
  if (!name) return null;
  const lib = await library();
  const f = { id: uid(), name, color: nextColor(lib.folders) };
  lib.folders.push(f);
  await save();
  return f;
}

export async function createTag() {
  const name = await prompt('Nueva etiqueta', '', { placeholder: 'Ej.: Urgente', ok: 'Crear' });
  if (!name) return null;
  const lib = await library();
  const t = { id: uid(), name, color: nextColor(lib.tags) };
  lib.tags.push(t);
  await save();
  return t;
}

/** Menú de una carpeta o etiqueta de la barra lateral: renombrar, color, eliminar. */
export async function editEntry(kind, entry, anchor, onChange) {
  const lib = await library();
  const list = kind === 'folder' ? lib.folders : lib.tags;
  const label = kind === 'folder' ? 'carpeta' : 'etiqueta';
  const colors = h('div.lib-colors');
  for (const c of LIB_COLORS) {
    colors.append(h('button.lib-color' + (c === entry.color ? '.on' : ''), { style: { background: c }, onclick: async () => { entry.color = c; await save(); closeAllPopovers(); onChange(); } }));
  }
  const p = popover(anchor, h('div.pop-pad', {},
    h('div.pop-title', { text: entry.name }),
    colors,
    h('button.btn.full', { html: `${icon('pencil', 18)} Renombrar`, onclick: async () => {
      p.close();
      const n = await prompt(`Nombre de la ${label}`, entry.name);
      if (n) { entry.name = n; await save(); onChange(); }
    } }),
    h('button.btn.full.danger-text', { html: `${icon('trash-2', 18)} Eliminar ${label}`, onclick: async () => {
      p.close();
      const msg = kind === 'folder' ? 'Los tableros no se borran: pasan a «Todos los tableros».' : 'Los tableros no se borran: solo pierden esta etiqueta.';
      if (!(await confirm(`¿Eliminar «${entry.name}»?`, msg, { ok: 'Eliminar', danger: true }))) return;
      list.splice(list.indexOf(entry), 1);
      await save();
      for (const m of await db.listMeta()) {
        let changed = false;
        if (kind === 'folder' && m.folder === entry.id) { m.folder = null; changed = true; }
        if (kind === 'tag' && m.tags?.includes(entry.id)) { m.tags = m.tags.filter((t) => t !== entry.id); changed = true; }
        if (changed) await db.putMeta(m);
      }
      onChange(true);
    } })));
}

/** Menú «Mover a carpeta» para un tablero. */
export async function moveToFolder(meta, anchor, onDone) {
  const lib = await library();
  const set = async (folder) => {
    const fresh = (await db.getMeta(meta.id)) || meta;
    fresh.folder = folder; meta.folder = folder;
    await db.putMeta(fresh);
    const f = folderOf(lib, folder);
    toast(f ? `Movido a «${f.name}»` : 'Quitado de la carpeta', 1200);
    onDone?.();
  };
  menu(anchor, [
    ...lib.folders.map((f) => ({ label: f.name, checked: meta.folder === f.id, act: () => set(f.id) })),
    lib.folders.length ? { sep: true } : null,
    { label: 'Nueva carpeta…', icon: 'plus', act: async () => { const f = await createFolder(); if (f) set(f.id); } },
    meta.folder ? { label: 'Quitar de la carpeta', icon: 'x', act: () => set(null) } : null,
  ]);
}

/** Popover para marcar y desmarcar las etiquetas de un tablero. */
export async function editTags(meta, anchor, onDone) {
  const lib = await library();
  const box = h('div.pop-pad.tag-pick', {}, h('div.pop-title', { text: 'Etiquetas' }));
  const list = h('div.tag-list');
  const toggle = async (id) => {
    const fresh = (await db.getMeta(meta.id)) || meta;
    const tags = new Set(fresh.tags || []);
    if (tags.has(id)) tags.delete(id); else tags.add(id);
    fresh.tags = [...tags]; meta.tags = fresh.tags;
    await db.putMeta(fresh);
    draw();
    onDone?.();
  };
  const draw = () => {
    list.innerHTML = '';
    if (!lib.tags.length) list.append(h('p.pop-note', { text: 'Aún no tienes etiquetas. Crea una para marcar tableros por tema, prioridad o estado.' }));
    for (const t of lib.tags) {
      const on = (meta.tags || []).includes(t.id);
      list.append(h('button.tag-row' + (on ? '.on' : ''), { onclick: () => toggle(t.id) },
        h('span.tag-dot', { style: { background: t.color } }), h('span.lbl', { text: t.name }), h('span.chk', { html: on ? icon('check', 18) : '' })));
    }
  };
  draw();
  box.append(list, h('button.btn.full', { html: `${icon('plus', 18)} Nueva etiqueta`, onclick: async () => { const t = await createTag(); if (t) { await toggle(t.id); } } }));
  popover(anchor, box, { keep: false });
}

/** Puntos de color de las etiquetas de un tablero (para las tarjetas de la galería). */
export function tagDots(lib, meta) {
  const tags = (meta.tags || []).map((id) => tagOf(lib, id)).filter(Boolean);
  if (!tags.length) return null;
  return h('div.card-tags', {}, ...tags.slice(0, 5).map((t) => h('span.tag-chip', { title: t.name }, h('span.tag-dot', { style: { background: t.color } }), t.name)));
}
