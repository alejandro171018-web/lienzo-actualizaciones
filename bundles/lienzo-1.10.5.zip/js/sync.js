// Sincronización con Studio (el PC): los tableros viven en el PC y aquí hay una copia que se mantiene al día.
// Cada tablero tiene un número de versión en el PC. Si los dos lados han cambiado, se juntan los cambios elemento
// a elemento comparando con la última versión común (la "base"), así no se pierde lo que se hizo en cada lado.
import * as db from './db.js';
import { store } from './store.js';
import { resetLibraryCache } from './library.js';

const LIB_ID = '__biblioteca__';
const STATE_KEY = 'studio.sync';
let T = null;              // transporte: { req(method, path, body) -> { status, data } }
let timer = null, running = false, again = false, fails = 0, ticks = 0;
let state = load();
const listeners = new Set();
export const status = { ok: false, last: 0, error: '' };

function load() { try { return JSON.parse(localStorage.getItem(STATE_KEY) || '{}'); } catch { return {}; } }
function saveState() { try { localStorage.setItem(STATE_KEY, JSON.stringify(state)); } catch { /* sin espacio */ } }
export function onStatus(fn) { listeners.add(fn); }
const emit = () => { for (const fn of listeners) fn(status); };

// Base: la última versión que ambos lados tenían en común (en una base de datos aparte, para no tocar la de los tableros).
let basep;
function baseDB() {
  if (!basep) basep = new Promise((res, rej) => { const r = indexedDB.open('lienzo-sync', 1); r.onupgradeneeded = () => r.result.createObjectStore('base', { keyPath: 'id' }); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error); });
  return basep;
}
async function baseOp(mode, fn) {
  const d = await baseDB();
  return new Promise((res, rej) => { const t = d.transaction('base', mode); const s = t.objectStore('base'); const r = fn(s); t.oncomplete = () => res(r?.result); t.onerror = () => rej(t.error); });
}
const getBase = (id) => (pendingBase?.id === id ? Promise.resolve(pendingBase) : baseOp('readonly', (s) => s.get(id)));
const putBase = (rec) => baseOp('readwrite', (s) => s.put(rec));

// Lo que se sincroniza: sin la posición de la vista (es de cada pantalla) ni datos derivados.
const metaOut = (m) => { const { view, ...rest } = m; return rest; };
const contentOut = (c) => { const { view, ...rest } = c || {}; return rest; };
function hashOf(meta, content) {
  const { thumb, updated, find, view, ...m } = meta;
  const s = JSON.stringify([m, contentOut(content)]);
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return `${s.length}:${h >>> 0}`;
}

/** Junta tres versiones de una lista de elementos con id. Gana el cambio de quien cambió; si cambiaron los dos, el del PC. */
export function mergeItems(base = [], local = [], remote = []) {
  const B = new Map(base.map((i) => [i.id, JSON.stringify(i)]));
  const L = new Map(local.map((i) => [i.id, i]));
  const R = new Map(remote.map((i) => [i.id, i]));
  const changed = (map, id) => JSON.stringify(map.get(id)) !== B.get(id);
  const out = [];
  for (const r of remote) {
    const id = r.id;
    if (L.has(id)) out.push(changed(L, id) && !changed(R, id) ? L.get(id) : r);
    else if (!B.has(id) || changed(R, id)) out.push(r);   // nuevo en el PC, o borrado aquí pero cambiado allí
  }
  for (const l of local) {
    if (R.has(l.id)) continue;
    if (!B.has(l.id) || changed(L, l.id)) out.push(l);   // nuevo aquí, o borrado allí pero cambiado aquí
  }
  return out;
}

function mergeContent(base, local, remote) {
  // Carpetas y etiquetas: listas con id, igual que los elementos.
  if (remote && 'folders' in remote) return { folders: mergeItems(base?.folders, local?.folders, remote.folders), tags: mergeItems(base?.tags, local?.tags, remote.tags) };
  const out = { ...remote, items: mergeItems(base?.items, local?.items, remote?.items) };
  for (const k of ['scenes', 'bg', 'pages', 'paper', 'hw', 'kind']) {
    if (JSON.stringify(local?.[k]) !== JSON.stringify(base?.[k]) && JSON.stringify(remote?.[k]) === JSON.stringify(base?.[k])) out[k] = local[k];
  }
  return out;
}

// Archivos (fotos, PDF, audio): se suben o bajan cuando hacen falta.
const toB64 = (blob) => new Promise((res) => { const r = new FileReader(); r.onload = () => res(String(r.result).split(',')[1]); r.readAsDataURL(blob); });
async function uploadBlobs(ids) {
  for (const id of ids) {
    const b = await db.getBlob(id);
    if (b) await T.req('PUT', `/api/archivo/${id}`, { type: b.type, data: await toB64(b) });
  }
}
async function downloadBlobs(items) {
  for (const id of db.blobIdsOf(items || [])) {
    if (await db.getBlob(id)) continue;
    const r = await T.req('GET', `/api/archivo/${id}`);
    if (r.status !== 200) continue;
    const bin = atob(r.data.data), arr = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    await db.putBlob(new Blob([arr], { type: r.data.type || '' }), id);
  }
}

const isOpenBoard = (id) => store.meta?.id === id;
let memo = null, pendingBase = null, baseTimer = null;
const flushBase = () => {
  clearTimeout(baseTimer);
  const r = pendingBase; pendingBase = null;
  if (!r) return null;
  if (state[r.id]) { state[r.id].hash = hashOf(r.meta, r.content); saveState(); }
  return putBase(r);
};   // { id, arr, refs, scenes, hw, bg, pages, title } de la última versión común del tablero abierto
const sameAsMemo = (id) => memo && memo.id === id && store.items === memo.arr && store.scenes === memo.scenes && store.hw === memo.hw && store.bg === memo.bg && store.pages === memo.pages && store.meta?.title === memo.title;

/** Versión local de un tablero: si está abierto, lo que hay en pantalla (aún sin guardar). */
async function localOf(id) {
  if (isOpenBoard(id)) return { meta: { ...store.meta }, content: store.content() };
  if (id === LIB_ID) { const lib = await db.getLibrary(); return { meta: { id: LIB_ID, title: '', updated: 0 }, content: lib }; }
  const meta = await db.getMeta(id);
  return meta ? { meta, content: (await db.getContent(id)) || { items: [] } } : null;
}

/** Guarda en este dispositivo la versión que viene del PC (o la juntada). */
async function applyLocal(id, meta, content) {
  if (id === LIB_ID) { await db.putLibrary({ folders: content.folders || [], tags: content.tags || [] }); resetLibraryCache(); window.lienzo?.home?.refresh?.(); return; }
  if (meta.deleted) {
    if (isOpenBoard(id)) await window.lienzo.closeBoard();
    if (await db.getMeta(id)) await db.deleteBoard(id);
    return;
  }
  await downloadBlobs(content.items);
  const prev = await db.getMeta(id);
  const m = { ...meta, view: prev?.view };
  if (isOpenBoard(id)) {
    // Tablero abierto: se cambia en pantalla al momento (sin tocar lo que estás haciendo en ese instante).
    const b = window.lienzo.board;
    for (let i = 0; i < 40 && (b.isBusy() || b.editing); i++) await new Promise((r) => setTimeout(r, 250));
    for (const bid of db.blobIdsOf(content.items)) await db.blobURL(bid);
    store.scenes = content.scenes || store.scenes; store.bg = content.bg || store.bg; store.hw = content.hw || store.hw;
    if (content.pages) store.pages = content.pages;
    Object.assign(store.meta, metaOut(m));
    store.set(content.items || [], { scenes: true, bg: true, pages: true });
    document.querySelector('#b-title span').textContent = store.meta.title;
  }
  await db.saveBoard(m, { ...content, id, view: (await db.getContent(id))?.view });
  if (window.lienzo?.current === 'home') window.lienzo.home.refresh();
}

/** Cambios de un tablero respecto a la base: elementos nuevos o cambiados, borrados, orden y el resto si cambió. */
function deltaOf(base, content, id) {
  const items = content.items || [];
  if (memo?.id === id && memo.refs && isOpenBoard(id) && content.items === store.items) {
    const set = items.filter((i) => memo.refs.get(i.id) !== i);
    const ids = new Set(items.map((i) => i.id));
    const del = [...memo.refs.keys()].filter((k) => !ids.has(k));
    const kept = memo.arr.map((i) => i.id).filter((k) => ids.has(k));
    const sameOrder = items.filter((i) => memo.refs.has(i.id)).every((i, n) => i.id === kept[n]);
    const rest = {};
    if (content.scenes !== memo.scenes) rest.scenes = content.scenes ?? null;
    if (content.hw !== memo.hw) rest.hw = content.hw ?? null;
    if (content.bg !== memo.bg) rest.bg = content.bg ?? null;
    if (content.pages !== memo.pages) { rest.pages = content.pages ?? null; rest.paper = content.paper ?? null; }
    return { set, del, ...(sameOrder ? {} : { order: items.map((i) => i.id) }), rest };
  }
  const B = new Map((base.items || []).map((i) => [i.id, JSON.stringify(i)]));
  const set = items.filter((i) => B.get(i.id) !== JSON.stringify(i));
  const ids = new Set(items.map((i) => i.id));
  const del = [...B.keys()].filter((k) => !ids.has(k));
  const kept = (base.items || []).map((i) => i.id).filter((k) => ids.has(k));
  const sameOrder = items.filter((i) => B.has(i.id)).every((i, n) => i.id === kept[n]);
  const rest = {};
  for (const k of ['scenes', 'bg', 'pages', 'paper', 'hw', 'kind']) if (JSON.stringify(content[k]) !== JSON.stringify(base[k])) rest[k] = content[k] ?? null;
  return { set, del, ...(sameOrder ? {} : { order: items.map((i) => i.id) }), rest };
}

async function push(id, local, baseRev) {
  for (let tries = 0; tries < 4; tries++) {
    const fresh = id !== LIB_ID && baseRev && state[id]?.rev === baseRev;
    const base = !fresh ? null : memo?.id === id && isOpenBoard(id) ? { meta: memo.meta, content: { items: memo.arr } } : await getBase(id);
    // La miniatura solo viaja si ha cambiado (es lo que más pesa de la ficha).
    const meta = metaOut(local.meta);
    for (const k of ['thumb', 'find']) if (base && meta[k] === base.meta?.[k]) delete meta[k];   // miniatura y texto de búsqueda: solo si cambian
    const body = base?.content?.items ? { baseRev, meta, delta: deltaOf(base.content, contentOut(local.content), id) } : { baseRev, meta: metaOut(local.meta), content: contentOut(local.content) };
    const r = await T.req('PUT', `/api/tablero/${id}`, body);
    if (r.status === 200) {
      if (r.data.faltan?.length) await uploadBlobs(r.data.faltan);
      await done(id, r.data.rev, local.meta, local.content);
      return;
    }
    if (r.status !== 409) throw new Error(r.data?.error || `HTTP ${r.status}`);
    // Alguien cambió el tablero en el PC mientras tanto: se juntan los cambios y se vuelve a intentar.
    const remote = r.data;
    const common = await getBase(id);
    const merged = { meta: { ...remote.meta, ...metaOut(local.meta) }, content: mergeContent(common?.content, local.content, remote.content) };
    await applyLocal(id, merged.meta, merged.content);
    local = merged; baseRev = remote.rev;
  }
}

async function done(id, rev, meta, content) {
  const open = isOpenBoard(id) && content.items === store.items;
  if (open) memo = { id, arr: store.items, refs: new Map(store.items.map((i) => [i.id, i])), scenes: store.scenes, hw: store.hw, bg: store.bg, pages: store.pages, title: store.meta.title, meta: metaOut(meta) };
  else if (memo?.id === id) memo = null;
  state[id] = { rev, hash: open ? state[id]?.hash : hashOf(meta, content), updated: meta.updated };
  saveState();
  // Tablero abierto: la base está en memoria y se guarda en disco como mucho cada 20 s (y al salir), no en cada trazo.
  const rec = { id, meta: metaOut(meta), content: contentOut(content) };
  if (open) { pendingBase = rec; clearTimeout(baseTimer); baseTimer = setTimeout(flushBase, 20000); } else await putBase(rec);
}

async function syncBoard(id, remoteRev, remoteDeleted = false, meta = undefined) {
  const st = state[id];
  if (pendingBase?.id === id && !isOpenBoard(id)) await flushBase();
  // Atajo (lo normal): ni aquí ni en el PC ha cambiado nada. Se mira solo la fecha, sin cargar el tablero.
  if (st && meta && id !== LIB_ID && !isOpenBoard(id) && meta.updated === st.updated && remoteRev === st.rev) return;
  // Mientras escribes o dibujas en ese tablero, se espera a que pares (así no da tirones ni gasta batería).
  if (isOpenBoard(id) && window.lienzo?.board?.isBusy?.()) return;
  const local = await localOf(id);
  if (!local) {
    if (st) {
      if (remoteDeleted) return;   // ya está borrado en los dos lados
      // Borrado aquí del todo: se avisa al PC (si ya lo tenía).
      if (remoteRev && remoteRev === st.rev) await push(id, { meta: { id, deleted: true, updated: Date.now() }, content: { items: [] } }, remoteRev);
      else if (remoteRev) { delete state[id]; saveState(); }   // cambiado en el PC después de borrarlo aquí: se vuelve a traer
      return;
    }
    if (!remoteRev) return;
    // Tablero nuevo que viene del PC.
    const r = await T.req('GET', `/api/tablero/${id}`);
    if (r.status !== 200 || r.data.meta?.deleted) return;
    await applyLocal(id, r.data.meta, r.data.content);
    await done(id, r.data.rev, r.data.meta, r.data.content);
    return;
  }
  // La fecha evita calcular la huella cada vez; la biblioteca no tiene fecha y es pequeña, se compara siempre.
  const openMemo = isOpenBoard(id) && memo?.id === id && st;
  const localChanged = !st || (openMemo ? !sameAsMemo(id) : (id === LIB_ID || local.meta.updated !== st.updated) && hashOf(local.meta, local.content) !== st.hash);
  const remoteChanged = remoteRev != null && (!st || remoteRev !== st.rev);
  if (!localChanged && !remoteChanged) return;
  if (!remoteChanged) { await push(id, local, st?.rev || 0); return; }
  const r = await T.req('GET', `/api/tablero/${id}`);
  if (r.status !== 200) throw new Error(`HTTP ${r.status}`);
  const remote = r.data;
  if (!localChanged) { await applyLocal(id, remote.meta, remote.content); await done(id, remote.rev, remote.meta, remote.content); return; }
  const base = await getBase(id);
  const merged = { meta: { ...remote.meta, title: local.meta.title !== base?.meta?.title ? local.meta.title : remote.meta.title, updated: Date.now() }, content: mergeContent(base?.content, local.content, remote.content) };
  await applyLocal(id, merged.meta, merged.content);
  await push(id, merged, remote.rev);
}

async function cycle() {
  if (running) { again = true; return; }
  running = true;
  try {
    const r = await T.req('GET', '/api/tableros');
    if (r.status === 401) throw new Error('El código de emparejamiento no es correcto');
    if (r.status !== 200) throw new Error(`HTTP ${r.status}`);
    const remote = new Map(r.data.map((b) => [b.id, b]));
    const metas = new Map((await db.listMeta()).map((m) => [m.id, m]));
    const ids = new Set([...metas.keys(), LIB_ID, ...Object.keys(state)]);
    for (const b of r.data) if (!b.deleted || state[b.id]) ids.add(b.id);
    for (const id of ids) {
      const rb = remote.get(id);
      if (rb?.deleted && !state[id] && !metas.has(id)) continue;
      await syncBoard(id, rb?.rev, !!rb?.deleted, metas.get(id) || null);
    }
    Object.assign(status, { ok: true, last: Date.now(), error: '' });
    fails = 0;
  } catch (err) {
    Object.assign(status, { ok: false, error: String(err?.message || err) });
    fails++;
  } finally {
    running = false;
    emit();
    if (again) { again = false; setTimeout(cycle, 200); }
  }
}

/**
 * Empieza a sincronizar con el PC. transport.req(method, path, body) devuelve { status, data }.
 * background: seguir aunque la app no esté en pantalla (en el PC sí; en la tablet no, para ahorrar batería).
 */
export function start(transport, every = 3000, background = false) {
  T = transport;
  clearInterval(timer);
  timer = setInterval(() => {
    if (!background && document.visibilityState !== 'visible') return;
    ticks++;
    if (fails && ticks % Math.min(15, 2 ** Math.min(fails, 4)) !== 0) return;   // PC apagado: 4 s, 8, 16, 32… hasta 1 min
    cycle();
  }, every);
  // Al volver a la app se sincroniza enseguida; al salir, una última vez (lo que acabas de escribir llega al PC).
  document.addEventListener('visibilitychange', () => { fails = 0; if (document.visibilityState === 'hidden') flushBase(); cycle(); });
  cycle();
}
export const syncNow = () => T && cycle();
export function stop() { clearInterval(timer); T = null; }
/** Al conectar otro PC u otro código, se empieza de cero (sin borrar nada: solo se vuelve a comparar todo). */
export function resetState() { state = {}; saveState(); }
