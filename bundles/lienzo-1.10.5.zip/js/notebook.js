// Cuadernos: páginas una debajo de otra (como una libreta), con plantilla de papel por página.
import { store, cloneItems } from './store.js';
import { h, icon, uid, clamp } from './util.js';
import { menu, popover, toast, confirm, dialog, segmented, closeAllPopovers } from './ui.js';
import * as G from './geom.js';
import { PAGE_GAP, PAGE_SIZES, TEMPLATES, PAPER_COLORS, paperColor, templateSVG, templatePreview, templateName } from './paper.js';
import { isDark } from './render.js';
import { renderToCanvas } from './export.js';

export const isNotebook = () => store.kind === 'notebook' && !!store.pages?.length;
export const pageSize = () => PAGE_SIZES[store.paper?.orient] || PAGE_SIZES.portrait;
const stride = () => pageSize().h + PAGE_GAP;

export function pageRect(i) { const { w, h: hh } = pageSize(); return { x: 0, y: i * stride(), w, h: hh }; }

/** Página bajo un punto del mundo (-1 si cae fuera de todas). */
export function pageAt(w, tol = 0) {
  const { w: pw, h: ph } = pageSize();
  const i = Math.floor((w.y + PAGE_GAP / 2) / stride());
  if (i < 0 || i >= store.pages.length) return -1;
  const y0 = i * stride();
  return w.x >= -tol && w.x <= pw + tol && w.y >= y0 - tol && w.y <= y0 + ph + tol ? i : -1;
}

/** Página a la que pertenece un elemento (por su centro). */
export function pageOf(it, map) {
  const b = G.aabb(it, map);
  return clamp(Math.floor((b.y + b.h / 2 + PAGE_GAP / 2) / stride()), 0, store.pages.length - 1);
}

/** Datos de un cuaderno nuevo. */
export function newNotebookContent({ orient = 'portrait', color = 'white', tpl = 'lines' } = {}) {
  return { items: [], scenes: [], bg: 'none', view: null, kind: 'notebook', paper: { orient, color, tpl }, pages: [{ id: uid(), tpl }] };
}

// Pintado de las páginas ----------------------------------------------------------------
export class Pages {
  constructor(board) {
    this.b = board;
    this.layer = h('div.pages-layer');
    this.els = [];
    this.drawn = new Map();   // índice -> clave de lo pintado (para no repintar)
  }

  /** Reconstruye las páginas (al abrir, al cambiar páginas o el tema). */
  render() {
    const layer = this.layer;
    layer.innerHTML = '';
    this.els = [];
    this.drawn.clear();
    if (!isNotebook()) return;
    const { w, h: hh } = pageSize();
    const bg = paperColor(store.paper.color, isDark());
    store.pages.forEach((p, i) => {
      const r = pageRect(i);
      const el = h('div.page', { style: { left: `${r.x}px`, top: `${r.y}px`, width: `${w}px`, height: `${hh}px`, background: bg } });
      layer.append(el, h('div.page-num', { text: `${i + 1}`, style: { left: `${r.x}px`, top: `${r.y + hh + 10}px`, width: `${w}px` } }));
      this.els.push(el);
    });
    const end = pageRect(store.pages.length);
    layer.append(h('button.add-page', { 'data-act': 'add-page', style: { left: `${w / 2}px`, top: `${end.y + 4}px` }, html: `${icon('plus', 22)}<span>Añadir página</span>` }));
    this.updateVisible(true);
  }

  /** Solo se dibuja la plantilla de las páginas cercanas a la vista (cuadernos largos van fluidos). */
  updateVisible(force = false) {
    if (!isNotebook() || !this.els.length) return;
    const vis = this.b.vp.visibleBox();
    const s = stride();
    const a = Math.max(0, Math.floor(vis.y / s) - 1), z = Math.min(this.els.length - 1, Math.floor((vis.y + vis.h) / s) + 1);
    const dark = isDark();
    const { w, h: hh } = pageSize();
    this.els.forEach((el, i) => {
      const want = i >= a && i <= z ? `${store.pages[i].tpl}|${dark}|${w}` : '';
      if (!force && this.drawn.get(i) === want) return;
      this.drawn.set(i, want);
      el.innerHTML = want ? templateSVG(store.pages[i].tpl, w, hh, dark) : '';
    });
  }

  /** Límites de la vista: centrada en horizontal si cabe; en vertical, de la primera a la última página. */
  bounds(x, y, z) {
    if (!isNotebook()) return { x, y };
    const r = this.b.vp.rect();
    const { w } = pageSize();
    const total = store.pages.length * stride() - PAGE_GAP + 90; // + botón «Añadir página»
    const m = 24, top = 70;
    const cw = w * z, ch = total * z;
    if (cw + m * 2 <= r.width) x = (r.width - cw) / 2;
    else x = clamp(x, r.width - m - cw, m);
    if (ch + top + m <= r.height) y = top;
    else y = clamp(y, r.height * 0.45 - ch, top);
    return { x, y };
  }
}

/** Página que más ocupa la vista ahora. */
export function currentPage(b) {
  if (!isNotebook()) return 0;
  const c = b.vp.center();
  return clamp(Math.floor((c.y + PAGE_GAP / 2) / stride()), 0, store.pages.length - 1);
}

/** Zoom para que la página ocupe el ancho (sin pasarse en tablets apaisadas). */
export function fitZoom(b, r = b.vp.rect()) {
  const { w, h: hh } = pageSize();
  return clamp(Math.min((r.width - 48) / w, ((r.height - 90) / hh) * 1.7), 0.3, 2.5);
}

export function goToPage(b, i, animate = true) {
  const r = b.vp.rect(), pr = pageRect(i), z = b.vp.z;
  const x = (r.width - pr.w * z) / 2, y = 78 - pr.y * z;
  if (animate) b.vp.animateTo(x, y, z, 320); else b.vp.set(x, y, z);
}

export function fitPage(b, i = currentPage(b), animate = true) {
  const r = b.vp.rect(), pr = pageRect(i);
  const z = fitZoom(b);
  const x = (r.width - pr.w * z) / 2, y = 78 - pr.y * z;
  if (animate) b.vp.animateTo(x, y, z); else b.vp.set(x, y, z);
}

// Operaciones con páginas (cada una es un solo paso de deshacer) --------------------------------
const shift = (it, dy) => {
  if (it.type === 'line') { const f = (e) => (e?.id ? e : { x: e.x, y: e.y + dy }); return { ...it, a: f(it.a), b: f(it.b) }; }
  return { ...it, y: it.y + dy };
};

function byPage(map) {
  const out = new Map();
  for (const it of store.items) { const p = pageOf(it, map); if (!out.has(p)) out.set(p, []); out.get(p).push(it); }
  return out;
}

export function addPage(b, after = store.pages.length - 1, tpl) {
  const page = { id: uid(), tpl: tpl || store.pages[Math.max(0, after)]?.tpl || store.paper.tpl };
  const pages = [...store.pages];
  pages.splice(after + 1, 0, page);
  const s = stride();
  const items = store.items.map((it) => (pageOf(it, b.map) > after ? shift(it, s) : it));
  store.setPages(pages, items);
  goToPage(b, after + 1);
}

export async function deletePage(b, i) {
  if (store.pages.length === 1) { toast('Un cuaderno necesita al menos una página'); return; }
  const mine = store.items.filter((it) => pageOf(it, b.map) === i);
  if (mine.length && !(await confirm(`¿Eliminar la página ${i + 1}?`, 'Se borrará lo que hay en ella. Puedes deshacerlo.', { ok: 'Eliminar', danger: true }))) return;
  const gone = new Set(mine.map((x) => x.id));
  const s = stride();
  const items = store.items.filter((it) => !gone.has(it.id)).map((it) => (pageOf(it, b.map) > i ? shift(it, -s) : it))
    .map((it) => (it.type === 'line' ? detach(it, gone, b.map) : it));
  const pages = store.pages.filter((_, k) => k !== i);
  b.clearSel();
  store.setPages(pages, items);
  b.pages.render();
}

function detach(line, gone, map) {
  let n = line;
  for (const end of ['a', 'b']) if (line[end]?.id && gone.has(line[end].id)) { const p = G.endPoint(line, end, map); n = { ...n, [end]: { x: p.x, y: p.y } }; }
  return n;
}

export function duplicatePage(b, i) {
  const s = stride();
  const mine = store.items.filter((it) => pageOf(it, b.map) === i);
  const copies = cloneItems(mine, 0, s, b.map);
  const items = [...store.items.map((it) => (pageOf(it, b.map) > i ? shift(it, s) : it)), ...copies];
  const pages = [...store.pages];
  pages.splice(i + 1, 0, { ...store.pages[i], id: uid() });
  store.setPages(pages, items);
  goToPage(b, i + 1);
  toast('Página duplicada');
}

/** Intercambia la página i con la siguiente o la anterior (dir = ±1). */
export function movePage(b, i, dir) {
  const j = i + dir;
  if (j < 0 || j >= store.pages.length) return;
  const s = stride();
  const items = store.items.map((it) => { const p = pageOf(it, b.map); return p === i ? shift(it, s * dir) : p === j ? shift(it, -s * dir) : it; });
  const pages = [...store.pages];
  [pages[i], pages[j]] = [pages[j], pages[i]];
  store.setPages(pages, items);
  goToPage(b, j);
}

export function setTemplate(i, tpl) {
  const pages = store.pages.map((p, k) => (i === 'all' || k === i ? { ...p, tpl } : p));
  store.setPages(pages, store.items, i === 'all' ? { ...store.paper, tpl } : store.paper);
}

export function setPaperColor(color) { store.setPages(store.pages, store.items, { ...store.paper, color }); }

// Paneles ------------------------------------------------------------------------------------------
/** Elegir plantilla: para esta página o para todas. */
export function templatePicker(b, anchor, i = currentPage(b)) {
  // La posición se toma ya: el botón puede estar en un panel que se cierra al abrir este.
  const at = anchor instanceof Element ? anchor.getBoundingClientRect() : anchor;
  let scope = 'one';
  const grid = h('div.tpl-grid');
  for (const t of TEMPLATES) {
    grid.append(h('button.tpl-opt' + (store.pages[i].tpl === t.id ? '.on' : ''), { onclick: () => { setTemplate(scope === 'all' ? 'all' : i, t.id); closeAllPopovers(); } },
      h('span', { html: templatePreview(t.id, store.paper.orient, store.paper.color) }), h('small', { text: t.name })));
  }
  const colors = h('div.paper-colors');
  for (const c of PAPER_COLORS) colors.append(h('button.paper-sw' + (store.paper.color === c.id ? '.on' : ''), { title: c.name, style: { background: c.light }, onclick: (e) => { setPaperColor(c.id); colors.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === e.currentTarget)); grid.querySelectorAll('.tpl-prev rect').forEach((r) => r.setAttribute('fill', c.light)); } }));
  popover(at, h('div.pop-pad.tpl-pop', {},
    h('div.pop-title', { text: 'Papel' }),
    segmented([{ value: 'one', label: `Solo la página ${i + 1}` }, { value: 'all', label: 'Todas las páginas' }], scope, (v) => { scope = v; }),
    grid, h('div.pk-sub', { text: 'Color del papel' }), colors), { className: 'tpl-popover' });
}

export function pagesPanel(b, anchor) {
  const list = h('div.pages-list');
  const cur = currentPage(b);
  const draw = () => {
    list.innerHTML = '';
    store.pages.forEach((p, i) => {
      const th = h('div.pg-thumb');
      const row = h('div.pg-row' + (i === cur ? '.on' : ''), {},
        h('button.pg-go', { onclick: () => { closeAllPopovers(); goToPage(b, i); } }, th, h('span', {}, h('b', { text: `Página ${i + 1}` }), h('small', { text: templateName(p.tpl) }))),
        h('button.btn.icon', { html: icon('ellipsis', 18), onclick: (e) => pageMenu(b, e.currentTarget, i, draw) }));
      list.append(row);
      thumbOf(i).then((c) => { if (c) th.append(c); });
    });
  };
  draw();
  popover(anchor, h('div.pop-pad.pages-pop', {},
    h('div.pop-head', {}, h('b', { text: `${store.pages.length} ${store.pages.length === 1 ? 'página' : 'páginas'}` }),
      h('button.btn.small', { html: `${icon('file-text', 16)} Papel`, onclick: () => templatePicker(b, document.getElementById('page-pill'), cur) })),
    list,
    h('button.btn.full.primary', { html: `${icon('plus', 18)} Añadir página`, onclick: () => { closeAllPopovers(); addPage(b, cur); } })), { placement: 'above', className: 'pages' });
  requestAnimationFrame(() => list.querySelector('.pg-row.on')?.scrollIntoView({ block: 'center' }));
}

function pageMenu(b, anchor, i, redraw) {
  const n = store.pages.length;
  menu(anchor, [
    { label: 'Ir a la página', icon: 'eye', act: () => { closeAllPopovers(); goToPage(b, i); } },
    { label: 'Añadir página después', icon: 'file-plus', act: () => { closeAllPopovers(); addPage(b, i); } },
    { label: 'Añadir página antes', icon: 'file-plus', act: () => { closeAllPopovers(); addPage(b, i - 1, store.pages[i].tpl); } },
    { label: 'Duplicar página', icon: 'copy', act: () => { closeAllPopovers(); duplicatePage(b, i); } },
    { label: 'Cambiar papel', icon: 'file-text', act: () => templatePicker(b, document.getElementById('page-pill'), i) },
    i > 0 ? { label: 'Subir', icon: 'arrow-up', act: () => { movePage(b, i, -1); redraw(); } } : null,
    i < n - 1 ? { label: 'Bajar', icon: 'arrow-down', act: () => { movePage(b, i, 1); redraw(); } } : null,
    { sep: true },
    { label: 'Eliminar página', icon: 'trash-2', danger: true, disabled: n === 1, act: () => { closeAllPopovers(); deletePage(b, i); } },
  ], { keep: true });
}

/** Miniatura de una página (con su plantilla). */
export async function thumbOf(i, maxW = 64) {
  const r = pageRect(i), p = store.pages[i];
  const map = new Map(store.items.map((x) => [x.id, x]));
  const items = store.items.filter((it) => G.boxesIntersect(G.aabb(it, map), r));
  // Escala doble para que se vea nítida en pantallas de alta densidad; el CSS la deja en maxW.
  const s = Math.min(maxW / r.w, maxW / r.h);
  const c = await renderToCanvas(items, r, s * 2, { page: { tpl: p.tpl, color: store.paper.color } });
  c.style.width = `${Math.round(r.w * s)}px`;
  c.style.height = `${Math.round(r.h * s)}px`;
  c.className = 'pg-canvas';
  return c;
}

// Crear un cuaderno ------------------------------------------------------------------------------
/** Diálogo para elegir papel, color y orientación. Devuelve las opciones o null. */
export function newNotebookDialog() {
  const opts = { tpl: 'lines', color: 'white', orient: 'portrait' };
  return dialog((box, done) => {
    box.classList.add('nb-dialog');
    const grid = h('div.tpl-grid');
    const paint = () => {
      grid.innerHTML = '';
      for (const t of TEMPLATES) grid.append(h('button.tpl-opt' + (opts.tpl === t.id ? '.on' : ''), { onclick: () => { opts.tpl = t.id; paint(); } },
        h('span', { html: templatePreview(t.id, opts.orient, opts.color) }), h('small', { text: t.name })));
    };
    const colors = h('div.paper-colors');
    for (const c of PAPER_COLORS) colors.append(h('button.paper-sw' + (opts.color === c.id ? '.on' : ''), { title: c.name, style: { background: c.light }, onclick: (e) => { opts.color = c.id; colors.querySelectorAll('button').forEach((x) => x.classList.toggle('on', x === e.currentTarget)); paint(); } }));
    paint();
    box.append(h('h3', { text: 'Nuevo cuaderno' }),
      h('p', { text: 'Páginas una debajo de otra, como una libreta. Luego puedes cambiar el papel de cada página.' }),
      grid,
      h('div.nb-row', {}, h('div', {}, h('div.pk-sub', { text: 'Color del papel' }), colors),
        h('div', {}, h('div.pk-sub', { text: 'Orientación' }), segmented([{ value: 'portrait', label: 'Vertical' }, { value: 'landscape', label: 'Horizontal' }], opts.orient, (v) => { opts.orient = v; paint(); }))),
      h('div.dlg-btns', {}, h('button.btn', { text: 'Cancelar', onclick: () => done(null) }), h('button.btn.primary', { text: 'Crear', onclick: () => done(opts) })));
  });
}
