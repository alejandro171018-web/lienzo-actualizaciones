// Calibrar la presión del S Pen: aprende lo suave y lo fuerte que escribes tú, para que el grosor
// de los trazos responda a tu mano (se guarda en settings.pressureCal y lo usa penPressure).
import { h, icon } from './util.js';
import { settings } from './settings.js';
import { toast } from './ui.js';
import { inkPath } from './ink.js';
import { penPressure, autoRange, resetLearnedPressure } from './penpressure.js';

export function pressureCalibration() {
  const steps = [
    { title: 'Escribe suave', text: 'Haz 3 rayas o palabras con tu presión más suave, como cuando escribes rápido y sin apretar.' },
    { title: 'Ahora aprieta', text: 'Haz 3 rayas apretando bastante, como cuando repasas algo para que se vea gordo.' },
  ];
  let step = 0, strokes = [[], []], cur = null;
  const title = h('b.pc-title'), text = h('p.pc-text'), count = h('span.pc-count');
  const svg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
  svg.setAttribute('class', 'pc-ink');
  const area = h('div.pc-area', {}, svg);
  const result = h('div.pc-result');
  // Medidor en vivo: lo que manda el lápiz ahora mismo (para ver que apretar cambia algo).
  const meterFill = h('i'), meterNum = h('b', { text: '—' });
  const meter = h('div.pc-meter', {}, h('span', { text: 'Presión del lápiz' }), h('div.pc-bar', {}, meterFill), meterNum);
  const seen = { min: 1, max: 0, n: 0 };
  const showRaw = (raw) => {
    meterFill.style.width = `${Math.round(Math.min(1, raw) * 100)}%`;
    meterNum.textContent = `${Math.round(raw * 100)}`;
    seen.min = Math.min(seen.min, raw); seen.max = Math.max(seen.max, raw); seen.n++;
  };
  const auto = autoRange();
  const status = h('p.pc-status', { text: settings.pressureCal ? 'Ahora usa tu calibración manual.'
    : auto ? `Ajuste automático: ha aprendido que escribes entre ${Math.round(auto.min * 100)} y ${Math.round(auto.max * 100)} (lo normal, ${Math.round(auto.med * 100)}).`
      : 'Ajuste automático: aprende de cómo escribes (necesita unos cuantos trazos).' });
  const next = h('button.btn.primary', { text: 'Siguiente', disabled: true, onclick: () => advance() });
  const paint = () => {
    title.textContent = step < 2 ? `${step + 1} de 2 · ${steps[step].title}` : 'Listo';
    text.textContent = step < 2 ? steps[step].text : 'Prueba a escribir aquí abajo: así quedarán tus trazos con la pluma.';
    count.textContent = step < 2 ? `${strokes[step].length} de 3` : '';
    next.disabled = step < 2 && strokes[step].length < 3;
    next.textContent = step === 1 ? 'Calcular' : step === 2 ? 'Guardar' : 'Siguiente';
  };
  const percentile = (arr, q) => { const s = [...arr].sort((a, b) => a - b); return s[Math.min(s.length - 1, Math.max(0, Math.floor(q * (s.length - 1))))] ?? 0; };
  let proposal = null;
  const advance = () => {
    if (step === 0) { step = 1; svg.innerHTML = ''; paint(); return; }
    if (step === 1) {
      // Rango real: lo más suave (sin contar el arranque y el final) y lo más fuerte.
      const soft = percentile(strokes[0].flat(), 0.25), hard = percentile(strokes[1].flat(), 0.8);
      if (hard - soft < 0.08) { toast('No noto diferencia entre suave y fuerte. Prueba otra vez apretando más en el paso 2.', 3200); strokes[1] = []; svg.innerHTML = ''; paint(); return; }
      proposal = { min: Math.max(0, soft * 0.85), max: Math.min(1, hard * 1.05) };
      settings.pressureCal = proposal;   // se aplica ya, para probarlo
      step = 2; svg.innerHTML = '';
      result.textContent = `Tu rango: de ${Math.round(soft * 100)} a ${Math.round(hard * 100)} (de 100).`;
      paint(); return;
    }
    close(true);
  };
  // Dibujo de prueba con la pluma (en el paso 3 ya con la presión calibrada).
  area.addEventListener('pointerdown', (e) => {
    if (e.pointerType !== 'pen' && e.pointerType !== 'mouse') { toast('Usa el S Pen'); return; }
    e.preventDefault();
    try { area.setPointerCapture(e.pointerId); } catch { /* */ }
    const path = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    path.setAttribute('fill', 'currentColor');
    svg.append(path);
    cur = { path, flat: [], raw: [] };
    add(e);
  });
  const add = (e) => {
    if (!cur) return;
    const r = area.getBoundingClientRect();
    const evs = e.getCoalescedEvents?.();
    for (const ev of evs?.length ? evs : [e]) {
      const raw = ev.pressure || 0.5;
      cur.raw.push(raw);
      showRaw(raw);
      cur.flat.push(ev.clientX - r.left, ev.clientY - r.top, step === 2 ? penPressure(raw, 'pen') : raw);
    }
    if (cur.flat.length) cur.path.setAttribute('d', inkPath(cur.flat, 'pen', 6));
  };
  area.addEventListener('pointermove', (e) => { if (cur) add(e); });
  const end = () => {
    if (!cur) return;
    // Se descartan el arranque y el final del trazo (ahí la presión siempre es baja).
    const k = Math.floor(cur.raw.length * 0.15);
    const mid = cur.raw.slice(k, cur.raw.length - k).filter((p) => p > 0);
    if (step < 2 && mid.length > 3) strokes[step].push(mid);
    cur = null;
    // Si el lápiz manda siempre lo mismo, no hay presión que calibrar: se avisa.
    if (seen.n > 60 && seen.max - seen.min < 0.02) result.textContent = `Tu lápiz manda siempre la misma presión (${Math.round(seen.max * 100)}). Revisa en Ajustes de Android › S Pen que la presión esté activada.`;
    paint();
  };
  area.addEventListener('pointerup', end);
  area.addEventListener('pointercancel', end);

  const prev = settings.pressureCal || null;
  const close = (save) => {
    if (!save) settings.pressureCal = prev;
    else toast('Presión calibrada');
    ov.remove();
  };
  const reset = prev
    ? h('button.btn', { text: 'Volver a automático', onclick: () => { settings.pressureCal = null; toast('Presión automática: aprende de cómo escribes'); ov.remove(); } })
    : h('button.btn', { text: 'Reaprender', onclick: () => { resetLearnedPressure(); toast('Empieza a aprender de nuevo cómo escribes'); ov.remove(); } });
  const ov = h('div.viewer', {},
    h('div.viewer-bar', {}, h('button.btn.icon', { html: icon('x', 22), onclick: () => close(false) }), h('b.viewer-title', { text: 'Calibrar la presión' }), reset),
    h('div.pc-wrap', {}, status, h('div.pc-head', {}, title, count), text, meter, area, result, h('div.pc-btns', {}, next)));
  ov.addEventListener('back', () => close(false));
  document.getElementById('overlay').append(ov);
  paint();
}
