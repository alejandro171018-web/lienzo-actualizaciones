// Versión de la app web. scripts/publicar.mjs la sube y la app la compara para actualizarse.
export const VERSION = '1.10.3';
